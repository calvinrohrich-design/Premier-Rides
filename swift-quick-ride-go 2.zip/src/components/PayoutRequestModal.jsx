import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { X, DollarSign, CheckCircle } from "lucide-react";

const PAYMENT_METHODS = ["Venmo", "Zelle", "Cash App", "PayPal", "Check", "Direct Deposit"];

export default function PayoutRequestModal({ user, availableBalance, onClose }) {
  const [paymentMethod, setPaymentMethod] = useState("");
  const [paymentDetails, setPaymentDetails] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!paymentMethod || !paymentDetails) return;
    setLoading(true);
    await base44.entities.PayoutRequest.create({
      driver_id: user.id,
      driver_name: user.full_name,
      amount: availableBalance,
      payment_method: paymentMethod,
      payment_details: paymentDetails,
      notes,
      status: "pending",
      period_end: new Date().toISOString(),
    });
    setLoading(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black/60 z-50 flex items-end justify-center">
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          className="bg-card w-full max-w-md rounded-t-3xl p-8 text-center"
        >
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-primary" />
          </div>
          <h2 className="text-xl font-bold mb-2">Request Submitted!</h2>
          <p className="text-muted-foreground text-sm mb-6">
            Your payout request of <strong>${availableBalance.toFixed(2)}</strong> has been sent. You'll be paid via {paymentMethod} once approved.
          </p>
          <button onClick={onClose} className="w-full bg-primary text-white py-4 rounded-2xl font-bold">
            Done
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-end justify-center">
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        className="bg-card w-full max-w-md rounded-t-3xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Request Payout</h2>
          <button onClick={onClose} className="w-9 h-9 bg-secondary rounded-xl flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Amount */}
        <div className="bg-primary/10 rounded-2xl p-4 flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
            <DollarSign className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Requesting</p>
            <p className="text-2xl font-bold text-primary">${availableBalance.toFixed(2)}</p>
          </div>
        </div>

        {/* Payment Method */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-muted-foreground mb-2 block">Payment Method</label>
          <div className="grid grid-cols-3 gap-2">
            {PAYMENT_METHODS.map((m) => (
              <button
                key={m}
                onClick={() => setPaymentMethod(m)}
                className={`py-2.5 rounded-xl border-2 text-sm font-semibold transition-all ${
                  paymentMethod === m ? "border-primary bg-primary/10 text-primary" : "border-border bg-secondary text-muted-foreground"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Payment Details */}
        {paymentMethod && (
          <div className="mb-4">
            <label className="text-xs font-semibold text-muted-foreground mb-2 block">
              {paymentMethod === "Check" ? "Mailing Address" : paymentMethod === "Direct Deposit" ? "Bank Details" : `Your ${paymentMethod} username / phone / email`}
            </label>
            <input
              type="text"
              placeholder={paymentMethod === "Check" ? "123 Main St, Bismarck ND" : paymentMethod === "Venmo" ? "@yourname" : "Phone or email"}
              value={paymentDetails}
              onChange={(e) => setPaymentDetails(e.target.value)}
              className="w-full bg-secondary rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        )}

        {/* Notes */}
        <div className="mb-6">
          <label className="text-xs font-semibold text-muted-foreground mb-2 block">Notes (optional)</label>
          <textarea
            placeholder="Any additional info..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full bg-secondary rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary h-20 resize-none"
          />
        </div>

        <button
          onClick={handleSubmit}
          disabled={loading || !paymentMethod || !paymentDetails}
          className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 disabled:opacity-40 active:scale-95 transition-transform"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
          ) : "Submit Payout Request"}
        </button>
      </motion.div>
    </div>
  );
}