import { useState } from "react";
import { X, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import AddressAutocomplete from "@/components/AddressAutocomplete";

const PLACES = [
  { key: "home", label: "Home", emoji: "🏠", addrField: "saved_home_address", latField: "saved_home_lat", lngField: "saved_home_lng" },
  { key: "work", label: "Work", emoji: "🏢", addrField: "saved_work_address", latField: "saved_work_lat", lngField: "saved_work_lng" },
  { key: "airport", label: "Airport", emoji: "✈️", addrField: "saved_airport_address", latField: "saved_airport_lat", lngField: "saved_airport_lng" },
];

export default function SavedPlacesEditor({ user, onClose, onSaved }) {
  const [editing, setEditing] = useState(null); // key of the place being edited
  const [value, setValue] = useState("");
  const [coords, setCoords] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(null);

  const startEdit = (place) => {
    setEditing(place.key);
    setValue(user?.[place.addrField] || "");
    setCoords(
      user?.[place.latField] ? { lat: user[place.latField], lng: user[place.lngField] } : null
    );
  };

  const handleSelect = (location) => {
    setCoords({ lat: location.lat, lng: location.lng });
  };

  const handleSave = async () => {
    const place = PLACES.find((p) => p.key === editing);
    if (!place || !value) return;
    setSaving(true);
    await base44.auth.updateMe({
      [place.addrField]: value,
      ...(coords ? { [place.latField]: coords.lat, [place.lngField]: coords.lng } : {}),
    });
    setSaved(place.key);
    setSaving(false);
    setEditing(null);
    setTimeout(() => setSaved(null), 2000);
    if (onSaved) onSaved({ ...user, [place.addrField]: value, ...(coords ? { [place.latField]: coords.lat, [place.lngField]: coords.lng } : {}) });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-end"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 28, stiffness: 300 }}
        className="w-full bg-card rounded-t-3xl px-5 pt-5 pb-10"
        style={{ paddingBottom: "max(2.5rem, env(safe-area-inset-bottom, 2.5rem))" }}
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold">Saved Places</h2>
          <button onClick={onClose} className="w-9 h-9 bg-secondary rounded-xl flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          {PLACES.map((place) => {
            const currentAddr = user?.[place.addrField];
            const isEditing = editing === place.key;
            const justSaved = saved === place.key;

            return (
              <div key={place.key} className="bg-secondary rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{place.emoji}</span>
                    <span className="font-semibold">{place.label}</span>
                  </div>
                  {!isEditing && (
                    <button
                      onClick={() => startEdit(place)}
                      className="text-xs text-primary font-semibold px-3 py-1.5 bg-primary/10 rounded-xl active:scale-95 transition-transform"
                    >
                      {currentAddr ? "Edit" : "Set"}
                    </button>
                  )}
                  {justSaved && (
                    <span className="flex items-center gap-1 text-xs text-green-600 font-semibold">
                      <Check className="w-3.5 h-3.5" /> Saved
                    </span>
                  )}
                </div>

                {!isEditing && (
                  <p className="text-sm text-muted-foreground truncate">
                    {currentAddr || <span className="italic">Not set</span>}
                  </p>
                )}

                <AnimatePresence>
                  {isEditing && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="pt-2 space-y-2">
                        <AddressAutocomplete
                          placeholder={`Enter ${place.label.toLowerCase()} address`}
                          value={value}
                          onChange={setValue}
                          onSelect={handleSelect}
                          icon="pin"
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={() => setEditing(null)}
                            className="flex-1 py-2.5 border border-border rounded-xl text-sm font-semibold text-muted-foreground active:scale-95 transition-transform"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleSave}
                            disabled={saving || !value}
                            className="flex-1 py-2.5 bg-primary text-white rounded-xl text-sm font-semibold active:scale-95 transition-transform disabled:opacity-40"
                          >
                            {saving ? "Saving..." : "Save"}
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </motion.div>
    </motion.div>
  );
}