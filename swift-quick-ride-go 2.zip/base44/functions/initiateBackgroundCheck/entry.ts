import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Checkr API credentials (must be set in environment variables)
    const checkrApiKey = Deno.env.get('CHECKR_API_KEY');
    if (!checkrApiKey) {
      console.error('CHECKR_API_KEY not configured');
      return Response.json({ 
        error: 'Background check service not configured',
        success: false 
      }, { status: 500 });
    }

    // Create applicant in Checkr
    const applicantResponse = await fetch('https://api.checkr.com/v1/applicants', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${btoa(checkrApiKey + ':')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: user.email,
        first_name: user.full_name?.split(' ')[0] || 'User',
        last_name: user.full_name?.split(' ').slice(1).join(' ') || 'Name',
      }),
    });

    if (!applicantResponse.ok) {
      const error = await applicantResponse.json();
      console.error('Checkr applicant creation failed:', error);
      return Response.json({ 
        error: 'Failed to initiate background check',
        success: false 
      }, { status: 500 });
    }

    const applicant = await applicantResponse.json();

    // Create background check report
    const reportResponse = await fetch('https://api.checkr.com/v1/reports', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${btoa(checkrApiKey + ':')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        applicant_id: applicant.id,
        package: 'rideshare_standard', // Or your configured package name
      }),
    });

    if (!reportResponse.ok) {
      const error = await reportResponse.json();
      console.error('Checkr report creation failed:', error);
      return Response.json({ 
        error: 'Failed to create background check report',
        success: false 
      }, { status: 500 });
    }

    const report = await reportResponse.json();

    console.log(`Background check initiated for ${user.email}, Checkr applicant ID: ${applicant.id}`);

    return Response.json({
      success: true,
      applicant_id: applicant.id,
      report_id: report.id,
      report_status: report.status,
    });
  } catch (error) {
    console.error('Background check initiation error:', error);
    return Response.json({ 
      error: error.message,
      success: false 
    }, { status: 500 });
  }
});