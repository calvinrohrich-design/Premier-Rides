import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { X, Send } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const QUICK_REPLIES = [
  "On my way!",
  "I'm here, outside.",
  "Be there in 2 min",
  "Running a bit late",
];

export default function RideChat({ rideId, currentUser, senderRole, otherName, onClose }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    // Load existing messages
    base44.entities.RideMessage.filter({ ride_id: rideId }, "created_date", 100).then(setMessages);

    // Subscribe to real-time updates
    const unsub = base44.entities.RideMessage.subscribe((event) => {
      if (event.data?.ride_id === rideId) {
        if (event.type === "create") {
          setMessages((prev) => {
            // Avoid duplicates
            if (prev.find((m) => m.id === event.id)) return prev;
            return [...prev, event.data];
          });
        }
      }
    });
    return unsub;
  }, [rideId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (content) => {
    if (!content.trim()) return;
    console.log('[RideChat] Sending message:', { rideId, sender_id: currentUser?.id, content });
    setSending(true);
    setText("");
    try {
      await base44.entities.RideMessage.create({
        ride_id: rideId,
        sender_id: currentUser?.id,
        sender_name: currentUser?.full_name,
        sender_role: senderRole,
        content: content.trim(),
      });
      console.log('[RideChat] Message sent successfully');
    } catch (error) {
      console.error('[RideChat] Failed to send message:', error);
      alert('Failed to send message. Please try again.');
      setText(content);
    }
    setSending(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage(text);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: "100%" }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: "100%" }}
      transition={{ type: "spring", damping: 28, stiffness: 300 }}
      className="fixed inset-0 z-50 flex flex-col bg-background"
    >
      {/* Header */}
      <div className="flex items-center gap-3 px-5 pt-12 pb-4 border-b border-border bg-card">
        <button onClick={onClose} className="w-9 h-9 bg-secondary rounded-xl flex items-center justify-center">
          <X className="w-4 h-4" />
        </button>
        <div className="flex-1">
          <p className="font-bold">{otherName || "Chat"}</p>
          <p className="text-xs text-muted-foreground">In-ride chat · no numbers shared</p>
        </div>
        <div className="w-2.5 h-2.5 bg-primary rounded-full animate-pulse" />
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <span className="text-4xl block mb-3">💬</span>
            <p className="font-medium">No messages yet</p>
            <p className="text-sm mt-1">Send a message to {otherName}</p>
          </div>
        )}
        {messages.map((msg) => {
          const isMe = msg.sender_id === currentUser.id;
          return (
            <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[75%] ${isMe ? "items-end" : "items-start"} flex flex-col gap-1`}>
                {!isMe && (
                  <p className="text-xs text-muted-foreground px-1">{msg.sender_name}</p>
                )}
                <div className={`px-4 py-2.5 rounded-2xl text-sm ${isMe
                  ? "bg-primary text-white rounded-br-sm"
                  : "bg-card border border-border text-foreground rounded-bl-sm"
                }`}>
                  {msg.content}
                </div>
                <p className="text-xs text-muted-foreground px-1">
                  {new Date(msg.created_date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Quick Replies */}
      <div className="px-4 py-2 flex gap-2 overflow-x-auto scrollbar-hide">
        {QUICK_REPLIES.map((q) => (
          <button
            key={q}
            onClick={() => sendMessage(q)}
            className="flex-shrink-0 bg-secondary border border-border text-sm px-3 py-1.5 rounded-full font-medium active:scale-95 transition-transform"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="flex items-center gap-3 px-4 pb-8 pt-2 border-t border-border bg-card">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type a message..."
          className="flex-1 bg-secondary rounded-2xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          autoFocus
        />
        <button
          type="submit"
          disabled={!text.trim() || sending}
          className="w-11 h-11 bg-primary rounded-xl flex items-center justify-center active:scale-90 transition-transform disabled:opacity-40 flex-shrink-0"
        >
          <Send className="w-4 h-4 text-white" />
        </button>
      </form>
    </motion.div>
  );
}