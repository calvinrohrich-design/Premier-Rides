import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const { input, lat, lng } = await req.json();

    if (!input) {
      return Response.json({ error: "Missing input" }, { status: 400 });
    }

    const apiKey = Deno.env.get("GOOGLE_MAPS_API_KEY");
    let url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(input)}&key=${apiKey}&language=en`;

    if (lat && lng) {
      url += `&location=${lat},${lng}&radius=50000`;
    }

    const res = await fetch(url);
    const data = await res.json();

    return Response.json({ predictions: data.predictions || [] });
  } catch (error) {
    console.error("placesAutocomplete error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});