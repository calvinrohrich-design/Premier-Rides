import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle, XCircle, Clock, User, Car, FileText, Shield, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";

export default function AdminDriverApprovals() {
  const [pendingDrivers, setPendingDrivers] = useState([]);
  const [processedDrivers, setProcessedDrivers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);

  useEffect(() => {
    loadDrivers();
  }, []);

  const loadDrivers = async () => {
    setLoading(true);
    try {
      const response = await base44.functions.invoke('getAllUsers', {});
      const users = response.data.users || [];
      const pending = users.filter((u) => ["submitted", "background_check_pending"].includes(u.verification_status));
      const processed = users.filter((u) => ["approved", "rejected"].includes(u.verification_status));
      setPendingDrivers(pending);
      setProcessedDrivers(processed);
    } catch (error) {
      console.error('Failed to load drivers:', error);
    }
    setLoading(false);
  };

  const handleApprove = async (driverId) => {
    setActionLoading(driverId);
    try {
      await base44.functions.invoke('updateUserStatus', { userId: driverId, verificationStatus: 'approved' });
    } catch (error) {
      console.error('Failed to approve driver:', error);
    }
    setActionLoading(null);
    loadDrivers();
  };

  const handleReject = async (driverId) => {
    setActionLoading(driverId);
    try {
      await base44.functions.invoke('updateUserStatus', { userId: driverId, verificationStatus: 'rejected' });
    } catch (error) {
      console.error('Failed to reject driver:', error);
    }
    setActionLoading(null);
    loadDrivers();
  };

  const getStatusColor = (status) => {
    if (status === "approved") return "bg-green-100 text-green-700";
    if (status === "rejected") return "bg-red-100 text-red-700";
    return "bg-amber-100 text-amber-700";
  };

  const getStatusIcon = (status) => {
    if (status === "approved") return <CheckCircle className="w-3 h-3" />;
    if (status === "rejected") return <XCircle className="w-3 h-3" />;
    return <Clock className="w-3 h-3" />;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <Clock className="w-5 h-5 text-amber-500" />
          Pending Applications ({pendingDrivers.length})
        </h2>

        {pendingDrivers.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <User className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No pending applications</p>
          </div>
        )}

        <div className="grid gap-4">
          {pendingDrivers.map((driver) => (
            <motion.div
              key={driver.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border rounded-2xl p-5"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-lg font-bold">
                  {driver.full_name?.[0] || "?"}
                </div>
                <div className="flex-1">
                  <p className="font-bold text-lg">{driver.full_name || "Unknown"}</p>
                  <p className="text-sm text-muted-foreground">{driver.email}</p>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 ${getStatusColor("submitted")}`}>
                      {getStatusIcon("submitted")}
                      Under Review
                    </span>
                    {driver.checkr_report_status ? (
                      <span className={`text-xs px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 ${
                        driver.checkr_report_status === 'clear' ? 'bg-green-100 text-green-700' :
                        driver.checkr_report_status === 'consider' ? 'bg-amber-100 text-amber-700' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        <Shield className="w-3 h-3" />
                        BG Check: {driver.checkr_report_status === 'clear' ? 'Clear' : driver.checkr_report_status === 'consider' ? 'Review' : 'Pending'}
                      </span>
                    ) : (
                      <span className="text-xs px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 bg-amber-100 text-amber-700">
                        <Shield className="w-3 h-3" />
                        No Background Check
                      </span>
                    )}
                    {driver.vehicle_make && (
                      <span className="text-xs bg-secondary px-2.5 py-1 rounded-full font-medium flex items-center gap-1">
                        <Car className="w-3 h-3" />
                        {driver.vehicle_make} {driver.vehicle_model}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {driver.vehicle_make && (
                <div className="bg-secondary rounded-xl p-3 mb-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Car className="w-4 h-4 text-muted-foreground" />
                    <p className="text-xs font-semibold text-muted-foreground">VEHICLE</p>
                  </div>
                  <p className="text-sm font-semibold">
                    {driver.vehicle_color} {driver.vehicle_make} {driver.vehicle_model} · {driver.license_plate || "N/A"}
                  </p>
                </div>
              )}

              <div className="space-y-2 mb-4">
                {[
                  ["drivers_license_url", "Driver's License", FileText],
                  ["vehicle_registration_url", "Vehicle Registration", Car],
                  ["insurance_url", "Insurance", Shield],
                  ["mvr_url", "MVR / Driving Record", FileText],
                ].map(([key, label, Icon]) => (
                  <div key={key}>
                    <p className="text-xs text-muted-foreground mb-1">{label}</p>
                    {driver[key] ? (
                      <a
                        href={driver[key]}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-primary flex items-center gap-1 hover:underline"
                      >
                        <FileText className="w-3 h-3" />
                        View Document
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    ) : (
                      <p className="text-xs text-muted-foreground">Not uploaded</p>
                    )}
                  </div>
                ))}
              </div>

              {!driver.checkr_report_status && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-3">
                  <p className="text-xs text-amber-800 font-semibold mb-1">⚠️ No Background Check</p>
                  <p className="text-xs text-amber-700">This driver hasn't completed a background check. Approve at your own discretion.</p>
                </div>
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => handleReject(driver.id)}
                  disabled={actionLoading === driver.id}
                  className="flex-1 border-2 border-destructive text-destructive py-2.5 rounded-xl font-bold text-sm active:scale-95 transition-transform disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {actionLoading === driver.id ? (
                    <div className="w-4 h-4 border-2 border-destructive/30 border-t-destructive rounded-full animate-spin" />
                  ) : (
                    <>
                      <XCircle className="w-4 h-4" /> Reject
                    </>
                  )}
                </button>
                <button
                  onClick={() => handleApprove(driver.id)}
                  disabled={actionLoading === driver.id}
                  className="flex-[2] bg-primary text-white py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {actionLoading === driver.id ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" /> Approve Driver
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {processedDrivers.length > 0 && (
        <div>
          <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
            <FileText className="w-5 h-5 text-muted-foreground" />
            Processed ({processedDrivers.length})
          </h2>
          <div className="grid gap-3">
            {processedDrivers.map((driver) => (
              <div key={driver.id} className="bg-card border border-border rounded-2xl p-4 opacity-75">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center text-sm font-bold">
                    {driver.full_name?.[0] || "?"}
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{driver.full_name}</p>
                    <p className="text-xs text-muted-foreground">{driver.email}</p>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 ${getStatusColor(driver.verification_status)}`}>
                    {getStatusIcon(driver.verification_status)}
                    {driver.verification_status === "approved" ? "Approved" : "Rejected"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}