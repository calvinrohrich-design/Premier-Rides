import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, Clock, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import { driverEarnings } from "@/utils/fareCalculator";

/**
 * Shown to a driver during an active ride.
 * Displays the next waiting ride request and lets the driver queue it
 * so they can pick up that customer right after the current dropoff.
 */
export default function QueuedRideCard({ currentUser, activeRideId }) {
  const [nextRide, setNextRide] = useState(null);

  const loadNext = async () => {
    const requested = await base44.entities.Ride.filter({ status: "requested" });
    const candidates = requested.filter((r) => r.id !== activeRideId);
    // Prefer a ride this driver already queued
    const mine = candidates.find((r) => r.queued_driver_id === currentUser?.id);
    setNextRide(mine || candidates[0] || null);
  };

  useEffect(() => {
    if (!currentUser) return;
    loadNext();
    const unsub = base44.entities.Ride.subscribe((event) => {
      if (event.id === activeRideId) return;
      if (event.type === "create" && event.data?.status === "requested") {
        setNextRide((prev) => prev || event.data);
      }
      if (event.type === "update" || event.type === "delete") {
        setNextRide((prev) => {
          if (prev?.id !== event.id) return prev;
          if (event.type === "delete" || event.data?.status !== "requested") {
            loadNext();
            return null;
          }
          return event.data;
        });
      }
    });
    return unsub;
  }, [currentUser?.id, activeRideId]);

  if (!nextRide) return null;

  const isQueuedByMe = nextRide.queued_driver_id === currentUser?.id;
  const isQueuedByOther = nextRide.queued_driver_id && !isQueuedByMe;
  if (isQueuedByOther) return null;

  const handleQueue = async () => {
    await base44.entities.Ride.update(nextRide.id, {
      queued_driver_id: currentUser.id,
      queued_driver_name: currentUser.full_name,
    });
    setNextRide({ ...nextRide, queued_driver_id: currentUser.id, queued_driver_name: currentUser.full_name });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl border-2 p-4 mb-4 ${isQueuedByMe ? "border-primary bg-primary/5" : "border-amber-400 bg-amber-50"}`}
    >
      {isQueuedByMe ? (
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle className="w-4 h-4 text-primary" />
          <p className="font-bold text-sm text-primary">Next Ride Queued</p>
        </div>
      ) : (
        <p className="font-bold text-sm text-amber-700 mb-2">⏳ A rider is waiting — queue them next?</p>
      )}
      <div className="flex items-start gap-2 text-sm">
        <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="font-semibold truncate">{nextRide.pickup_address}</p>
          <p className="text-muted-foreground text-xs truncate">→ {nextRide.dropoff_address}</p>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="font-bold text-primary">${driverEarnings(nextRide.estimated_fare).toFixed(2)}</p>
          <p className="text-xs text-muted-foreground flex items-center gap-1 justify-end">
            <Clock className="w-3 h-3" />{nextRide.estimated_duration_min || "—"} min
          </p>
        </div>
      </div>
      {isQueuedByMe ? (
        <p className="text-xs text-muted-foreground mt-2">You'll start this ride right after your current dropoff.</p>
      ) : (
        <button
          onClick={handleQueue}
          className="mt-3 w-full bg-amber-500 text-white py-2.5 rounded-xl font-bold text-sm active:scale-95 transition-transform"
        >
          Add to Queue
        </button>
      )}
    </motion.div>
  );
}