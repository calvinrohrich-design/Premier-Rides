import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { DollarSign, CheckCircle, XCircle, Clock, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

const STATUS_STYLES = {
  pending: "bg-amber-100 text-amber-700",
  approved: "bg-blue-100 text-blue-700",
  paid: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
};

export default function AdminPayouts() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);
  const [adminNotes, setAdminNotes] = useState({});

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    setLoading(true);
    const all = await base44.entities.PayoutRequest.list("-created_date", 100);
    setRequests(all);
    setLoading(false);
  };

  const updateStatus = async (id, status) => {
    setActionLoading(id);
    const req = requests.find((r) => r.id === id);
    await base44.entities.PayoutRequest.update(id, {
      status,
      admin_notes: adminNotes[id] || "",
    });

    // Send confirmation email when marked as paid
    if (status === "paid" && req?.driver_id) {
      try {
        const [driver] = await base44.entities.User.filter({ id: req.driver_id });
        if (driver?.email) {
          await base44.integrations.Core.SendEmail({
            to: driver.email,
            subject: "Your EW Premier Rides Payout Has Been Sent! 💸",
            body: `Hi ${req.driver_name},\n\nGreat news! Your payout of $${(req.amount || 0).toFixed(2)} has been sent to your ${req.payment_method} account (${req.payment_details}).\n\nPlease allow a few minutes for the transfer to appear.\n${adminNotes[id] ? `\nNote from admin: ${adminNotes[id]}\n` : ""}\nThank you for driving with EW Premier Rides!\n\n— The EW Premier Rides Team`,
          });
        }
      } catch (e) {
        console.error("Failed to send payout email:", e);
      }
    }

    setActionLoading(null);
    loadRequests();
  };

  const pending = requests.filter((r) => r.status === "pending");
  const processed = requests.filter((r) => r.status !== "pending");
  const totalPending = pending.reduce((sum, r) => sum + (r.amount || 0), 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-10 h-10 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Pending", value: pending.length, color: "text-amber-600 bg-amber-50 border-amber-200" },
          { label: "Total Owed", value: `$${totalPending.toFixed(2)}`, color: "text-primary bg-primary/5 border-primary/20" },
          { label: "Paid Out", value: requests.filter(r => r.status === "paid").length, color: "text-green-600 bg-green-50 border-green-200" },
        ].map((s) => (
          <div key={s.label} className={`border rounded-2xl p-3 text-center ${s.color}`}>
            <p className="text-xl font-bold">{s.value}</p>
            <p className="text-xs font-semibold mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Pending Requests */}
      <div>
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <Clock className="w-5 h-5 text-amber-500" />
          Pending Requests ({pending.length})
        </h2>

        {pending.length === 0 && (
          <div className="text-center py-10 text-muted-foreground">
            <DollarSign className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p>No pending payout requests</p>
          </div>
        )}

        <div className="space-y-4">
          {pending.map((req) => (
            <motion.div
              key={req.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border rounded-2xl p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-bold text-lg">{req.driver_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(req.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                  </p>
                </div>
                <p className="text-2xl font-bold text-primary">${(req.amount || 0).toFixed(2)}</p>
              </div>

              <div className="bg-secondary rounded-xl p-3 mb-3 space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Pay via</span>
                  <span className="font-semibold">{req.payment_method}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Send to</span>
                  <span className="font-semibold">{req.payment_details}</span>
                </div>
              </div>

              {req.notes && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-3">
                  <p className="text-xs text-amber-800"><strong>Driver note:</strong> {req.notes}</p>
                </div>
              )}

              <textarea
                placeholder="Admin notes (optional)..."
                value={adminNotes[req.id] || ""}
                onChange={(e) => setAdminNotes((prev) => ({ ...prev, [req.id]: e.target.value }))}
                className="w-full bg-secondary rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none h-16 mb-3"
              />

              <div className="flex gap-2">
                <button
                  onClick={() => updateStatus(req.id, "rejected")}
                  disabled={actionLoading === req.id}
                  className="flex-1 border-2 border-destructive text-destructive py-2.5 rounded-xl font-bold text-sm active:scale-95 transition-transform disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  <XCircle className="w-4 h-4" /> Reject
                </button>
                <button
                  onClick={() => updateStatus(req.id, "approved")}
                  disabled={actionLoading === req.id}
                  className="flex-1 bg-blue-500 text-white py-2.5 rounded-xl font-bold text-sm active:scale-95 transition-transform disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  <AlertCircle className="w-4 h-4" /> Approve
                </button>
                <button
                  onClick={() => updateStatus(req.id, "paid")}
                  disabled={actionLoading === req.id}
                  className="flex-[2] bg-primary text-white py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  {actionLoading === req.id ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <><CheckCircle className="w-4 h-4" /> Mark as Paid</>
                  )}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Processed */}
      {processed.length > 0 && (
        <div>
          <h2 className="text-lg font-bold mb-3">History ({processed.length})</h2>
          <div className="space-y-3">
            {processed.map((req) => (
              <div key={req.id} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3 opacity-80">
                <div className="flex-1">
                  <p className="font-semibold text-sm">{req.driver_name}</p>
                  <p className="text-xs text-muted-foreground">{req.payment_method} · {new Date(req.created_date).toLocaleDateString()}</p>
                </div>
                <p className="font-bold">${(req.amount || 0).toFixed(2)}</p>
                <span className={`text-xs px-2.5 py-1 rounded-full font-semibold capitalize ${STATUS_STYLES[req.status]}`}>
                  {req.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}