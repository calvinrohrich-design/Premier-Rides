import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const base44 = createClientFromRequest(req);

    const body = await req.text();
    const sig = req.headers.get('stripe-signature');
    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

    // Reject any request without a valid Stripe signature — never trust unsigned payloads
    if (!webhookSecret || !sig) {
      console.error('Webhook rejected: missing signature or webhook secret');
      return Response.json({ error: 'Missing signature' }, { status: 400 });
    }
    const event = await stripe.webhooks.constructEventAsync(body, sig, webhookSecret);

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const rideId = session.metadata?.ride_id;
      const isTip = session.metadata?.is_tip === 'true';

      if (rideId) {
        if (isTip) {
          const ride = await base44.asServiceRole.entities.Ride.filter({ id: rideId });
          if (ride.length > 0) {
            const currentTip = ride[0].tip_amount || 0;
            await base44.asServiceRole.entities.Ride.update(rideId, {
              tip_amount: currentTip + (session.amount_total / 100),
            });
            console.log(`Tip of $${session.amount_total / 100} added to ride ${rideId}`);
          }
        } else {
          await base44.asServiceRole.entities.Ride.update(rideId, {
            payment_status: 'paid',
            final_fare: session.amount_total / 100,
          });
          console.log(`Ride ${rideId} marked as paid`);

          // Save Stripe customer ID to the user for future one-click charges
          const stripeCustomerId = session.customer;
          if (stripeCustomerId) {
            const rides = await base44.asServiceRole.entities.Ride.filter({ id: rideId });
            if (rides.length > 0) {
              const customerId = rides[0].customer_id;
              if (customerId) {
                const users = await base44.asServiceRole.entities.User.filter({ id: customerId });
                if (users.length > 0 && !users[0].stripe_customer_id) {
                  await base44.asServiceRole.entities.User.update(customerId, { stripe_customer_id: stripeCustomerId });
                  console.log(`Saved Stripe customer ${stripeCustomerId} for user ${customerId}`);
                }
              }
            }
          }
        }
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 400 });
  }
});