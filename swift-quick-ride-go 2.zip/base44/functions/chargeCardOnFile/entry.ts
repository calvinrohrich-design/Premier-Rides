import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { rideId } = await req.json();
    if (!rideId) return Response.json({ error: 'Missing rideId' }, { status: 400 });

    const rides = await base44.asServiceRole.entities.Ride.filter({ id: rideId });
    if (!rides.length) return Response.json({ error: 'Ride not found' }, { status: 404 });
    const ride = rides[0];

    if (!ride.estimated_fare || ride.estimated_fare <= 0) {
      return Response.json({ error: 'Ride has no valid fare' }, { status: 400 });
    }

    const stripeCustomerId = user.stripe_customer_id;
    if (!stripeCustomerId) return Response.json({ error: 'No saved payment method' }, { status: 400 });

    const methods = await stripe.paymentMethods.list({ customer: stripeCustomerId, type: 'card' });
    const pm = methods.data[0];
    if (!pm) return Response.json({ error: 'No saved payment method' }, { status: 400 });

    const amountCents = Math.round(ride.estimated_fare * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountCents,
      currency: 'usd',
      customer: stripeCustomerId,
      payment_method: pm.id,
      confirm: true,
      off_session: true,
      description: `${ride.ride_type || 'Economy'} Ride: ${ride.pickup_address} → ${ride.dropoff_address}`,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        ride_id: rideId,
      },
    });

    if (paymentIntent.status === 'succeeded') {
      await base44.asServiceRole.entities.Ride.update(rideId, { payment_status: 'paid' });
      return Response.json({ success: true });
    } else {
      return Response.json({ error: 'Payment did not succeed', status: paymentIntent.status }, { status: 402 });
    }
  } catch (error) {
    console.error('chargeCardOnFile error:', error);
    // If off-session payment requires authentication, fall back to checkout
    if (error.code === 'authentication_required' || error.code === 'requires_action') {
      return Response.json({ requiresCheckout: true });
    }
    return Response.json({ error: error.message }, { status: 500 });
  }
});