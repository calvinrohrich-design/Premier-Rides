import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const today = new Date().toISOString().split('T')[0];
    const warnDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const allUsers = await base44.asServiceRole.entities.User.list();

    const drivers = allUsers.filter(
      (u) =>
        (u.user_type === 'driver' || u.user_type === 'both') &&
        u.verification_status === 'approved' &&
        u.documents_valid !== false
    );

    const blocked = [];
    const warned = [];

    for (const driver of drivers) {
      const licenseExpired = driver.license_expiration_date && driver.license_expiration_date < today;
      const insuranceExpired = driver.insurance_expiration_date && driver.insurance_expiration_date < today;

      if (!licenseExpired && !insuranceExpired) {
        // Advance warning: docs expiring within the next 14 days
        const expiringSoon = [
          driver.license_expiration_date && driver.license_expiration_date <= warnDate
            ? `driver's license (expires ${driver.license_expiration_date})` : null,
          driver.insurance_expiration_date && driver.insurance_expiration_date <= warnDate
            ? `auto insurance (expires ${driver.insurance_expiration_date})` : null,
        ].filter(Boolean);

        if (expiringSoon.length === 0) continue;

        // Only warn once per expiration date set
        const warnKey = expiringSoon.join('|');
        if (driver.expiration_warning_sent === warnKey) continue;

        try {
          await base44.asServiceRole.integrations.Core.SendEmail({
            to: driver.email,
            subject: '⏰ Renewal Reminder: Your driver document expires soon',
            body: `Hi ${driver.full_name},\n\nHeads up — your ${expiringSoon.join(' and ')} on file with EW Premier Rides ${expiringSoon.length > 1 ? 'are' : 'is'} expiring soon.\n\nPlease renew now. If your document expires, you will automatically be taken offline and won't be able to accept rides until you upload a current, valid document.\n\nTo stay on the road:\n1. Renew your document with your provider\n2. Open the app and go to Driver Verification\n3. Upload the renewed document\n\nThanks for keeping our platform safe!\nThe EW Premier Rides Team`,
          });
          await base44.asServiceRole.entities.User.update(driver.id, {
            expiration_warning_sent: warnKey,
          });
          warned.push({ email: driver.email, expiring: expiringSoon });
          console.log(`Warned driver ${driver.email}: ${expiringSoon.join(', ')}`);
        } catch (emailError) {
          console.error(`Failed to warn ${driver.email}:`, emailError);
        }
        continue;
      }

      const expiredDocs = [
        licenseExpired ? `driver's license (expired ${driver.license_expiration_date})` : null,
        insuranceExpired ? `insurance (expired ${driver.insurance_expiration_date})` : null,
      ].filter(Boolean);

      await base44.asServiceRole.entities.User.update(driver.id, {
        documents_valid: false,
        is_online: false,
        on_break: false,
        documents_validation_notes: `Auto-blocked on ${today}: ${expiredDocs.join(' and ')}`,
      });

      try {
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: driver.email,
          subject: '⚠️ Action Required: Your driver documents have expired',
          body: `Hi ${driver.full_name},\n\nYour ${expiredDocs.join(' and ')} on file with EW Premier Rides ${expiredDocs.length > 1 ? 'have' : 'has'} expired.\n\nYou have been temporarily taken offline and cannot accept rides until you upload a current, valid document.\n\nTo get back on the road:\n1. Open the app and go to Driver Verification\n2. Upload your renewed document(s)\n3. Once validated, you'll be cleared to drive again\n\nThanks for keeping our platform safe!\nThe EW Premier Rides Team`,
        });
      } catch (emailError) {
        console.error(`Failed to email ${driver.email}:`, emailError);
      }

      blocked.push({ email: driver.email, expired: expiredDocs });
      console.log(`Blocked driver ${driver.email}: ${expiredDocs.join(', ')}`);
    }

    return Response.json({
      checked: drivers.length,
      blocked_count: blocked.length,
      blocked,
      warned_count: warned.length,
      warned,
    });
  } catch (error) {
    console.error('Document expiration check error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});