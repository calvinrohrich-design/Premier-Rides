import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const stripeCustomerId = user.stripe_customer_id;
    if (!stripeCustomerId) return Response.json({ paymentMethod: null });

    const methods = await stripe.paymentMethods.list({ customer: stripeCustomerId, type: 'card' });
    const pm = methods.data[0];
    if (!pm) return Response.json({ paymentMethod: null });

    return Response.json({
      paymentMethod: {
        id: pm.id,
        brand: pm.card.brand,
        last4: pm.card.last4,
        exp_month: pm.card.exp_month,
        exp_year: pm.card.exp_year,
      }
    });
  } catch (error) {
    console.error('getSavedPaymentMethod error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});