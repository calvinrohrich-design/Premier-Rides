import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { DollarSign, Car, Users, TrendingUp, Star, Clock } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function AdminStats() {
  const [stats, setStats] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const ridesPromise = base44.entities.Ride.list("-created_date", 200);
        const usersPromise = base44.functions.invoke('getAllUsers', {});
        
        // Timeout after 10 seconds to prevent hanging
        const timeout = (promise, ms) => 
          Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), ms))]);
        
        const rides = await timeout(ridesPromise, 10000);
        const usersResponse = await timeout(usersPromise, 10000);
        const users = usersResponse.data?.users || [];

        const completed = rides.filter((r) => r.status === "completed");
        const active = rides.filter((r) => ["accepted", "en_route", "arrived", "in_progress"].includes(r.status));
        const drivers = users.filter((u) => u.role === "driver" || u.vehicle_make);
        const avgRating = completed.filter((r) => r.customer_rating).reduce((s, r, _, a) => s + r.customer_rating / a.length, 0);

        const now = new Date();
        const thisMonth = now.getMonth();
        const thisYear = now.getFullYear();
        const lastMonthDate = new Date(thisYear, thisMonth - 1, 1);
        const lastMonth = lastMonthDate.getMonth();
        const lastMonthYear = lastMonthDate.getFullYear();

        const getRideFare = (r) => (r.final_fare || r.estimated_fare || 0);

        const thisMonthRides = completed.filter((r) => {
          const d = new Date(r.created_date);
          return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
        });
        const lastMonthRides = completed.filter((r) => {
          const d = new Date(r.created_date);
          return d.getMonth() === lastMonth && d.getFullYear() === lastMonthYear;
        });

        const thisMonthRevenue = thisMonthRides.reduce((s, r) => s + getRideFare(r), 0);
        const lastMonthRevenue = lastMonthRides.reduce((s, r) => s + getRideFare(r), 0);
        const totalRevenue = completed.reduce((s, r) => s + getRideFare(r), 0);

        const thisMonthName = now.toLocaleDateString("en-US", { month: "long" });
        const lastMonthName = lastMonthDate.toLocaleDateString("en-US", { month: "long" });

        setStats({
          totalRides: rides.length,
          completedRides: completed.length,
          activeRides: active.length,
          totalRevenue,
          thisMonthRevenue,
          lastMonthRevenue,
          thisMonthName,
          lastMonthName,
          combinedRevenue: thisMonthRevenue + lastMonthRevenue,
          totalUsers: users.length,
          totalDrivers: drivers.length,
          avgRating: avgRating.toFixed(1),
        });

        // Last 7 days chart
        const days = Array.from({ length: 7 }, (_, i) => {
          const d = new Date();
          d.setDate(d.getDate() - (6 - i));
          return d;
        });
        const data = days.map((d) => {
          const label = d.toLocaleDateString("en-US", { weekday: "short" });
          const dayRides = completed.filter((r) => {
            const rd = new Date(r.created_date);
            return rd.toDateString() === d.toDateString();
          });
          const revenue = dayRides.reduce((s, r) => s + (r.final_fare || r.estimated_fare || 0), 0);
          return { label, rides: dayRides.length, revenue: parseFloat(revenue.toFixed(2)) };
        });
        setChartData(data);
      } catch (error) {
        console.error("Failed to load admin stats:", error);
        // Set default stats on error so the page doesn't crash
        const fallbackNow = new Date();
        setStats({
          totalRides: 0,
          completedRides: 0,
          activeRides: 0,
          totalRevenue: 0,
          thisMonthRevenue: 0,
          lastMonthRevenue: 0,
          combinedRevenue: 0,
          thisMonthName: fallbackNow.toLocaleDateString("en-US", { month: "long" }),
          lastMonthName: new Date(fallbackNow.getFullYear(), fallbackNow.getMonth() - 1, 1).toLocaleDateString("en-US", { month: "long" }),
          totalUsers: 0,
          totalDrivers: 0,
          avgRating: "0.0",
        });
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin" /></div>;

  const cards = [
    { label: `${stats.thisMonthName} Revenue`, value: `$${stats.thisMonthRevenue.toFixed(2)}`, icon: DollarSign, color: "text-primary bg-primary/10", change: "This month" },
    { label: `${stats.lastMonthName} Revenue`, value: `$${stats.lastMonthRevenue.toFixed(2)}`, icon: DollarSign, color: "text-green-500 bg-green-500/10", change: "Last month" },
    { label: `${stats.lastMonthName} + ${stats.thisMonthName}`, value: `$${stats.combinedRevenue.toFixed(2)}`, icon: TrendingUp, color: "text-blue-500 bg-blue-500/10", change: "Combined total" },
    { label: "All-Time Revenue", value: `$${stats.totalRevenue.toFixed(2)}`, icon: DollarSign, color: "text-purple-500 bg-purple-500/10", change: "All completed rides" },
    { label: "Total Rides", value: stats.totalRides, icon: Car, color: "text-amber-500 bg-amber-500/10", change: `${stats.completedRides} completed` },
    { label: "Active Rides", value: stats.activeRides, icon: TrendingUp, color: "text-amber-500 bg-amber-500/10", change: "Right now" },
    { label: "Total Users", value: stats.totalUsers, icon: Users, color: "text-purple-500 bg-purple-500/10", change: `${stats.totalDrivers} drivers` },
    { label: "Avg Rating", value: stats.avgRating, icon: Star, color: "text-amber-500 bg-amber-500/10", change: "Driver score" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${card.color}`}>
                <card.icon className="w-5 h-5" />
              </div>
              <span className="text-xs text-muted-foreground">{card.change}</span>
            </div>
            <p className="text-2xl font-bold">{card.value}</p>
            <p className="text-muted-foreground text-sm mt-1">{card.label}</p>
          </div>
        ))}
      </div>

      {/* Revenue Chart */}
      <div className="bg-card border border-border rounded-2xl p-5">
        <h3 className="font-bold mb-4">Revenue — Last 7 Days</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={chartData}>
            <XAxis dataKey="label" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
            <Tooltip formatter={(v, n) => [n === "revenue" ? `$${v}` : v, n === "revenue" ? "Revenue" : "Rides"]} />
            <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Rides Chart */}
      <div className="bg-card border border-border rounded-2xl p-5">
        <h3 className="font-bold mb-4">Completed Rides — Last 7 Days</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={chartData}>
            <XAxis dataKey="label" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="rides" fill="hsl(var(--accent))" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}