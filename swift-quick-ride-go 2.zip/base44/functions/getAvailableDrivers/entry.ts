import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get all approved drivers who are online and not on break
    const allUsers = await base44.asServiceRole.entities.User.list();
    const availableDrivers = allUsers.filter((u) => 
      (u.role === 'driver' || u.vehicle_make) && 
      u.verification_status === 'approved' &&
      u.is_online === true &&
      u.on_break !== true
    );

    return Response.json({ 
      drivers: availableDrivers,
      count: availableDrivers.length
    });
  } catch (error) {
    console.error('Failed to get available drivers:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});