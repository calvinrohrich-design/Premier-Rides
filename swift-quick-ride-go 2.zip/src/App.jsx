import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

import SignUpPage from './pages/SignUpPage';
import LoginPage from './pages/LoginPage';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import WelcomePage from './pages/WelcomePage';
import DriverVerificationPage from './pages/DriverVerificationPage';
import CustomerHome from './pages/CustomerHome';
import CustomerRideTracking from './pages/CustomerRideTracking';
import DriverHome from './pages/DriverHome';
import DriverActiveRide from './pages/DriverActiveRide';
import CustomerRideHistory from './pages/CustomerRideHistory';
import DriverEarnings from './pages/DriverEarnings';
import DriverProfile from './pages/DriverProfile';
import AdminDashboard from './pages/AdminDashboard';
import ActiveDriversMap from './pages/ActiveDriversMap';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CustomerReservations from './pages/CustomerReservations';
import DriverReservations from './pages/DriverReservations';
import HelpSupport from './pages/HelpSupport';

// Sync system dark mode with .dark class
function DarkModeSync() {
  useEffect(() => {
    const apply = (dark) => {
      document.documentElement.classList.toggle("dark", dark);
    };
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    apply(mq.matches);
    const handler = (e) => apply(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);
  return null;
}

const pageVariants = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.2, ease: "easeOut" } },
  exit: { opacity: 0, y: -6, transition: { duration: 0.15, ease: "easeIn" } },
};

function AnimatedRoutes({ children }) {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div key={location.pathname} variants={pageVariants} initial="initial" animate="animate" exit="exit" style={{ minHeight: "100dvh" }}>
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-10 h-10 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </div>
          <div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      const path = window.location.pathname;
      const publicPaths = ["/", "/welcome", "/login", "/signup", "/forgot-password", "/reset-password"];
      if (publicPaths.includes(path)) {
        // Unauthenticated user on a public page — just render the routes normally
        return (
          <Routes>
            <Route path="/" element={<AnimatedRoutes><WelcomePage /></AnimatedRoutes>} />
            <Route path="/welcome" element={<AnimatedRoutes><WelcomePage /></AnimatedRoutes>} />
            <Route path="/signup" element={<AnimatedRoutes><SignUpPage /></AnimatedRoutes>} />
            <Route path="/login" element={<AnimatedRoutes><LoginPage /></AnimatedRoutes>} />
            <Route path="/forgot-password" element={<AnimatedRoutes><ForgotPassword /></AnimatedRoutes>} />
            <Route path="/reset-password" element={<AnimatedRoutes><ResetPassword /></AnimatedRoutes>} />
            <Route path="*" element={<AnimatedRoutes><WelcomePage /></AnimatedRoutes>} />
          </Routes>
        );
      }
      // Protected page — send back to welcome
      window.location.replace("/");
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/" element={<AnimatedRoutes><WelcomePage /></AnimatedRoutes>} />
      <Route path="/signup" element={<AnimatedRoutes><SignUpPage /></AnimatedRoutes>} />
      <Route path="/login" element={<AnimatedRoutes><LoginPage /></AnimatedRoutes>} />
      <Route path="/forgot-password" element={<AnimatedRoutes><ForgotPassword /></AnimatedRoutes>} />
      <Route path="/reset-password" element={<AnimatedRoutes><ResetPassword /></AnimatedRoutes>} />
      <Route path="/welcome" element={<AnimatedRoutes><WelcomePage /></AnimatedRoutes>} />
      <Route path="/driver-verification" element={<AnimatedRoutes><DriverVerificationPage /></AnimatedRoutes>} />
      <Route path="/customer-home" element={<AnimatedRoutes><CustomerHome /></AnimatedRoutes>} />
      <Route path="/customer-ride-tracking" element={<AnimatedRoutes><CustomerRideTracking /></AnimatedRoutes>} />
      <Route path="/driver-home" element={<AnimatedRoutes><DriverHome /></AnimatedRoutes>} />
      <Route path="/driver-active-ride" element={<AnimatedRoutes><DriverActiveRide /></AnimatedRoutes>} />
      <Route path="/customer-ride-history" element={<AnimatedRoutes><CustomerRideHistory /></AnimatedRoutes>} />
      <Route path="/driver-earnings" element={<AnimatedRoutes><DriverEarnings /></AnimatedRoutes>} />
      <Route path="/driver-profile" element={<AnimatedRoutes><DriverProfile /></AnimatedRoutes>} />
      <Route path="/admin" element={<AnimatedRoutes><AdminDashboard /></AnimatedRoutes>} />
      <Route path="/active-drivers" element={<AnimatedRoutes><ActiveDriversMap /></AnimatedRoutes>} />
      <Route path="/terms" element={<AnimatedRoutes><TermsOfService /></AnimatedRoutes>} />
      <Route path="/privacy" element={<AnimatedRoutes><PrivacyPolicy /></AnimatedRoutes>} />
      <Route path="/customer-reservations" element={<AnimatedRoutes><CustomerReservations /></AnimatedRoutes>} />
      <Route path="/driver-reservations" element={<AnimatedRoutes><DriverReservations /></AnimatedRoutes>} />
      <Route path="/help" element={<AnimatedRoutes><HelpSupport /></AnimatedRoutes>} />
      <Route path="*" element={<AnimatedRoutes><PageNotFound /></AnimatedRoutes>} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <DarkModeSync />
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;