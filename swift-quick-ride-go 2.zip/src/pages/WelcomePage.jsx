import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Car, User, ChevronRight, Shield, CheckCircle, Clock, Lock } from "lucide-react";
import { motion } from "framer-motion";

export default function WelcomePage() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.auth.isAuthenticated().then(async (authed) => {
      if (authed) {
        const me = await base44.auth.me();
        setUser(me);
        // Auto-route if coming back from driver login
        const params = new URLSearchParams(window.location.search);
        if (params.get("role") === "driver") {
          if (me?.verification_status === "approved") {
            window.location.replace("/driver-home");
          } else {
            window.location.replace("/driver-verification");
          }
          return;
        }
      }
      setLoading(false);
    });
  }, []);

  const isApprovedDriver = user?.verification_status === "approved";
  const isPendingDriver = user?.verification_status === "pending" || user?.verification_status === "submitted";
  const hasApplied = user?.user_type === "driver" || user?.user_type === "both";

  const handleCustomerClick = () => {
    if (user) {
      window.location.href = "/customer-home";
    } else {
      window.location.href = "/signup?role=customer";
    }
  };

  const handleDriverClick = () => {
    if (!user) {
      window.location.href = "/signup?role=driver";
      return;
    }
    // Approved drivers go straight to driver home
    if (user.verification_status === "approved") {
      window.location.href = "/driver-home";
      return;
    }
    // Users with no driver profile yet, or pending/submitted — go to verification
    window.location.href = "/driver-verification";
  };

  // Only disable for logged-in users who have already applied but aren't approved yet (pending)
  // Guests and non-driver users should always be able to tap to sign up / apply
  const driverButtonDisabled = false;
  const driverSubtext = () => {
    if (!user) return "Sign up and apply to drive";
    if (isApprovedDriver) return "You're approved — tap to start driving";
    if (isPendingDriver) return "Your application is under review";
    return "Apply to drive in your area";
  };
  const driverBadge = () => {
    if (isApprovedDriver) return { label: "Approved", color: "bg-green-500/20 text-green-400 border-green-500/30" };
    if (isPendingDriver) return { label: "Pending Review", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" };
    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <img src="https://media.base44.com/images/public/6a1ee3e497d6160b2982f0ba/7457cbdb8_generated_image.png" alt="Premier Rides" className="w-32 mx-auto mb-4" />
          <div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  const badge = driverBadge();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex flex-col">
      {/* Header */}
      <div className="pt-14 pb-4 px-6 flex items-center justify-between">
        <img src="https://media.base44.com/images/public/6a1ee3e497d6160b2982f0ba/7457cbdb8_generated_image.png" alt="Premier Rides" className="h-10 w-auto" />
        {user ? (
          <button
            onClick={() => base44.auth.logout("/login")}
            className="text-white/60 text-sm hover:text-white transition-colors"
          >
            Sign Out
          </button>
        ) : (
          <Link to="/login" className="text-primary text-sm font-semibold hover:text-primary/80 transition-colors">
            Sign In
          </Link>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <h1 className="text-4xl font-bold text-white mb-3">
            {user ? `Hey, ${user.full_name?.split(" ")[0] || "Friend"}!` : "Welcome to Premier Rides"}
          </h1>
          <p className="text-white/60 text-lg">
            {user ? "What would you like to do?" : "Fast, reliable rides in North Dakota"}
          </p>
        </motion.div>

        <div className="w-full max-w-md space-y-4">
          {/* Ride as Customer */}
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            onClick={handleCustomerClick}
            className="w-full flex items-center gap-4 bg-white/10 backdrop-blur-md border-2 border-white/30 rounded-2xl p-5 hover:bg-white/20 active:scale-95 transition-all shadow-lg"
          >
            <div className="w-14 h-14 bg-primary/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <User className="w-7 h-7 text-primary" />
            </div>
            <div className="text-left flex-1">
              <p className="font-bold text-white text-lg">Ride as Customer</p>
              <p className="text-white/60 text-sm">
                {user ? "Book a ride to your destination" : "Create an account or sign in"}
              </p>
            </div>
            <ChevronRight className="w-6 h-6 text-white/60 flex-shrink-0" />
          </motion.button>

          {/* Drive & Earn */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="relative"
          >
            <button
              onClick={handleDriverClick}
              disabled={driverButtonDisabled || loading}
              className={`w-full flex items-center gap-4 backdrop-blur-md border-2 rounded-2xl p-5 active:scale-95 transition-all shadow-lg text-left
                ${isApprovedDriver
                  ? "bg-primary/20 border-primary/50 hover:bg-primary/30"
                  : driverButtonDisabled
                  ? "bg-white/5 border-white/10 opacity-50 cursor-not-allowed"
                  : "bg-white/10 border-white/30 hover:bg-white/20"
                }`}
            >
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 ${isApprovedDriver ? "bg-primary/30" : "bg-white/10"}`}>
                {driverButtonDisabled ? (
                  <Lock className="w-7 h-7 text-white/40" />
                ) : (
                  <Car className="w-7 h-7 text-primary" />
                )}
              </div>
              <div className="text-left flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className={`font-bold text-lg ${driverButtonDisabled ? "text-white/40" : "text-white"}`}>
                    Drive & Earn
                  </p>
                  {badge && (
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${badge.color}`}>
                      {badge.label}
                    </span>
                  )}
                </div>
                <p className={`text-sm mt-0.5 ${driverButtonDisabled ? "text-white/30" : "text-white/60"}`}>
                  {driverSubtext()}
                </p>
              </div>
              {!driverButtonDisabled && <ChevronRight className="w-6 h-6 text-white/60 flex-shrink-0" />}
            </button>

            {/* Apply to Drive CTA — shown for logged-in non-driver users */}
            {user && !hasApplied && (
              <button
                onClick={() => window.location.href = "/driver-verification"}
                className="absolute inset-0 w-full h-full rounded-2xl"
                aria-label="Apply to drive"
              />
            )}
          </motion.div>

          {/* Apply to Drive prompt for customer-only accounts */}
          {user && !hasApplied && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-center text-white/40 text-xs"
            >
              Tap "Drive & Earn" to apply as a driver
            </motion.p>
          )}
        </div>
      </div>

      {/* Footer legal links */}
      <div className="pb-8 flex items-center justify-center gap-4 text-white/30 text-xs">
        <a href="/terms" className="hover:text-white/60 transition-colors">Terms of Service</a>
        <span>·</span>
        <a href="/privacy" className="hover:text-white/60 transition-colors">Privacy Policy</a>
      </div>
    </div>
  );
}