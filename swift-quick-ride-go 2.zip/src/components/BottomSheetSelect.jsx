import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronDown } from "lucide-react";

export default function BottomSheetSelect({ value, onChange, options, placeholder = "Select...", required = false }) {
  const [open, setOpen] = useState(false);

  const selected = options.find((o) => o.value === value);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={`w-full bg-secondary rounded-xl px-3 py-3 text-sm text-left flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-primary ${
          selected ? "text-foreground" : "text-muted-foreground"
        }`}
      >
        <span>{selected ? selected.label : placeholder}</span>
        <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-card rounded-t-3xl"
              style={{ paddingBottom: "env(safe-area-inset-bottom, 16px)" }}
            >
              <div className="w-10 h-1 bg-border rounded-full mx-auto mt-3 mb-4" />
              <p className="px-5 pb-3 font-bold text-base border-b border-border">{placeholder}</p>
              <div className="max-h-72 overflow-y-auto">
                {options.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => { onChange(opt.value); setOpen(false); }}
                    className="w-full flex items-center justify-between px-5 py-4 text-sm border-b border-border last:border-0 active:bg-secondary transition-colors"
                  >
                    <span className={value === opt.value ? "font-semibold text-primary" : "text-foreground"}>{opt.label}</span>
                    {value === opt.value && <Check className="w-4 h-4 text-primary" />}
                  </button>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}