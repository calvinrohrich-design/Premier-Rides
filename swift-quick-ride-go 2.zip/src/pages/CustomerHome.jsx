import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { MapPin, Navigation, Clock, Star, ChevronRight, User, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { calculateFare, fareBreakdown, FARE_RATES } from "@/utils/fareCalculator";
import { getAvailableRideTypes } from "@/utils/vehicleClassifier";
import AddressAutocomplete from "@/components/AddressAutocomplete";
import PaymentConfirmModal from "@/components/PaymentConfirmModal";
import BottomNav from "@/components/BottomNav";
import SavedPlacesEditor from "@/components/SavedPlacesEditor";

// Haversine formula — returns miles between two lat/lng points
function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 3958.8;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

const RIDE_TYPES = [
  { id: "economy", label: "Economy", emoji: "🚗", desc: "Affordable rides" },
  { id: "comfort", label: "Comfort", emoji: "🚙", desc: "Extra comfort" },
  { id: "premium", label: "Premium", emoji: "🏎️", desc: "Luxury experience" },
];

export default function CustomerHome() {
  const { user: authUser } = useAuth();
  const [user, setUser] = useState(null);
  const [pickup, setPickup] = useState("");
  const [dropoff, setDropoff] = useState("");
  const [pickupCoords, setPickupCoords] = useState(null);
  const [dropoffCoords, setDropoffCoords] = useState(null);
  const [rideType, setRideType] = useState("economy");
  const [step, setStep] = useState("input");
  const [loading, setLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);
  const [userCoords, setUserCoords] = useState(null);
  const [tripEstimate, setTripEstimate] = useState({
    durationMin: 15,
    distanceMiles: 3.0,
  });
  const [availableRideTypes, setAvailableRideTypes] = useState(["economy", "comfort", "premium"]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [savedCard, setSavedCard] = useState(null);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [pendingRide, setPendingRide] = useState(null);
  const [showSavedPlaces, setShowSavedPlaces] = useState(false);

  const loadAvailableRideTypes = () => {
    // Always show all ride types for customers
    setAvailableRideTypes(["economy", "comfort", "premium"]);
  };

  const handlePickupSelect = (location) => {
    setPickupCoords({ lat: location.lat, lng: location.lng });
    if (dropoffCoords) updateTripEstimate({ lat: location.lat, lng: location.lng }, dropoffCoords);
  };

  const handleDropoffSelect = (location) => {
    setDropoffCoords({ lat: location.lat, lng: location.lng });
    if (pickupCoords) updateTripEstimate(pickupCoords, { lat: location.lat, lng: location.lng });
  };

  // Use user from AuthContext immediately — no extra auth.me() call needed
  useEffect(() => {
    if (!authUser) return;
    setUser(authUser);
    if ((authUser.user_type === "driver" || authUser.user_type === "both") && authUser.verification_status !== "approved") {
      window.location.replace("/welcome");
      return;
    }
    // Non-blocking active ride check — page renders immediately while this resolves
    // Non-blocking — page renders immediately
    base44.entities.Ride.filter({ customer_id: authUser.id }).then((allRides) => {
      const activeRide = allRides.find((r) =>
        ["requested", "accepted", "en_route", "arrived", "in_progress"].includes(r.status)
      );
      if (activeRide) window.location.replace(`/customer-ride-tracking?rideId=${activeRide.id}`);
    }).catch(() => {});
  }, [authUser]);

  useEffect(() => {
    detectLocation();
    loadAvailableRideTypes();
  }, []);

  // Load saved card non-blocking when auth user is available
  useEffect(() => {
    if (!authUser) return;
    base44.functions.invoke("getSavedPaymentMethod", {})
      .then((res) => { if (res.data?.paymentMethod) setSavedCard(res.data.paymentMethod); })
      .catch(() => {});
  }, [authUser]);

  const detectLocation = () => {
    if (!navigator.geolocation) {
      // Fallback to Bismarck, ND if geolocation not available
      const fallbackCoords = { lat: 46.8083, lng: -100.7837 };
      setUserCoords([fallbackCoords.lat, fallbackCoords.lng]);
      setPickupCoords(fallbackCoords);
      setPickup("Bismarck, ND");
      return;
    }
    setLocationLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        setUserCoords([latitude, longitude]);
        setPickupCoords({ lat: latitude, lng: longitude });
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`
          );
          const data = await res.json();
          const address = data.address?.road
            ? `${data.address.road}${data.address.house_number ? " " + data.address.house_number : ""}${data.address.city ? ", " + data.address.city : ""}`
            : data.display_name?.split(",").slice(0, 2).join(",").trim()
            || `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
          setPickup(address);
        } catch {
          setPickup(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
        }
        setLocationLoading(false);
      },
      (error) => {
        console.error("Geolocation error:", error);
        // Fallback to Bismarck, ND on error
        const fallbackCoords = { lat: 46.8083, lng: -100.7837 };
        setUserCoords([fallbackCoords.lat, fallbackCoords.lng]);
        setPickupCoords(fallbackCoords);
        setPickup("Bismarck, ND");
        setLocationLoading(false);
      }
    );
  };

  const updateTripEstimate = async (pCoords, dCoords) => {
    if (!pCoords || !dCoords) return;
    try {
      const res = await fetch(
        `https://router.project-osrm.org/route/v1/driving/${pCoords.lng},${pCoords.lat};${dCoords.lng},${dCoords.lat}?overview=false`
      );
      const data = await res.json();
      if (data.routes && data.routes.length > 0) {
        const route = data.routes[0];
        const miles = parseFloat((route.distance * 0.000621371).toFixed(1)); // meters to miles
        const durationMin = Math.round(route.duration / 60); // seconds to minutes
        setTripEstimate({ durationMin, distanceMiles: miles });
      }
    } catch {
      // Fallback to Haversine if OSRM fails
      const miles = haversineDistance(pCoords.lat, pCoords.lng, dCoords.lat, dCoords.lng) * 0.75;
      const roundedMiles = parseFloat(miles.toFixed(1));
      const durationMin = Math.round((roundedMiles / 65) * 60 + 3);
      setTripEstimate({ durationMin, distanceMiles: roundedMiles });
    }
  };

  // Step 1: Show payment confirmation modal
  const handleRequestRide = () => {
    setShowPaymentModal(true);
  };

  // Step 2a: Use card on file — create ride then charge immediately
  const handleUseCardOnFile = async () => {
    setPaymentLoading(true);
    setShowPaymentModal(false); // Optimistic: close modal instantly
    const fare = calculateFare(tripEstimate.durationMin, tripEstimate.distanceMiles, rideType);
    const ride = await base44.entities.Ride.create({
      customer_id: user?.id,
      customer_name: user?.full_name,
      status: "requested",
      pickup_address: pickup,
      dropoff_address: dropoff,
      ride_type: rideType,
      estimated_fare: fare,
      estimated_duration_min: tripEstimate.durationMin,
      estimated_distance_miles: tripEstimate.distanceMiles,
      payment_status: "pending",
      ...(pickupCoords && { pickup_lat: pickupCoords.lat, pickup_lng: pickupCoords.lng }),
      ...(dropoffCoords && { dropoff_lat: dropoffCoords.lat, dropoff_lng: dropoffCoords.lng }),
    });

    // Optimistic: navigate to tracking immediately, charge in background
    window.location.href = `/customer-ride-tracking?rideId=${ride.id}`;
    base44.functions.invoke("chargeCardOnFile", { rideId: ride.id }).then((chargeRes) => {
      if (chargeRes.data?.requiresCheckout) {
        redirectToCheckout(ride.id, fare);
      }
    }).catch(() => {});
  };

  // Step 2b: Pay with new card via Stripe Checkout
  const handleNewCard = async () => {
    setPaymentLoading(true);
    const fare = calculateFare(tripEstimate.durationMin, tripEstimate.distanceMiles, rideType);
    const ride = await base44.entities.Ride.create({
      customer_id: user?.id,
      customer_name: user?.full_name,
      status: "requested",
      pickup_address: pickup,
      dropoff_address: dropoff,
      ride_type: rideType,
      estimated_fare: fare,
      estimated_duration_min: tripEstimate.durationMin,
      estimated_distance_miles: tripEstimate.distanceMiles,
      payment_status: "unpaid",
      ...(pickupCoords && { pickup_lat: pickupCoords.lat, pickup_lng: pickupCoords.lng }),
      ...(dropoffCoords && { dropoff_lat: dropoffCoords.lat, dropoff_lng: dropoffCoords.lng }),
    });
    await redirectToCheckout(ride.id, fare);
    setPaymentLoading(false);
  };

  const redirectToCheckout = async (rideId, fare) => {
    if (window.self !== window.top) {
      alert("Payment checkout only works from the published app. Redirecting to ride tracking instead.");
      window.location.href = `/customer-ride-tracking?rideId=${rideId}`;
      return;
    }
    const res = await base44.functions.invoke("createCheckoutSession", { rideId, amount: fare, rideType, pickupAddress: pickup, dropoffAddress: dropoff });
    if (res.data?.url) {
      window.location.href = res.data.url;
    } else {
      window.location.href = `/customer-ride-tracking?rideId=${rideId}`;
    }
  };

  const savedPlaces = [
    { label: "Home", address: user?.saved_home_address, lat: user?.saved_home_lat, lng: user?.saved_home_lng, icon: "🏠" },
    { label: "Work", address: user?.saved_work_address, lat: user?.saved_work_lat, lng: user?.saved_work_lng, icon: "🏢" },
    { label: "Airport", address: user?.saved_airport_address, lat: user?.saved_airport_lat, lng: user?.saved_airport_lng, icon: "✈️" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Map Placeholder */}
      <div className="relative flex-1 bg-gradient-to-br from-slate-800 to-slate-900 overflow-hidden" style={{ minHeight: "45vh" }}>
        <div className="absolute inset-0 opacity-20">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="absolute border border-white/20" style={{ left: `${i * 14}%`, top: 0, bottom: 0, width: 1 }} />
          ))}
          {[...Array(6)].map((_, i) => (
            <div key={i} className="absolute border border-white/20" style={{ top: `${i * 17}%`, left: 0, right: 0, height: 1 }} />
          ))}
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 2 }} className="w-6 h-6 bg-primary rounded-full shadow-lg shadow-primary/50" />
        </div>
        {/* Header bar — safe area aware for all iOS devices */}
        <div className="absolute top-0 left-0 right-0 z-30" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
          <div className="flex items-center justify-between px-4 py-3 bg-white shadow-md">
            <div className="flex items-center gap-3">
              <img src="https://media.base44.com/images/public/6a1ee3e497d6160b2982f0ba/7457cbdb8_generated_image.png" alt="Premier Rides" className="h-16 w-auto" />
              <div>
                <p className="text-gray-500 text-xs">Good {new Date().getHours() < 12 ? "morning" : "evening"}</p>
                <p className="text-gray-900 font-bold text-base">{user?.full_name?.split(" ")[0] || "Rider"} 👋</p>
              </div>
            </div>
            <button 
              onClick={() => setMenuOpen(true)} 
              className="w-11 h-11 bg-gray-100 rounded-xl flex items-center justify-center shadow border border-gray-200 active:scale-95 transition-transform"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <Menu className="w-6 h-6 text-gray-700" />
            </button>
          </div>
        </div>
        {/* Location pill */}
        <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2 bg-white/10 backdrop-blur-md rounded-2xl px-4 py-2.5">
          <Navigation className="w-4 h-4 text-primary flex-shrink-0" />
          <span className="text-white text-sm font-medium truncate">
            {locationLoading ? "Detecting location..." : pickup || "Current Location"}
          </span>
        </div>
      </div>

      {/* Bottom Sheet */}
      <div className="bg-background rounded-t-3xl -mt-6 relative z-10 flex-1 px-5 pt-6 pb-8">
        <div className="w-10 h-1 bg-border rounded-full mx-auto mb-6" />

        {step === "input" && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h2 className="text-xl font-bold mb-4">Where are you going?</h2>
            {/* Inputs */}
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  <AddressAutocomplete
                    placeholder="Current location"
                    value={pickup}
                    onChange={setPickup}
                    onSelect={handlePickupSelect}
                    icon={locationLoading ? "loader" : "pin"}
                    userCoords={userCoords}
                  />
                </div>
                {locationLoading ? (
                  <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin flex-shrink-0" />
                ) : (
                  <button onClick={detectLocation} className="flex-shrink-0 w-10 h-10 bg-secondary rounded-xl flex items-center justify-center" title="Use my location">
                    <Navigation className="w-4 h-4 text-primary" />
                  </button>
                )}
              </div>
              <AddressAutocomplete
                placeholder="Where to?"
                value={dropoff}
                onChange={setDropoff}
                onSelect={handleDropoffSelect}
                icon="destination"
                userCoords={userCoords}
              />
            </div>

            {/* Saved Places */}
            <div className="mb-5">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Saved Places</p>
                <button onClick={() => setShowSavedPlaces(true)} className="text-xs text-primary font-semibold">Edit</button>
              </div>
              <div className="space-y-1">
                {savedPlaces.map((place) => (
                  <button
                    key={place.label}
                    onClick={() => {
                      if (!place.address) { setShowSavedPlaces(true); return; }
                      setDropoff(place.address);
                      if (place.lat && place.lng) {
                        setDropoffCoords({ lat: place.lat, lng: place.lng });
                        if (pickupCoords) updateTripEstimate(pickupCoords, { lat: place.lat, lng: place.lng });
                      }
                    }}
                    className="w-full flex items-center gap-3 py-3 border-b border-border last:border-0"
                  >
                    <span className="text-xl">{place.icon}</span>
                    <div className="text-left flex-1 min-w-0">
                      <p className="font-semibold text-sm">{place.label}</p>
                      <p className="text-muted-foreground text-xs truncate">
                        {place.address || <span className="italic text-primary">Tap to set</span>}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto flex-shrink-0" />
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => { if (pickup && dropoff) setStep("confirm"); }}
              disabled={!pickup || !dropoff}
              className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-40"
            >
              See Ride Options
            </button>
          </motion.div>
        )}

        {step === "confirm" && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center gap-3 mb-5">
              <button onClick={() => setStep("input")} className="w-9 h-9 bg-secondary rounded-xl flex items-center justify-center">
                <X className="w-4 h-4" />
              </button>
              <div className="flex-1">
                <h2 className="text-xl font-bold">Choose Ride</h2>
                {availableRideTypes.length < 3 && (
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {availableRideTypes.length === 1 ? "Only economy available" : `${availableRideTypes.length} ride types available`}
                  </p>
                )}
              </div>
            </div>

            {/* Route summary */}
            <div className="bg-secondary rounded-2xl p-4 mb-4">
              <div className="flex items-start gap-3">
                <div className="flex flex-col items-center gap-1 mt-1">
                  <div className="w-2.5 h-2.5 bg-primary rounded-full" />
                  <div className="w-0.5 h-8 bg-border" />
                  <MapPin className="w-3 h-3 text-destructive" />
                </div>
                <div className="flex-1 space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground">FROM</p>
                    <p className="font-semibold text-sm">{pickup}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">TO</p>
                    <p className="font-semibold text-sm">{dropoff}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Trip estimate summary */}
            <div className="flex items-center gap-3 mb-4 bg-secondary rounded-xl px-4 py-2.5 text-sm text-muted-foreground">
              <Clock className="w-4 h-4 flex-shrink-0" />
              <span>~{tripEstimate.durationMin} min</span>
              <span className="text-border">·</span>
              <Navigation className="w-4 h-4 flex-shrink-0" />
              <span>{tripEstimate.distanceMiles} mi</span>
            </div>

            {/* Ride types */}
            <div className="space-y-3 mb-5">
              {RIDE_TYPES.filter(type => availableRideTypes.includes(type.id)).map((type) => {
                const bd = fareBreakdown(tripEstimate.durationMin, tripEstimate.distanceMiles, type.id);
                const isSelected = rideType === type.id;
                return (
                  <button
                    key={type.id}
                    onClick={() => setRideType(type.id)}
                    className={`w-full p-4 rounded-2xl border-2 transition-all text-left ${
                      isSelected ? "border-primary bg-primary/5" : "border-border bg-card"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{type.emoji}</span>
                      <div className="flex-1">
                        <p className="font-bold">{type.label}</p>
                        <p className="text-muted-foreground text-xs">{type.desc} · ~{tripEstimate.durationMin} min</p>
                      </div>
                      <p className="font-bold text-lg">${bd.total}</p>
                    </div>
                    {isSelected && (
                      <div className="mt-3 pt-3 border-t border-primary/20">
                        <div className="grid grid-cols-3 gap-2 text-xs text-center">
                          <div>
                            <p className="text-muted-foreground">Base charge</p>
                            <p className="font-semibold">${bd.base}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">{tripEstimate.durationMin} min × ${FARE_RATES.PER_MINUTE.toFixed(2)}/min</p>
                            <p className="font-semibold">+${bd.time}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">{tripEstimate.distanceMiles} mi × ${FARE_RATES.PER_MILE.toFixed(2)}/mi</p>
                            <p className="font-semibold">+${bd.distance}</p>
                          </div>
                        </div>
                        {bd.multiplier > 1 && (
                          <p className="text-xs text-muted-foreground text-center mt-2">
                            {type.label} rate: ×{bd.multiplier} applied to subtotal (${bd.subtotal})
                          </p>
                        )}
                        <p className="text-[11px] text-muted-foreground text-center mt-2">
                          Estimated total fare: <strong className="text-foreground">${bd.total}</strong> — final fare based on actual trip time and distance
                        </p>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Damage Policy Notice */}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 flex gap-2 items-start">
              <span className="text-amber-500 text-base flex-shrink-0">⚠️</span>
              <p className="text-xs text-amber-800 leading-relaxed">
                <strong>Damage Policy:</strong> Passengers are responsible for any damage caused to the driver's vehicle. A minimum fee of <strong>$300.00</strong> will be charged for any damage.
              </p>
            </div>

            <button
              onClick={handleRequestRide}
              disabled={loading}
              className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform"
            >
              {`Request & Pay · $${fareBreakdown(tripEstimate.durationMin, tripEstimate.distanceMiles, rideType).total}`}
            </button>
          </motion.div>
        )}
      </div>

      {/* Payment Confirmation Modal */}
      <AnimatePresence>
        {showPaymentModal && (
          <PaymentConfirmModal
            fare={calculateFare(tripEstimate.durationMin, tripEstimate.distanceMiles, rideType)}
            rideType={rideType}
            savedCard={savedCard}
            onUseCard={handleUseCardOnFile}
            onNewCard={handleNewCard}
            onCancel={() => setShowPaymentModal(false)}
            loading={paymentLoading}
          />
        )}
      </AnimatePresence>

      {/* Side Menu */}
      <AnimatePresence>
        {menuOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 z-40" onClick={() => setMenuOpen(false)} />
            <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "spring", damping: 25 }} className="fixed right-0 top-0 bottom-0 w-72 bg-card z-50 p-6 pt-14">
              <button onClick={() => setMenuOpen(false)} className="absolute top-12 right-4 w-9 h-9 bg-secondary rounded-xl flex items-center justify-center">
                <X className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-3 mb-8">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="font-bold">{user?.full_name || "User"}</p>
                  <div className="flex items-center gap-1"><Star className="w-3 h-3 text-amber-500 fill-amber-500" /><span className="text-sm text-muted-foreground">{user?.rating || "5.0"}</span></div>
                </div>
              </div>
              {(user?.user_type === "both" || user?.user_type === "driver" || user?.verification_status || user?.vehicle_type) && (
                <button onClick={() => window.location.href = "/"} className="w-full flex items-center gap-3 py-4 border-b border-border text-left">
                  <span className="text-xl">🚗</span>
                  <span className="font-medium">Switch to Driver</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto" />
                </button>
              )}
              {(user?.role === "admin") && (
                <button onClick={() => window.location.href = "/admin"} className="w-full flex items-center gap-3 py-4 border-b border-border text-left">
                  <span className="text-xl">👨‍💼</span>
                  <span className="font-medium">Admin Dashboard</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto" />
                </button>
              )}
              {[["Reservations", "📅", "/customer-reservations"], ["Ride History", "🕓", "/customer-ride-history"], ["Payment Methods", "💳", null], ["Promotions", "🎁", null], ["Help & Support", "💬", "/help"], ["Terms of Service", "📄", "/terms"], ["Privacy Policy", "🔒", "/privacy"]].map(([label, emoji, href]) => (
                <button
                  key={label}
                  onClick={() => href && (window.location.href = href)}
                  className="w-full flex items-center gap-3 py-4 border-b border-border text-left"
                >
                  <span className="text-xl">{emoji}</span>
                  <span className="font-medium">{label}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto" />
                </button>
              ))}
              <button onClick={() => base44.auth.logout("/login")} className="w-full mt-6 py-3 text-destructive font-semibold text-center">Sign Out</button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
      <BottomNav variant="customer" />

      {/* Saved Places Editor */}
      <AnimatePresence>
        {showSavedPlaces && (
          <SavedPlacesEditor
            user={user}
            onClose={() => setShowSavedPlaces(false)}
            onSaved={(updatedUser) => setUser(updatedUser)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}