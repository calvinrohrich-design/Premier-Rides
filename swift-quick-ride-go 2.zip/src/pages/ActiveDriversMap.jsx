import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { ArrowLeft, RefreshCw, Users } from "lucide-react";

// Fix default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const driverIcon = L.divIcon({
  html: `<div style="font-size:28px;line-height:1;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.4));">🚗</div>`,
  className: "",
  iconSize: [36, 36],
  iconAnchor: [18, 18],
});

const busyIcon = L.divIcon({
  html: `<div style="font-size:28px;line-height:1;opacity:0.6;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.3));">🚕</div>`,
  className: "",
  iconSize: [36, 36],
  iconAnchor: [18, 18],
});

export default function ActiveDriversMap() {
  const [drivers, setDrivers] = useState([]);
  const [activeRides, setActiveRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const loadData = async () => {
    setLoading(true);
    // Get all users who are online (drivers)
    const users = await base44.entities.User.list();
    const onlineDrivers = users.filter((u) => u.is_online);

    setDrivers(onlineDrivers);

    // Get active rides to see which drivers are busy
    const rides = await base44.entities.Ride.filter({ status: "in_progress" });
    setActiveRides(rides);

    setLastRefresh(new Date());
    setLoading(false);
  };

  useEffect(() => {
    loadData();
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  // Get drivers with known coordinates from active rides
  const driversOnMap = activeRides.filter((r) => r.driver_lat && r.driver_lng);
  const busyDriverIds = new Set(activeRides.map((r) => r.driver_id));
  const availableDrivers = drivers.filter((d) => !busyDriverIds.has(d.id) && !d.on_break);
  const onBreakDrivers = drivers.filter((d) => d.on_break);

  const defaultCenter = [46.8083, -100.7837]; // Bismarck, ND

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-foreground pt-12 pb-5 px-5 flex items-center gap-3">
        <button
          onClick={() => window.history.back()}
          className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="flex-1">
          <p className="text-white font-bold text-lg">Active Drivers</p>
          <p className="text-white/60 text-xs">
            Last updated {lastRefresh.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
        <button
          onClick={loadData}
          disabled={loading}
          className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center"
        >
          <RefreshCw className={`w-5 h-5 text-white ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Stats bar */}
      <div className="flex items-center gap-4 px-5 py-3 bg-card border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 bg-primary rounded-full animate-pulse" />
          <span className="text-sm font-semibold">{drivers.length} Online</span>
        </div>
        <div className="w-px h-4 bg-border" />
        <div className="flex items-center gap-2">
          <span className="text-lg">🚕</span>
          <span className="text-sm font-semibold">{busyDriverIds.size} On a Ride</span>
        </div>
        <div className="w-px h-4 bg-border" />
        <div className="flex items-center gap-2">
          <span className="text-lg">🟢</span>
          <span className="text-sm font-semibold">{availableDrivers.length} Available</span>
        </div>
        <div className="w-px h-4 bg-border" />
        <div className="flex items-center gap-2">
          <span className="text-lg">☕</span>
          <span className="text-sm font-semibold">{onBreakDrivers.length} On Break</span>
        </div>
      </div>

      {/* Map */}
      <div className="flex-1" style={{ minHeight: "55vh" }}>
        <MapContainer
          center={defaultCenter}
          zoom={12}
          style={{ height: "100%", width: "100%", minHeight: "55vh" }}
          zoomControl={true}
          scrollWheelZoom={true}
        >
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://carto.com/">CARTO</a>'
          />

          {/* Drivers with live location from active rides */}
          {driversOnMap.map((ride) => (
            <Marker
              key={ride.id}
              position={[ride.driver_lat, ride.driver_lng]}
              icon={busyIcon}
            >
              <Popup>
                <div className="text-sm">
                  <p className="font-bold">{ride.driver_name}</p>
                  <p className="text-gray-500">On a ride</p>
                  <p className="text-xs mt-1">📍 {ride.pickup_address}</p>
                  <p className="text-xs">→ {ride.dropoff_address}</p>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* Driver List */}
      <div className="bg-background px-5 pt-4 pb-8">
        <div className="flex items-center gap-2 mb-3">
          <Users className="w-4 h-4 text-muted-foreground" />
          <p className="font-bold text-sm">Online Drivers ({drivers.length})</p>
        </div>

        {drivers.length === 0 && !loading && (
          <div className="text-center py-8 text-muted-foreground">
            <span className="text-4xl block mb-2">🚗</span>
            <p className="font-medium">No drivers online right now</p>
          </div>
        )}

        <div className="space-y-2 max-h-48 overflow-y-auto">
          {drivers.map((driver) => {
            const isBusy = busyDriverIds.has(driver.id);
            return (
              <div key={driver.id} className="flex items-center gap-3 bg-card border border-border rounded-2xl p-3">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-xl">
                  👨
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{driver.full_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {driver.vehicle_make} {driver.vehicle_model} · {driver.license_plate || "—"}
                  </p>
                </div>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                  isBusy
                    ? "bg-amber-100 text-amber-700"
                    : driver.on_break
                    ? "bg-orange-100 text-orange-700"
                    : "bg-green-100 text-green-700"
                }`}>
                  {isBusy ? "On Ride" : driver.on_break ? "☕ Break" : "Available"}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}