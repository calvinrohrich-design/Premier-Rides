import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Star, ChevronLeft, Navigation, Shield, Car, Award, Camera, Trash2 } from "lucide-react";
import { motion } from "framer-motion";

function StarRow({ rating, size = "w-4 h-4" }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          className={`${size} transition-colors ${s <= Math.round(rating) ? "text-amber-500 fill-amber-500" : "text-border"}`}
        />
      ))}
    </div>
  );
}

function RatingBar({ label, count, total }) {
  const pct = total > 0 ? (count / total) * 100 : 0;
  return (
    <div className="flex items-center gap-3 text-sm">
      <span className="w-3 text-muted-foreground text-right">{label}</span>
      <Star className="w-3 h-3 text-amber-500 fill-amber-500 flex-shrink-0" />
      <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
        <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
      </div>
      <span className="w-5 text-muted-foreground text-right">{count}</span>
    </div>
  );
}

export default function DriverProfile() {
  const [driver, setDriver] = useState(null);
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Support viewing any driver via ?driverId=... or default to current user
  const driverIdParam = new URLSearchParams(window.location.search).get("driverId");

  useEffect(() => {
    const load = async () => {
      let driverUser;
      if (driverIdParam) {
        const users = await base44.entities.User.filter({ id: driverIdParam });
        driverUser = users[0];
      } else {
        driverUser = await base44.auth.me();
      }
      setDriver(driverUser);

      if (driverUser) {
        const completedRides = await base44.entities.Ride.filter(
          { driver_id: driverUser.id, status: "completed" },
          "-created_date",
          50
        );
        setRides(completedRides);
      }
      setLoading(false);
    };
    load();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const ratedRides = rides.filter((r) => r.customer_rating);
  const avgRating = ratedRides.length
    ? ratedRides.reduce((sum, r) => sum + r.customer_rating, 0) / ratedRides.length
    : driver?.rating || 5.0;

  const ratingCounts = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: ratedRides.filter((r) => Math.round(r.customer_rating) === star).length,
  }));

  const isOwnProfile = !driverIdParam;
  const backHref = isOwnProfile ? "/driver-home" : "/customer-home";

  const handleDeleteAccount = async () => {
    setDeleteLoading(true);
    await base44.auth.updateMe({ is_online: false, account_deleted: true, email: `deleted_${Date.now()}@deleted.invalid` });
    base44.auth.logout("/login");
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      await base44.auth.updateMe({ profile_photo_url: response.file_url });
      setDriver((prev) => ({ ...prev, profile_photo_url: response.file_url }));
    } catch (error) {
      console.error('Failed to upload photo:', error);
    }
    setUploading(false);
  };

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <div className="pb-6 px-5 bg-card border-b border-border" style={{ paddingTop: 'max(3rem, env(safe-area-inset-top, 3rem))' }}>
        <button onClick={() => window.location.href = backHref} className="flex items-center gap-2 text-muted-foreground mb-4">
          <ChevronLeft className="w-5 h-5" />
          <span className="text-sm">Back</span>
        </button>

        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center text-4xl border-2 border-primary/40 overflow-hidden">
              {driver?.profile_photo_url ? (
                <img src={driver.profile_photo_url} alt="" className="w-full h-full rounded-full object-cover" />
              ) : "🧑‍✈️"}
            </div>
            {isOwnProfile && (
              <label className="absolute bottom-0 right-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center cursor-pointer hover:bg-primary/90 transition-colors border-2 border-card">
                <Camera className="w-4 h-4 text-white" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                  disabled={uploading}
                />
              </label>
            )}
            {uploading && (
              <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              </div>
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{driver?.full_name || "Driver"}</h1>
            <div className="flex items-center gap-2 mt-1">
              <StarRow rating={avgRating} size="w-4 h-4" />
              <span className="font-bold text-foreground">{avgRating.toFixed(1)}</span>
            </div>
            <p className="text-muted-foreground text-sm mt-0.5">{ratedRides.length} ratings · {rides.length} trips</p>
          </div>
        </div>
      </div>

      <div className="px-5 space-y-5 -mt-4">
        {/* Trust Badges */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { icon: Shield, label: "Verified", color: "text-primary bg-primary/10", show: driver?.verification_status === "approved" },
            { icon: Award, label: `${rides.length} Trips`, color: "text-blue-500 bg-blue-500/10", show: true },
            { icon: Star, label: `${avgRating.toFixed(1)} Stars`, color: "text-amber-500 bg-amber-500/10", show: true },
          ].map((b) => b.show && (
            <div key={b.label} className="bg-card border border-border rounded-2xl p-3 text-center">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center mx-auto mb-2 ${b.color}`}>
                <b.icon className="w-4 h-4" />
              </div>
              <p className="font-semibold text-sm">{b.label}</p>
            </div>
          ))}
        </div>

        {/* Vehicle */}
        {(driver?.vehicle_make || driver?.vehicle_model) && (
          <div className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
              <Car className="w-5 h-5 text-muted-foreground" />
            </div>
            <div>
              <p className="font-semibold">
                {[driver.vehicle_color, driver.vehicle_make, driver.vehicle_model, driver.vehicle_year].filter(Boolean).join(" ")}
              </p>
              {driver?.license_plate && (
                <p className="text-sm text-muted-foreground">Plate: <span className="font-bold text-foreground">{driver.license_plate}</span></p>
              )}
            </div>
          </div>
        )}

        {/* Rating Breakdown */}
        {ratedRides.length > 0 && (
          <div className="bg-card border border-border rounded-2xl p-5">
            <p className="font-bold mb-4">Rating Breakdown</p>
            <div className="flex items-center gap-5 mb-5">
              <div className="text-center">
                <p className="text-5xl font-bold">{avgRating.toFixed(1)}</p>
                <StarRow rating={avgRating} size="w-4 h-4" />
                <p className="text-xs text-muted-foreground mt-1">{ratedRides.length} reviews</p>
              </div>
              <div className="flex-1 space-y-2">
                {ratingCounts.map(({ star, count }) => (
                  <RatingBar key={star} label={star} count={count} total={ratedRides.length} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Recent Reviews */}
        {ratedRides.length > 0 && (
          <div>
            <p className="font-bold mb-3">Recent Reviews</p>
            <div className="space-y-3">
              {ratedRides.slice(0, 8).map((ride, i) => (
                <motion.div
                  key={ride.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="bg-card border border-border rounded-2xl p-4"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center text-sm">
                        👤
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{ride.customer_name || "Rider"}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(ride.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </p>
                      </div>
                    </div>
                    <StarRow rating={ride.customer_rating} size="w-3.5 h-3.5" />
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Navigation className="w-3 h-3" />
                    <span className="truncate">{ride.pickup_address} → {ride.dropoff_address}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {ratedRides.length === 0 && (
          <div className="text-center py-10">
            <span className="text-4xl block mb-3">⭐</span>
            <p className="font-bold">No reviews yet</p>
            <p className="text-muted-foreground text-sm mt-1">Reviews will appear here after completed rides</p>
          </div>
        )}

        {/* Delete Account — only shown on own profile */}
        {isOwnProfile && (
          <div className="border border-destructive/30 rounded-2xl p-4 mt-4">
            <p className="font-bold text-destructive text-sm mb-1">Delete Account</p>
            <p className="text-muted-foreground text-xs mb-3">Permanently remove your account and all associated data. This action cannot be undone.</p>
            {!showDeleteConfirm ? (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="flex items-center gap-2 text-destructive font-semibold text-sm border border-destructive/40 px-4 py-2.5 rounded-xl active:scale-95 transition-transform"
              >
                <Trash2 className="w-4 h-4" />
                Delete My Account
              </button>
            ) : (
              <div className="space-y-2">
                <p className="text-sm font-semibold text-destructive">Are you sure? This cannot be undone.</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="flex-1 border border-border py-2.5 rounded-xl text-sm font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteAccount}
                    disabled={deleteLoading}
                    className="flex-1 bg-destructive text-white py-2.5 rounded-xl text-sm font-semibold active:scale-95 transition-transform disabled:opacity-60"
                  >
                    {deleteLoading ? "Deleting..." : "Yes, Delete"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}