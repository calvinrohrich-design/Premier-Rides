import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const { place_id } = await req.json();

    if (!place_id) {
      return Response.json({ error: "Missing place_id" }, { status: 400 });
    }

    const apiKey = Deno.env.get("GOOGLE_MAPS_API_KEY");
    const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(place_id)}&fields=geometry,formatted_address,name&key=${apiKey}`;

    const res = await fetch(url);
    const data = await res.json();

    return Response.json({ result: data.result || null });
  } catch (error) {
    console.error("placeDetails error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});