// Vehicle classification based on year, make, and model
// Returns: "economy", "comfort", or "premium"

const PREMIUM_BRANDS = [
  "mercedes-benz", "mercedes", "bmw", "audi", "lexus", "porsche", "maserati", 
  "bentley", "rolls-royce", "aston martin", "jaguar", "land rover", "cadillac",
  "tesla", "genesis", "infiniti", "acura"
];

const COMFORT_BRANDS = [
  "buick", "chrysler", "lincoln", "volvo", "subaru", "mazda", "volkswagen",
  "honda", "toyota", "nissan", "hyundai", "kia", "ford", "chevrolet", "dodge",
  "jeep", "ram", "gmc", "mitsubishi"
];

const PREMIUM_MODELS = [
  "model s", "model x", "7 series", "s-class", "a8", "ls", "panamera",
  "continental", "ghost", "phantom", "db11", "f-type", "ct6", "escala"
];

const COMFORT_MODELS = [
  "accord", "camry", "altima", "sonata", "malibu", "fusion", "passat",
  "legacy", "mazda6", "avalon", "espnge", "300", "lacrosse", "impala"
];

export function classifyVehicle(year, make, model) {
  if (!make || !model) return "economy";
  
  const yearNum = parseInt(year);
  const makeLower = make.toLowerCase().trim();
  const modelLower = model.toLowerCase().trim();
  
  // Check for premium models first
  if (PREMIUM_MODELS.some(m => modelLower.includes(m))) {
    return "premium";
  }
  
  // Check for premium brands
  if (PREMIUM_BRANDS.some(b => makeLower.includes(b))) {
    // Premium brands from 2018+ are premium, older are comfort
    return yearNum >= 2018 ? "premium" : "comfort";
  }
  
  // Check for comfort models
  if (COMFORT_MODELS.some(m => modelLower.includes(m))) {
    return yearNum >= 2015 ? "comfort" : "economy";
  }
  
  // Check for comfort brands
  if (COMFORT_BRANDS.some(b => makeLower.includes(b))) {
    return yearNum >= 2015 ? "comfort" : "economy";
  }
  
  // Default to economy
  return "economy";
}

export function getAvailableRideTypes(vehicleType) {
  // Drivers can only offer rides at their vehicle level or below
  if (vehicleType === "premium") return ["economy", "comfort", "premium"];
  if (vehicleType === "comfort") return ["economy", "comfort"];
  return ["economy"];
}