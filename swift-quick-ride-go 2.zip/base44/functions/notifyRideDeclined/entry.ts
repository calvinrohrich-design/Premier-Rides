import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { rideId } = await req.json();

    if (!rideId) {
      return Response.json({ error: 'Missing rideId' }, { status: 400 });
    }

    const rides = await base44.asServiceRole.entities.Ride.filter({ id: rideId });
    if (!rides.length) {
      return Response.json({ error: 'Ride not found' }, { status: 404 });
    }
    const ride = rides[0];

    // Only notify if ride is still waiting for a driver
    if (ride.status !== 'requested') {
      return Response.json({ skipped: true, reason: 'Ride no longer in requested state' });
    }

    // Post a system message in the ride chat so the customer sees it live
    await base44.asServiceRole.entities.RideMessage.create({
      ride_id: rideId,
      sender_id: 'system',
      sender_name: 'EW Premier Rides',
      sender_role: 'driver',
      content: '🔍 A driver was unavailable — we\'re still searching for the nearest available driver for you. Please hang tight!',
    });

    return Response.json({ sent: true });
  } catch (error) {
    console.error('notifyRideDeclined error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});