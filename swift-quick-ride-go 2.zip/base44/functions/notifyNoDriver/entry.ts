import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const isAuth = await base44.auth.isAuthenticated();
        if (!isAuth) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const payload = await req.json();
        const ride = payload?.data;
        if (!ride || ride.status !== 'requested') {
            return Response.json({ skipped: true, reason: 'No requested ride in payload' });
        }

        // Check if any approved driver is currently online (query directly so no driver is missed)
        const users = await base44.asServiceRole.entities.User.filter(
            { verification_status: 'approved', is_online: true },
            '-created_date',
            500
        );
        const onlineDrivers = users.filter((u) => !u.on_break);

        if (onlineDrivers.length > 0) {
            return Response.json({ skipped: true, reason: `${onlineDrivers.length} driver(s) online` });
        }

        await base44.asServiceRole.integrations.Core.SendEmail({
            to: 'Eric_wald83@hotmail.com',
            from_name: 'EW Premier Rides',
            subject: '🚨 Ride Request — No Drivers Online!',
            body: `Hey Eric,

A new ride was just requested but NO drivers are currently online.

Customer: ${ride.customer_name || 'Unknown'}
Pickup: ${ride.pickup_address}
Dropoff: ${ride.dropoff_address}
Estimated fare: $${ride.estimated_fare?.toFixed(2) || 'N/A'}

Log in and go online to accept this ride before the customer cancels.

— EW Premier Rides`
        });

        return Response.json({ sent: true });
    } catch (error) {
        console.error('notifyNoDriver error:', error.message);
        return Response.json({ error: error.message }, { status: 500 });
    }
});