import { motion } from "framer-motion";

export default function NoDriverModal({ onKeepWaiting, onCancel }) {
  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 bg-black/60 z-40" />
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        className="fixed bottom-0 left-0 right-0 bg-card rounded-t-3xl z-50 p-6 pb-10"
      >
        <div className="text-center mb-6">
          <span className="text-5xl">😕</span>
          <h2 className="text-2xl font-bold mt-3">No Drivers Available</h2>
          <p className="text-muted-foreground mt-2">
            We haven't found a driver yet. You can keep waiting or cancel your request — you won't be charged for a cancelled ride.
          </p>
        </div>
        <button
          onClick={onKeepWaiting}
          className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform mb-3"
        >
          Keep Waiting (5 more min)
        </button>
        <button
          onClick={onCancel}
          className="w-full border-2 border-destructive text-destructive py-4 rounded-2xl font-bold active:scale-95 transition-transform"
        >
          Cancel Ride
        </button>
      </motion.div>
    </>
  );
}