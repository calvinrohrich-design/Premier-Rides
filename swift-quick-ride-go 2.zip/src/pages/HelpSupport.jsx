import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { MessageCircle, Mail, ChevronLeft, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import BottomSheetSelect from "@/components/BottomSheetSelect";

const SUBJECT_OPTIONS = [
  { value: "Ride Issue", label: "Ride Issue" },
  { value: "Payment / Billing", label: "Payment / Billing" },
  { value: "Driver Concern", label: "Driver Concern" },
  { value: "Account Help", label: "Account Help" },
  { value: "Lost Item", label: "Lost Item" },
  { value: "Safety Concern", label: "Safety Concern" },
  { value: "Other", label: "Other" },
];

const FAQS = [
  {
    q: "How do I cancel a ride?",
    a: "You can cancel a ride from the ride tracking screen by tapping 'Cancel Ride'. Cancellations are free if done before a driver is assigned."
  },
  {
    q: "How do I get a receipt for my ride?",
    a: "A receipt is automatically emailed to you when your ride is completed. Check your inbox (and spam folder)."
  },
  {
    q: "How are fares calculated?",
    a: "Fares are based on a base charge plus per-minute and per-mile rates. The estimated fare is shown before you book."
  },
  {
    q: "What is the damage policy?",
    a: "Passengers are responsible for any damage caused to the driver's vehicle. A minimum fee of $300 will be charged for any damage."
  },
  {
    q: "How do I become a driver?",
    a: "Tap 'Become a Driver' on the welcome screen and complete the driver verification process including uploading your license and insurance."
  },
  {
    q: "When do drivers get paid?",
    a: "Drivers earn 70% of each fare plus 100% of any tips. Contact support for questions about your earnings."
  },
  {
    q: "How do I update my payment method?",
    a: "Payment methods are managed during the checkout process. Contact support if you need help with a billing issue."
  },
];

export default function HelpSupport() {
  const [user, setUser] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u) {
        setUser(u);
        setName(u.full_name || "");
        setEmail(u.email || "");
      }
    }).catch(() => {});
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !email || !subject || !message) return;
    setLoading(true);
    await base44.integrations.Core.SendEmail({
      to: "admin@ewpremierrides.com",
      subject: `[Support] ${subject}`,
      body: `From: ${name} <${email}>\n\n${message}`,
    });
    // Send confirmation to user
    await base44.integrations.Core.SendEmail({
      to: email,
      from_name: "EW Premier Rides Support",
      subject: "We received your message",
      body: `Hi ${name},\n\nThank you for contacting EW Premier Rides. We've received your message and will get back to you shortly.\n\nYour message:\n"${message}"\n\nBest,\nEW Premier Rides Team`,
    });
    setLoading(false);
    setSent(true);
  };

  const goBack = () => window.history.back();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="pb-6 px-5 bg-card border-b border-border" style={{ paddingTop: 'max(3rem, env(safe-area-inset-top, 3rem))' }}>
        <div className="flex items-center gap-3 mb-2">
          <button onClick={goBack} className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </button>
          <div>
            <p className="text-muted-foreground text-xs">EW Premier Rides</p>
            <p className="text-foreground font-bold text-xl">Help & Support</p>
          </div>
        </div>
      </div>

      <div className="px-5 py-6 space-y-6 max-w-lg mx-auto" style={{ paddingBottom: 'max(2rem, env(safe-area-inset-bottom, 2rem))' }}>

        {/* Contact Info */}
        <div className="grid grid-cols-2 gap-3">
          <a href="mailto:admin@ewpremierrides.com" className="bg-card border border-border rounded-2xl p-4 flex flex-col items-center gap-2 active:bg-secondary transition-colors">
            <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
              <Mail className="w-5 h-5 text-primary" />
            </div>
            <p className="font-semibold text-sm text-center">Email Us</p>
            <p className="text-xs text-muted-foreground text-center">admin@ewpremierrides.com</p>
          </a>
          <div className="bg-card border border-border rounded-2xl p-4 flex flex-col items-center gap-2">
            <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-blue-500" />
            </div>
            <p className="font-semibold text-sm text-center">Response Time</p>
            <p className="text-xs text-muted-foreground text-center">Within 24 hours</p>
          </div>
        </div>

        {/* FAQs */}
        <div>
          <h2 className="font-bold text-lg mb-3">Frequently Asked Questions</h2>
          <div className="space-y-2">
            {FAQS.map((faq, i) => (
              <div key={i} className="bg-card border border-border rounded-2xl overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full text-left px-4 py-4 flex items-center justify-between gap-3"
                >
                  <p className="font-medium text-sm flex-1">{faq.q}</p>
                  <span className={`text-primary font-bold text-lg transition-transform ${openFaq === i ? "rotate-45" : ""}`}>+</span>
                </button>
                <AnimatePresence>
                  {openFaq === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <p className="px-4 pb-4 text-sm text-muted-foreground">{faq.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>

        {/* Contact Form */}
        <div>
          <h2 className="font-bold text-lg mb-3">Send Us a Message</h2>
          <AnimatePresence mode="wait">
            {sent ? (
              <motion.div
                key="sent"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-primary/10 border-2 border-primary rounded-2xl p-8 text-center"
              >
                <CheckCircle className="w-14 h-14 text-primary mx-auto mb-3" />
                <p className="font-bold text-lg">Message Sent!</p>
                <p className="text-muted-foreground text-sm mt-1">We'll get back to you at <strong>{email}</strong> within 24 hours.</p>
                <button onClick={() => setSent(false)} className="mt-4 text-primary font-semibold text-sm underline">Send another message</button>
              </motion.div>
            ) : (
              <motion.form key="form" onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground mb-1 block">Your Name</label>
                    <input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Full name"
                      required
                      className="w-full bg-secondary rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground mb-1 block">Email</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your@email.com"
                      required
                      className="w-full bg-secondary rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground mb-1 block">Subject</label>
                  <BottomSheetSelect
                    value={subject}
                    onChange={setSubject}
                    options={SUBJECT_OPTIONS}
                    placeholder="Select a topic..."
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground mb-1 block">Message</label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Describe your issue or question..."
                    required
                    rows={4}
                    className="w-full bg-secondary rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-60"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
                  ) : "Send Message"}
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}