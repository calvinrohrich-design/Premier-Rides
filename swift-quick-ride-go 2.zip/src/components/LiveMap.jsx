import { useEffect, useState, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

function createCarIcon(rotation = 0) {
  return L.divIcon({
    html: `<div style="font-size:28px;line-height:1;transform:rotate(${rotation}deg);transition:transform 0.5s ease;">🚗</div>`,
    className: "",
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
}

const pickupIcon = L.divIcon({
  html: `<div style="width:16px;height:16px;background:#22c55e;border-radius:50%;border:3px solid white;box-shadow:0 0 10px rgba(34,197,94,0.8);"></div>`,
  className: "",
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

const dropoffIcon = L.divIcon({
  html: `<div style="width:16px;height:16px;background:#ef4444;border-radius:50%;border:3px solid white;box-shadow:0 0 10px rgba(239,68,68,0.8);"></div>`,
  className: "",
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

function RecenterMap({ center, follow }) {
  const map = useMap();
  const pausedUntilRef = useRef(0);
  const programmaticRef = useRef(false);
  const zoomedInRef = useRef(false);

  // Pause auto-follow when the driver manually zooms or pans
  useEffect(() => {
    const pause = () => {
      if (!programmaticRef.current) pausedUntilRef.current = Date.now() + 10000;
    };
    map.on("zoomstart", pause);
    map.on("dragstart", pause);
    return () => {
      map.off("zoomstart", pause);
      map.off("dragstart", pause);
    };
  }, [map]);

  useEffect(() => {
    if (!center || !follow) return;
    if (Date.now() < pausedUntilRef.current) return;
    programmaticRef.current = true;
    if (!zoomedInRef.current) {
      // Zoom in to street level when navigation starts
      map.setView(center, 16);
      zoomedInRef.current = true;
    } else {
      map.setView(center, map.getZoom());
    }
    setTimeout(() => { programmaticRef.current = false; }, 300);
  }, [center, follow, map]);
  return null;
}

function FitBounds({ points }) {
  const map = useMap();
  const key = points.map(p => p?.join(",")).join("|");
  useEffect(() => {
    if (points && points.length >= 2) {
      map.fitBounds(points, { padding: [50, 50] });
    }
  }, [key]);
  return null;
}

async function fetchRoadRoute(from, to) {
  if (!from || !to) return null;
  const url = `https://router.project-osrm.org/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}?overview=full&geometries=geojson`;
  const res = await fetch(url);
  const data = await res.json();
  if (data.routes && data.routes[0]) {
    return data.routes[0].geometry.coordinates.map(([lng, lat]) => [lat, lng]);
  }
  return null;
}

/**
 * Props:
 *   pickupCoords: [lat, lng]
 *   dropoffCoords: [lat, lng]
 *   driverCoords: [lat, lng]   (optional)
 *   showRoute: bool — fetch real road route from driver to active destination
 *   followDriver: bool — auto-recenter on driver position updates
 *   height: string (css, default "50vh")
 */
export default function LiveMap({ pickupCoords, dropoffCoords, driverCoords, showRoute = false, followDriver = false, height = "50vh", routeTo = "pickup" }) {
  const defaultCenter = driverCoords || pickupCoords || dropoffCoords;
  const [roadRoute, setRoadRoute] = useState(null);
  const [prevCoords, setPrevCoords] = useState(null);
  const [carRotation, setCarRotation] = useState(0);
  const lastRouteFetchRef = useRef(0);

  // Calculate car rotation based on movement direction
  useEffect(() => {
    if (!driverCoords || !prevCoords) {
      if (driverCoords) setPrevCoords(driverCoords);
      return;
    }
    const [lat1, lng1] = prevCoords;
    const [lat2, lng2] = driverCoords;
    const dy = lat2 - lat1;
    const dx = lng2 - lng1;
    // Calculate bearing: 0° = North (up), 90° = East (right)
    let angle = Math.atan2(dx, dy) * (180 / Math.PI);
    if (angle < 0) angle += 360;
    setCarRotation(angle);
    setPrevCoords(driverCoords);
  }, [driverCoords?.[0], driverCoords?.[1]]);

  useEffect(() => {
    if (!showRoute) return;
    const from = driverCoords;
    const to = routeTo === "dropoff" ? dropoffCoords : pickupCoords;
    if (!from || !to) {
      setRoadRoute(null);
      return;
    }
    // Throttle route recalculation to once every 12s to keep the app responsive
    const now = Date.now();
    if (roadRoute && now - lastRouteFetchRef.current < 12000) return;
    lastRouteFetchRef.current = now;
    let cancelled = false;
    fetchRoadRoute(from, to).then((route) => {
      if (!cancelled) setRoadRoute(route);
    });
    return () => { cancelled = true; };
  }, [
    showRoute,
    routeTo,
    driverCoords?.[0], driverCoords?.[1],
    pickupCoords?.[0], pickupCoords?.[1],
    dropoffCoords?.[0], dropoffCoords?.[1],
  ]);

  if (!defaultCenter) {
    return (
      <div style={{ height, width: "100%" }} className="flex items-center justify-center bg-secondary">
        <div className="text-muted-foreground text-sm">Locating...</div>
      </div>
    );
  }

  // Straight-line fallback points for customer view
  const straightPoints = [];
  if (driverCoords) straightPoints.push(driverCoords);
  if (pickupCoords) straightPoints.push(pickupCoords);
  if (dropoffCoords) straightPoints.push(dropoffCoords);

  const allBoundsPoints = [driverCoords, pickupCoords, dropoffCoords].filter(Boolean);

  return (
    <div style={{ height, width: "100%", position: "relative", zIndex: 0 }}>
      <MapContainer
        center={defaultCenter}
        zoom={14}
        style={{ height: "100%", width: "100%" }}
        zoomControl={false}
        scrollWheelZoom={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        />

        {/* Real road route for driver */}
        {showRoute && roadRoute && roadRoute.length >= 2 && (
          <Polyline positions={roadRoute} color="#22c55e" weight={5} opacity={0.9} />
        )}

        {/* Straight-line route for customer view */}
        {!showRoute && straightPoints.length >= 2 && (
          <Polyline positions={straightPoints} color="#22c55e" weight={3} opacity={0.7} dashArray="8,4" />
        )}

        {pickupCoords && (
          <Marker position={pickupCoords} icon={pickupIcon}>
            <Popup>Pickup</Popup>
          </Marker>
        )}
        {dropoffCoords && (
          <Marker position={dropoffCoords} icon={dropoffIcon}>
            <Popup>Dropoff</Popup>
          </Marker>
        )}
        {driverCoords && (
          <Marker
            key={`car-${driverCoords[0].toFixed(5)}-${driverCoords[1].toFixed(5)}`}
            position={driverCoords}
            icon={createCarIcon(carRotation)}
          >
            <Popup>Driver</Popup>
          </Marker>
        )}

        {followDriver && driverCoords && <RecenterMap center={driverCoords} follow={true} />}
        {showRoute && allBoundsPoints.length >= 2 && !followDriver && (
          <FitBounds points={allBoundsPoints} />
        )}
      </MapContainer>
    </div>
  );
}