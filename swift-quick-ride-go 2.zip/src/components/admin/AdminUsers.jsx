import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Search, Star, User, Car } from "lucide-react";

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    base44.functions.invoke('getAllUsers', {}).then((res) => {
      setUsers(res.data.users || []);
      setLoading(false);
    }).catch((err) => {
      console.error('Failed to load users:', err);
      setLoading(false);
    });
  }, []);

  const filtered = users.filter((u) => {
    const matchSearch = !search || u.full_name?.toLowerCase().includes(search.toLowerCase()) || u.email?.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || (filter === "driver" && (u.role === "driver" || u.vehicle_make)) || (filter === "customer" && u.role !== "driver" && !u.vehicle_make) || (filter === "admin" && u.role === "admin");
    return matchSearch && matchFilter;
  });

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or email..."
            className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <div className="flex gap-2">
          {["all", "customer", "driver", "admin"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium capitalize transition-colors ${filter === f ? "bg-primary text-white" : "bg-card border border-border text-muted-foreground hover:bg-secondary"}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <p className="text-sm text-muted-foreground">{filtered.length} user{filtered.length !== 1 ? "s" : ""}</p>

      <div className="grid gap-3">
        {filtered.map((u) => {
          const isDriver = u.role === "driver" || u.vehicle_make;
          return (
            <div key={u.id} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
              <div className={`w-11 h-11 rounded-full flex items-center justify-center text-lg font-bold flex-shrink-0 ${isDriver ? "bg-blue-500/10 text-blue-500" : "bg-primary/10 text-primary"}`}>
                {u.full_name?.[0] || "?"}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-semibold truncate">{u.full_name || "Unknown"}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${u.role === "admin" ? "bg-purple-100 text-purple-700" : isDriver ? "bg-blue-100 text-blue-700" : "bg-secondary text-muted-foreground"}`}>
                    {u.role === "admin" ? "Admin" : isDriver ? "Driver" : "Customer"}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground truncate">{u.email}</p>
                {isDriver && u.vehicle_make && (
                  <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                    <Car className="w-3 h-3" />
                    {u.vehicle_color} {u.vehicle_make} {u.vehicle_model} · {u.license_plate}
                  </p>
                )}
              </div>
              {u.rating && (
                <div className="flex items-center gap-1 text-sm font-semibold flex-shrink-0">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  {u.rating}
                </div>
              )}
              <p className="text-xs text-muted-foreground flex-shrink-0 hidden sm:block">
                {new Date(u.created_date).toLocaleDateString()}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}