import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, Clock, Star, ChevronLeft, Navigation } from "lucide-react";
import { motion } from "framer-motion";
import { fareBreakdown } from "@/utils/fareCalculator";
import BottomNav from "@/components/BottomNav";
import PullToRefresh from "@/components/PullToRefresh";

const STATUS_COLORS = {
  completed: "text-primary bg-primary/10",
  cancelled: "text-destructive bg-destructive/10",
  in_progress: "text-amber-500 bg-amber-500/10",
};

const RIDE_TYPE_EMOJI = { economy: "🚗", comfort: "🚙", premium: "🏎️" };

export default function CustomerRideHistory() {
  const [user, setUser] = useState(null);
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    const u = user || await base44.auth.me();
    if (!user) setUser(u);
    const all = await base44.entities.Ride.filter({ customer_id: u.id }, "-created_date", 50);
    setRides(all);
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, []);

  const totalSpent = rides
    .filter((r) => r.status === "completed")
    .reduce((sum, r) => sum + (r.estimated_fare || 0), 0);

  const completedCount = rides.filter((r) => r.status === "completed").length;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-nav">
      {/* Header */}
      <div className="pb-6 px-5 bg-card border-b border-border" style={{ paddingTop: 'max(3rem, env(safe-area-inset-top, 3rem))' }}>
        <button onClick={() => window.location.href = "/customer-home"} className="flex items-center gap-2 text-muted-foreground mb-3">
          <ChevronLeft className="w-5 h-5" />
          <span className="text-sm">Back</span>
        </button>
        <h1 className="text-2xl font-bold text-foreground">Ride History</h1>
        <p className="text-muted-foreground text-sm mt-1">{completedCount} trips completed</p>
      </div>

      {/* Stats */}
      <div className="px-5 -mt-4 mb-5">
        <div className="bg-card border border-border rounded-2xl p-4 grid grid-cols-3 gap-4 text-center shadow-sm">
          <div>
            <p className="text-2xl font-bold">{completedCount}</p>
            <p className="text-muted-foreground text-xs">Total Rides</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary">${totalSpent.toFixed(0)}</p>
            <p className="text-muted-foreground text-xs">Total Spent</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{rides.filter(r => r.status === "cancelled").length}</p>
            <p className="text-muted-foreground text-xs">Cancelled</p>
          </div>
        </div>
      </div>

      {/* Rides List */}
      <PullToRefresh onRefresh={loadData} className="px-5 pb-8">
        <div className="space-y-3 pt-1">
        {rides.length === 0 ? (
          <div className="text-center py-16">
            <span className="text-5xl block mb-4">🚗</span>
            <p className="font-bold text-lg">No rides yet</p>
            <p className="text-muted-foreground text-sm mt-1">Your ride history will appear here</p>
            <button onClick={() => window.location.href = "/customer-home"} className="mt-6 bg-primary text-white px-6 py-3 rounded-2xl font-semibold">Book a Ride</button>
          </div>
        ) : (
          rides.map((ride, i) => {
            const bd = ride.status === "completed"
              ? fareBreakdown(ride.estimated_duration_min, ride.estimated_distance_miles, ride.ride_type)
              : null;
            return (
              <motion.div
                key={ride.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="bg-card border border-border rounded-2xl p-4"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{RIDE_TYPE_EMOJI[ride.ride_type] || "🚗"}</span>
                    <div>
                      <p className="font-semibold capitalize">{ride.ride_type} Ride</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(ride.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${STATUS_COLORS[ride.status] || "text-muted-foreground bg-secondary"}`}>
                      {ride.status}
                    </span>
                    {bd && <p className="font-bold mt-1">${bd.total}</p>}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex flex-col items-center gap-1 mt-1">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    <div className="w-px h-6 bg-border" />
                    <MapPin className="w-3 h-3 text-destructive" />
                  </div>
                  <div className="flex-1 space-y-2">
                    <p className="text-sm text-muted-foreground truncate">{ride.pickup_address}</p>
                    <p className="text-sm font-medium truncate">{ride.dropoff_address}</p>
                  </div>
                </div>

                {ride.status === "completed" && (
                  <div className="mt-3 pt-3 border-t border-border flex items-center gap-4 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{ride.estimated_duration_min} min</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Navigation className="w-3.5 h-3.5" />
                      <span>{ride.estimated_distance_miles} mi</span>
                    </div>
                    {ride.driver_name && (
                      <div className="flex items-center gap-1 ml-auto">
                        <span>Driver: {ride.driver_name}</span>
                      </div>
                    )}
                    {ride.customer_rating && (
                      <div className="flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                        <span>{ride.customer_rating}</span>
                      </div>
                    )}
                  </div>
                )}

                {ride.status === "completed" && (
                  <button
                    onClick={() => window.location.href = `/customer-home?rebook=${encodeURIComponent(ride.dropoff_address)}`}
                    className="mt-3 w-full border border-primary text-primary py-2.5 rounded-xl text-sm font-semibold active:scale-95 transition-transform"
                  >
                    Rebook this trip
                  </button>
                )}
              </motion.div>
            );
          })
        )}
        </div>
      </PullToRefresh>
      <BottomNav variant="customer" />
    </div>
  );
}