/**
 * Fare Calculation
 * Base charge: $5.00
 * Per minute:  $0.35
 * Per mile:    $1.50
 */

export const FARE_RATES = {
  BASE_CHARGE: 5.00,
  PER_MINUTE: 0.35,
  PER_MILE: 1.50,
};

// Drivers keep 70% of the fare (tips are 100% theirs)
export const DRIVER_SHARE = 0.7;

export function driverEarnings(fare) {
  return parseFloat(((fare || 0) * DRIVER_SHARE).toFixed(2));
}

export const RIDE_TYPE_MULTIPLIERS = {
  economy: 1.0,
  comfort: 1.4,
  premium: 2.0,
};

/**
 * Calculate fare from duration and distance
 * @param {number} durationMin  - Trip duration in minutes
 * @param {number} distanceMiles - Trip distance in miles
 * @param {string} rideType - "economy" | "comfort" | "premium"
 * @returns {number} fare in dollars (rounded to 2 decimal places)
 */
export function calculateFare(durationMin, distanceMiles, rideType = "economy") {
  const multiplier = RIDE_TYPE_MULTIPLIERS[rideType] ?? 1.0;
  const fare =
    (FARE_RATES.BASE_CHARGE +
      FARE_RATES.PER_MINUTE * durationMin +
      FARE_RATES.PER_MILE * distanceMiles) *
    multiplier;
  return parseFloat(fare.toFixed(2));
}

/**
 * Returns a human-readable fare breakdown string
 */
export function fareBreakdown(durationMin, distanceMiles, rideType = "economy") {
  const multiplier = RIDE_TYPE_MULTIPLIERS[rideType] ?? 1.0;
  const base = FARE_RATES.BASE_CHARGE;
  const timeCost = FARE_RATES.PER_MINUTE * durationMin;
  const distCost = FARE_RATES.PER_MILE * distanceMiles;
  const subtotal = base + timeCost + distCost;
  const total = subtotal * multiplier;
  return {
    base: base.toFixed(2),
    time: timeCost.toFixed(2),
    distance: distCost.toFixed(2),
    subtotal: subtotal.toFixed(2),
    multiplier,
    total: total.toFixed(2),
  };
}