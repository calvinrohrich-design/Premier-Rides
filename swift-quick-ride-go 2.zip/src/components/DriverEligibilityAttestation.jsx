import { CheckCircle, UserCheck } from "lucide-react";

export const ELIGIBILITY_ITEMS = [
  "I am at least 21 years old and hold a valid driver's license.",
  "I have NOT had more than 3 moving violations in the last 3 years.",
  "I have NO convictions for DUI/DWI, fraud, sexual offenses, use of a motor vehicle to commit a felony, or violent crimes within the last 7 years.",
  "I am not listed on the national sex offender registry.",
  "The vehicle I will drive has current registration and TNC-compliant insurance coverage.",
];

export default function DriverEligibilityAttestation({ checked, onToggle }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <UserCheck className="w-5 h-5 text-primary" />
        <h2 className="font-bold text-lg">Driver Eligibility</h2>
        <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">ND Required</span>
      </div>
      <p className="text-xs text-muted-foreground mb-4">
        North Dakota law requires EW Premier Rides to verify driver eligibility before activation. You must truthfully confirm each statement — all are independently verified through your license and background check.
      </p>
      <div className="space-y-2">
        {ELIGIBILITY_ITEMS.map((item, i) => (
          <button
            key={i}
            type="button"
            onClick={() => onToggle(i)}
            className={`w-full flex items-start gap-3 p-3 rounded-xl border-2 text-left transition-all ${checked[i] ? "border-primary bg-primary/5" : "border-border bg-secondary/50"}`}
          >
            <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors ${checked[i] ? "bg-primary border-primary" : "border-border"}`}>
              {checked[i] && <CheckCircle className="w-3.5 h-3.5 text-white" />}
            </div>
            <span className={`text-sm ${checked[i] ? "text-foreground font-medium" : "text-muted-foreground"}`}>{item}</span>
          </button>
        ))}
      </div>
      <p className="text-xs text-muted-foreground mt-3">
        Providing false information will result in immediate and permanent removal from the platform.
      </p>
    </div>
  );
}