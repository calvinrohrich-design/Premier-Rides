import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import AdminStats from "@/components/admin/AdminStats";
import AdminLiveRides from "@/components/admin/AdminLiveRides";
import AdminUsers from "@/components/admin/AdminUsers";
import AdminRideHistory from "@/components/admin/AdminRideHistory";
import AdminDriverApprovals from "@/components/admin/AdminDriverApprovals";
import AdminPayouts from "@/components/admin/AdminPayouts";
import { LayoutDashboard, Car, Users, History, LogOut, Map, ClipboardCheck, DollarSign } from "lucide-react";

const TABS = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "live", label: "Live Rides", icon: Car },
  { id: "approvals", label: "Driver Approvals", icon: ClipboardCheck },
  { id: "payouts", label: "Payouts", icon: DollarSign },
  { id: "users", label: "Users", icon: Users },
  { id: "history", label: "Ride History", icon: History },
];

export default function AdminDashboard() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">You need admin privileges to view this page.</p>
          <button onClick={() => window.location.href = "/login"} className="mt-6 bg-primary text-white px-6 py-3 rounded-2xl font-semibold">
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="w-64 bg-card border-r border-border flex flex-col fixed top-0 bottom-0 left-0 z-20 hidden md:flex">
        <div className="px-6 py-6 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </div>
            <div>
              <p className="font-bold text-sm">RideAdmin</p>
              <p className="text-xs text-muted-foreground">Dashboard</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-4 py-4 space-y-1">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                activeTab === tab.id ? "bg-primary text-white" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </nav>
        <div className="px-4 py-4 border-t border-border space-y-1">
          <a
            href="/customer-home"
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <span className="text-lg">🚗</span>
            Customer View
          </a>
          <a
            href="/driver-home"
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <span className="text-lg">🚙</span>
            Driver View
          </a>
          <a
            href="/active-drivers"
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <Map className="w-4 h-4" />
            Driver Map
          </a>
          <button
            onClick={() => base44.auth.logout("/login")}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile top nav */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-20 bg-card border-b border-border px-4 pt-10 pb-3">
        <div className="flex items-center justify-between mb-3">
          <p className="font-bold">RideAdmin</p>
          <button onClick={() => base44.auth.logout("/login")} className="text-destructive text-sm">Sign Out</button>
        </div>
        <div className="flex gap-1 overflow-x-auto pb-1 mb-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id ? "bg-primary text-white" : "bg-secondary text-muted-foreground"
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex gap-2 pt-2 border-t border-border">
          <a href="/customer-home" className="flex-1 bg-secondary text-center py-2 rounded-xl text-xs font-medium">🚗 Customer</a>
          <a href="/driver-home" className="flex-1 bg-secondary text-center py-2 rounded-xl text-xs font-medium">🚙 Driver</a>
        </div>
      </div>

      {/* Main content */}
      <main className="flex-1 md:ml-64 pt-36 md:pt-0">
        <div className="p-6 md:p-8">
          <div className="mb-6 hidden md:block">
            <h1 className="text-2xl font-bold">{TABS.find((t) => t.id === activeTab)?.label}</h1>
            <p className="text-muted-foreground text-sm mt-1">{new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
          </div>

          {activeTab === "overview" && <AdminStats />}
          {activeTab === "live" && <AdminLiveRides />}
          {activeTab === "approvals" && <AdminDriverApprovals />}
          {activeTab === "payouts" && <AdminPayouts />}
          {activeTab === "users" && <AdminUsers />}
          {activeTab === "history" && <AdminRideHistory />}
        </div>
      </main>
    </div>
  );
}