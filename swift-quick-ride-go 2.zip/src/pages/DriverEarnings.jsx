import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, DollarSign, Navigation, Star, TrendingUp, Clock, MapPin } from "lucide-react";
import { motion } from "framer-motion";
import PayoutRequestModal from "@/components/PayoutRequestModal";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { fareBreakdown, driverEarnings } from "@/utils/fareCalculator";

const PERIODS = ["Week", "Month", "All Time"];

function getWeekLabel(date) {
  return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][new Date(date).getDay()];
}

function getMonthLabel(date) {
  return new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export default function DriverEarnings() {
  const [user, setUser] = useState(null);
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("Week");
  const [showPayoutModal, setShowPayoutModal] = useState(false);

  useEffect(() => {
    base44.auth.me().then(async (u) => {
      setUser(u);
      const all = await base44.entities.Ride.filter({ driver_id: u.id, status: "completed" }, "-created_date", 100);
      setRides(all);
      setLoading(false);
    });
  }, []);

  const now = new Date();
  const filtered = rides.filter((r) => {
    const d = new Date(r.created_date);
    if (period === "Week") return (now - d) < 7 * 86400000;
    if (period === "Month") return (now - d) < 30 * 86400000;
    return true;
  });

  // Driver keeps 70% of fare + 100% of tips
  const totalEarnings = filtered.reduce((sum, r) => {
    const bd = fareBreakdown(r.estimated_duration_min, r.estimated_distance_miles, r.ride_type);
    return sum + driverEarnings(parseFloat(bd.total)) + (r.tip_amount || 0);
  }, 0);

  const totalTips = filtered.reduce((sum, r) => sum + (r.tip_amount || 0), 0);

  const avgRating = filtered.filter(r => r.driver_rating).reduce((sum, r, _, arr) => sum + r.driver_rating / arr.length, 0);
  const totalMin = filtered.reduce((sum, r) => sum + (r.estimated_duration_min || 0), 0);
  const totalMiles = filtered.reduce((sum, r) => sum + (r.actual_distance_miles || r.estimated_distance_miles || 0), 0);
  const IRS_RATE = 0.67; // 2024 IRS standard mileage rate per mile
  const mileageDeduction = totalMiles * IRS_RATE;

  // Build chart data grouped by day
  const chartMap = {};
  filtered.forEach((r) => {
    const label = period === "Month" ? getMonthLabel(r.created_date) : getWeekLabel(r.created_date);
    const bd = fareBreakdown(r.estimated_duration_min, r.estimated_distance_miles, r.ride_type);
    chartMap[label] = (chartMap[label] || 0) + driverEarnings(parseFloat(bd.total)) + (r.tip_amount || 0);
  });

  const chartData = Object.entries(chartMap).map(([day, earnings]) => ({
    day,
    earnings: parseFloat(earnings.toFixed(2)),
  }));

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <div className="pb-6 px-5 bg-card border-b border-border" style={{ paddingTop: 'max(3rem, env(safe-area-inset-top, 3rem))' }}>
        <button onClick={() => window.location.href = "/driver-home"} className="flex items-center gap-2 text-muted-foreground mb-3">
          <ChevronLeft className="w-5 h-5" />
          <span className="text-sm">Back</span>
        </button>
        <h1 className="text-2xl font-bold text-foreground">Earnings</h1>
        <p className="text-sm mt-1 text-muted-foreground">{filtered.length} trips · {period.toLowerCase()}</p>
        <button
          onClick={() => setShowPayoutModal(true)}
          className="mt-3 bg-primary text-white px-5 py-2.5 rounded-xl font-semibold text-sm active:scale-95 transition-transform"
        >
          💸 Request Payout
        </button>
      </div>

      <div className="px-5 -mt-4 space-y-5">
        {/* Period Toggle */}
        <div className="flex gap-2 bg-card border border-border rounded-2xl p-1.5 shadow-sm">
          {PERIODS.map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${period === p ? "bg-primary text-white shadow" : "text-muted-foreground"}`}
            >
              {p}
            </button>
          ))}
        </div>

        {/* Main Earnings Card */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="bg-primary rounded-3xl p-5 text-white">
          <p className="text-white/70 text-sm">Total Earned (70% of fares + 100% of tips)</p>
          <p className="text-4xl font-bold mt-1">${totalEarnings.toFixed(2)}</p>
          <div className="flex items-center gap-1 mt-2 text-white/70 text-sm">
            <TrendingUp className="w-4 h-4" />
            <span>{filtered.length} completed rides</span>
          </div>
          {totalTips > 0 && (
            <div className="mt-3 pt-3 border-t border-white/20 flex items-center gap-2 text-sm">
              <span className="text-white/70">Includes tips:</span>
              <span className="font-bold text-green-300">${totalTips.toFixed(2)}</span>
            </div>
          )}
        </motion.div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Trips", value: filtered.length, icon: Navigation, color: "text-blue-500 bg-blue-500/10" },
            { label: "Avg Rating", value: avgRating > 0 ? avgRating.toFixed(1) : "—", icon: Star, color: "text-amber-500 bg-amber-500/10" },
            { label: "Drive Time", value: `${Math.round(totalMin / 60)}h ${totalMin % 60}m`, icon: Clock, color: "text-purple-500 bg-purple-500/10" },
            { label: "Miles Driven", value: `${totalMiles.toFixed(1)} mi`, icon: MapPin, color: "text-green-500 bg-green-500/10" },
          ].map((s) => (
            <div key={s.label} className="bg-card border border-border rounded-2xl p-3 text-center">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center mx-auto mb-2 ${s.color}`}>
                <s.icon className="w-4 h-4" />
              </div>
              <p className="font-bold text-lg">{s.value}</p>
              <p className="text-muted-foreground text-xs">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Mileage Tax Deduction Card */}
        {totalMiles > 0 && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-bold text-green-800 text-sm">🚗 IRS Mileage Deduction</p>
                <p className="text-green-700 text-xs mt-0.5">Based on {totalMiles.toFixed(1)} miles @ $0.67/mi (2024 rate)</p>
              </div>
              <p className="font-bold text-green-700 text-lg">${mileageDeduction.toFixed(2)}</p>
            </div>
            <p className="text-green-600 text-xs mt-2">Keep this for tax purposes. Consult a tax professional for your filing.</p>
          </div>
        )}

        {/* Chart */}
        {chartData.length > 0 && (
          <div className="bg-card border border-border rounded-2xl p-4">
            <p className="font-bold mb-4">Earnings Breakdown</p>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={chartData} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }}
                  formatter={(v) => [`$${v}`, "Earnings"]}
                />
                <Bar dataKey="earnings" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Recent Trips */}
        <div>
          <p className="font-bold mb-3">Recent Trips</p>
          {filtered.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <DollarSign className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p>No completed rides in this period</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.slice(0, 10).map((ride) => {
                const bd = fareBreakdown(ride.estimated_duration_min, ride.estimated_distance_miles, ride.ride_type);
                return (
                  <div key={ride.id} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{ride.dropoff_address}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(ride.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })} · {ride.estimated_duration_min} min · {(ride.actual_distance_miles || ride.estimated_distance_miles || 0).toFixed(1)} mi
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-bold text-primary">${(driverEarnings(parseFloat(bd.total)) + (ride.tip_amount || 0)).toFixed(2)}</p>
                      {ride.customer_rating && (
                        <div className="flex items-center gap-0.5 justify-end mt-0.5">
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                          <span className="text-xs text-muted-foreground">{ride.customer_rating}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {showPayoutModal && (
        <PayoutRequestModal
          user={user}
          availableBalance={totalEarnings}
          onClose={() => setShowPayoutModal(false)}
        />
      )}
    </div>
  );
}