import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Search, Star, MapPin } from "lucide-react";

const STATUS_COLORS = {
  requested: "bg-amber-100 text-amber-700",
  accepted: "bg-blue-100 text-blue-700",
  en_route: "bg-blue-100 text-blue-700",
  arrived: "bg-purple-100 text-purple-700",
  in_progress: "bg-primary/10 text-primary",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

export default function AdminRideHistory() {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    base44.entities.Ride.list("-created_date", 200).then((r) => {
      setRides(r);
      setLoading(false);
    });
  }, []);

  const filtered = rides.filter((r) => {
    const matchSearch = !search ||
      r.customer_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.driver_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.pickup_address?.toLowerCase().includes(search.toLowerCase()) ||
      r.dropoff_address?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin" /></div>;

  const statuses = ["all", "requested", "accepted", "in_progress", "completed", "cancelled"];

  return (
    <div className="space-y-4">
      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search customer, driver, address..."
            className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
      </div>
      <div className="flex gap-2 flex-wrap">
        {statuses.map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium capitalize transition-colors ${statusFilter === s ? "bg-primary text-white" : "bg-card border border-border text-muted-foreground hover:bg-secondary"}`}
          >
            {s.replace("_", " ")}
          </button>
        ))}
      </div>

      <p className="text-sm text-muted-foreground">{filtered.length} ride{filtered.length !== 1 ? "s" : ""}</p>

      <div className="space-y-3">
        {filtered.map((ride) => (
          <div key={ride.id} className="bg-card border border-border rounded-2xl p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${STATUS_COLORS[ride.status] || "bg-secondary text-foreground"}`}>
                  {ride.status.replace("_", " ")}
                </span>
                <span className="text-xs text-muted-foreground capitalize">{ride.ride_type}</span>
                <span className="text-xs text-muted-foreground">{new Date(ride.created_date).toLocaleString()}</span>
              </div>
              <p className="font-bold text-primary">${ride.estimated_fare?.toFixed(2)}</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-muted-foreground mb-1">CUSTOMER</p>
                <p className="font-semibold text-sm">{ride.customer_name || "—"}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">DRIVER</p>
                <p className="font-semibold text-sm">{ride.driver_name || "Not assigned"}</p>
              </div>
            </div>

            <div className="mt-3 flex items-start gap-3">
              <div className="flex flex-col items-center gap-1 mt-1">
                <div className="w-2 h-2 bg-primary rounded-full" />
                <div className="w-0.5 h-5 bg-border" />
                <MapPin className="w-3 h-3 text-destructive" />
              </div>
              <div className="flex-1 space-y-1.5">
                <p className="text-sm text-muted-foreground">{ride.pickup_address}</p>
                <p className="text-sm text-foreground">{ride.dropoff_address}</p>
              </div>
              {ride.customer_rating && (
                <div className="flex items-center gap-1 text-sm font-medium flex-shrink-0">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  {ride.customer_rating}
                </div>
              )}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-12 bg-card border border-border rounded-2xl">
            <p className="text-muted-foreground">No rides found</p>
          </div>
        )}
      </div>
    </div>
  );
}