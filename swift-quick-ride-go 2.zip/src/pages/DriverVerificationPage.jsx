import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle, Upload, Clock, Car, FileText, Shield, Camera, ClipboardCheck, AlertTriangle, MapPin, ChevronLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { classifyVehicle } from "@/utils/vehicleClassifier";
import DriverEligibilityAttestation, { ELIGIBILITY_ITEMS } from "@/components/DriverEligibilityAttestation";

const INSPECTION_ITEMS = [
  "Brakes functioning properly",
  "All lights working (headlights, brake lights, turn signals)",
  "Seatbelts in working condition (all seats)",
  "Tires in good condition (no bald spots or damage)",
  "Windshield free of cracks obstructing vision",
  "Horn functioning",
  "Mirrors properly adjusted and intact",
  "Vehicle interior clean and safe for passengers",
];

const DocUpload = ({ label, icon: Icon, docKey, uploaded, onUpload }) => (
  <div className={`rounded-2xl border-2 p-4 transition-all ${uploaded ? "border-primary bg-primary/5" : "border-dashed border-border bg-secondary/50"}`}>
    <div className="flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${uploaded ? "bg-primary/20" : "bg-secondary"}`}>
        <Icon className={`w-6 h-6 ${uploaded ? "text-primary" : "text-muted-foreground"}`} />
      </div>
      <div className="flex-1">
        <p className="font-semibold text-sm">{label}</p>
        <p className={`text-xs mt-0.5 ${uploaded ? "text-primary" : "text-muted-foreground"}`}>
          {uploaded ? "✓ Uploaded" : "Tap to upload"}
        </p>
      </div>
      <label className="cursor-pointer">
        <input type="file" accept="image/*,application/pdf" className="hidden" onChange={(e) => onUpload(docKey, e.target.files[0])} />
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-90 ${uploaded ? "bg-primary/20 text-primary" : "bg-primary text-white"}`}>
          {uploaded ? <CheckCircle className="w-5 h-5" /> : <Upload className="w-5 h-5" />}
        </div>
      </label>
    </div>
  </div>
);

export default function DriverVerificationPage() {
  const [user, setUser] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [docs, setDocs] = useState({ drivers_license: null, vehicle_registration: null, insurance: null, profile_photo: null });
  const [vehicle, setVehicle] = useState({ make: "", model: "", year: "", color: "", plate: "" });
  const [serviceCity, setServiceCity] = useState("Bismarck");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [inspectionChecked, setInspectionChecked] = useState({});
  const [eligibilityChecked, setEligibilityChecked] = useState({});
  const [alcoholPolicyAgreed, setAlcoholPolicyAgreed] = useState(false);
  const [termsAgreed, setTermsAgreed] = useState(false);
  const [backgroundCheckInitiated, setBackgroundCheckInitiated] = useState(user?.checkr_applicant_id ? true : false);
  const [backgroundCheckStatus, setBackgroundCheckStatus] = useState(user?.checkr_report_status || null);
  const [initiatingCheck, setInitiatingCheck] = useState(false);
  const [validationError, setValidationError] = useState(null);
  const [validating, setValidating] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setLoadingAuth(false);
    });
  }, []);

  if (loadingAuth) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-10 h-10 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  if (!user) {
    window.location.replace("/login?role=driver");
    return null;
  }

  const handleUpload = (key, file) => {
    setDocs((prev) => ({ ...prev, [key]: file }));
  };

  const initiateBackgroundCheck = async () => {
    setInitiatingCheck(true);
    try {
      // Call backend function to create Checkr applicant and run background check
      const response = await base44.functions.invoke('initiateBackgroundCheck', {
        email: user.email,
        full_name: user.full_name,
      });
      
      if (response.data.success) {
        await base44.auth.updateMe({
          checkr_applicant_id: response.data.applicant_id,
          checkr_report_status: 'pending',
        });
        setBackgroundCheckInitiated(true);
        setBackgroundCheckStatus('pending');
      }
    } catch (error) {
      console.error('Background check initiation failed:', error);
    }
    setInitiatingCheck(false);
  };

  const handleSubmit = async () => {
    setLoading(true);
    setValidationError(null);
    const urls = {};
    for (const [key, file] of Object.entries(docs)) {
      if (file) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        urls[key] = file_url;
      }
    }

    // AI validation: license & insurance must be active before submission
    setValidating(true);
    const validation = await base44.functions.invoke('validateDriverDocuments', {
      license_url: urls.drivers_license,
      insurance_url: urls.insurance,
    });
    setValidating(false);
    if (!validation.data?.documents_valid) {
      setValidationError(validation.data);
      setLoading(false);
      return;
    }

    const vehicleType = classifyVehicle(vehicle.year, vehicle.make, vehicle.model);
    const allInspectionChecked = INSPECTION_ITEMS.every((_, i) => inspectionChecked[i]);
    await base44.auth.updateMe({
      vehicle_make: vehicle.make,
      vehicle_model: vehicle.model,
      vehicle_year: vehicle.year,
      vehicle_color: vehicle.color,
      license_plate: vehicle.plate,
      vehicle_type: vehicleType,
      drivers_license_url: urls.drivers_license,
      vehicle_registration_url: urls.vehicle_registration,
      insurance_url: urls.insurance,
      profile_photo_url: urls.profile_photo,
      vehicle_inspection_passed: allInspectionChecked,
      eligibility_attested: ELIGIBILITY_ITEMS.every((_, i) => eligibilityChecked[i]),
      eligibility_attested_date: new Date().toISOString(),
      service_city: serviceCity,
      verification_status: user?.verification_status === "approved" ? "approved" : "submitted",
    });

    // Already-approved drivers re-uploading renewed docs go straight back to driving
    if (user?.verification_status === "approved") {
      window.location.href = "/driver-home";
      return;
    }
    
    setSubmitted(true);
    setLoading(false);
  };

  if (user?.verification_status === "approved" && user?.documents_valid !== false && !submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <CheckCircle className="w-12 h-12 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-center">You're Approved! 🎉</h2>
        <p className="text-muted-foreground text-center mt-2 max-w-xs">Your driver account is active. You're ready to start accepting rides.</p>
        <div className="mt-8 w-full max-w-sm space-y-3">
          {[["Driver's License", "Verified ✓"], ["Vehicle Registration", "Verified ✓"], ["Insurance", "Verified ✓"]].map(([label, status]) => (
            <div key={label} className="flex items-center justify-between bg-card border border-border rounded-2xl px-4 py-3">
              <span className="font-medium text-sm">{label}</span>
              <span className="text-primary text-xs font-semibold">{status}</span>
            </div>
          ))}
        </div>
        <button onClick={() => window.location.href = "/driver-home"} className="mt-8 bg-primary text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform">
          Go to Driver Home
        </button>
      </div>
    );
  }

  if (submitted || user?.verification_status === "submitted" || user?.verification_status === "pending") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="w-24 h-24 bg-amber-100 rounded-full flex items-center justify-center mb-6">
          <Clock className="w-12 h-12 text-amber-500" />
        </div>
        <h2 className="text-2xl font-bold text-center">Under Review</h2>
        <p className="text-muted-foreground text-center mt-2 max-w-xs">We're reviewing your documents. This usually takes 1-2 business days.</p>
        <div className="mt-8 w-full max-w-sm space-y-3">
          {[["Driver's License", "Submitted ✓"], ["Vehicle Registration", "Submitted ✓"], ["Insurance", "Submitted ✓"]].map(([label, status]) => (
            <div key={label} className="flex items-center justify-between bg-card border border-border rounded-2xl px-4 py-3">
              <span className="font-medium text-sm">{label}</span>
              <span className="text-primary text-xs font-semibold">{status}</span>
            </div>
          ))}
        </div>
        <button onClick={() => window.location.href = "/welcome"} className="mt-8 text-muted-foreground text-sm">← Back to Home</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="pb-6 px-6 bg-card border-b border-border" style={{ paddingTop: 'max(3.5rem, env(safe-area-inset-top, 3.5rem))' }}>
        <button onClick={() => window.location.href = "/driver-home"} className="flex items-center gap-2 text-muted-foreground mb-3">
          <ChevronLeft className="w-5 h-5" />
          <span className="text-sm">Back</span>
        </button>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Driver Verification</h1>
            <p className="text-muted-foreground text-sm">Complete your profile to start driving</p>
          </div>
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Vehicle Info */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <div className="flex items-center gap-2 mb-4">
            <Car className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-lg">Vehicle Information</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[["make", "Make", "Toyota"], ["model", "Model", "Camry"], ["year", "Year", "2022"], ["color", "Color", "Black"], ["plate", "License Plate", "ABC-1234"]].map(([key, label, placeholder]) => (
              <div key={key} className={key === "plate" ? "col-span-2" : ""}>
                <label className="text-xs font-semibold text-foreground/60 mb-1.5 block">{label}</label>
                <input
                  type={key === "year" ? "number" : "text"}
                  placeholder={placeholder}
                  value={vehicle[key]}
                  onChange={(e) => setVehicle({ ...vehicle, [key]: e.target.value })}
                  className="w-full bg-secondary rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm"
                />
              </div>
            ))}
          </div>
        </motion.div>

        {/* Service City */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.13 }}>
          <div className="flex items-center gap-2 mb-3">
            <MapPin className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-lg">Service City</h2>
          </div>
          <p className="text-xs text-muted-foreground mb-3">Select the city where you will primarily drive.</p>
          <div className="grid grid-cols-3 gap-3">
            {["Bismarck", "Dickinson", "Medora", "Minot", "Grand Forks", "Fargo"].map((city) => (
              <button
                key={city}
                type="button"
                onClick={() => setServiceCity(city)}
                className={`py-3 rounded-2xl border-2 font-semibold text-sm transition-all ${serviceCity === city ? "border-primary bg-primary/10 text-primary" : "border-border bg-secondary text-muted-foreground"}`}
              >
                {city}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Profile Photo — ND compliance: must be shown to passengers */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <div className="flex items-center gap-2 mb-4">
            <Camera className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-lg">Profile Photo</h2>
            <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">ND Required</span>
          </div>
          <p className="text-xs text-muted-foreground mb-3">North Dakota law requires your photo to be displayed to passengers before they enter the vehicle.</p>
          <DocUpload label="Driver Profile Photo" icon={Camera} docKey="profile_photo" uploaded={!!docs.profile_photo} onUpload={handleUpload} />
        </motion.div>

        {/* Documents */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-lg">Required Documents</h2>
          </div>
          <div className="space-y-3">
            <DocUpload label="Driver's License" icon={FileText} docKey="drivers_license" uploaded={!!docs.drivers_license} onUpload={handleUpload} />
            <DocUpload label="Vehicle Registration" icon={Car} docKey="vehicle_registration" uploaded={!!docs.vehicle_registration} onUpload={handleUpload} />
            <DocUpload label="Insurance Document" icon={Shield} docKey="insurance" uploaded={!!docs.insurance} onUpload={handleUpload} />
          </div>
          <div className="mt-3 bg-primary/5 border border-primary/20 rounded-2xl p-4">
            <p className="text-sm font-semibold text-foreground mb-1">🛡️ Insurance Coverage — How It Works</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              EW Premier Rides carries a commercial TNC insurance policy that covers you whenever you're driving on the platform, as required by North Dakota law (including $1,000,000 coverage from ride acceptance through drop-off). You do <strong className="text-foreground">not</strong> need your own rideshare policy — just upload proof of your current <strong className="text-foreground">personal auto insurance</strong>, which must remain active while you drive. We recommend letting your insurer know you drive for a TNC.
            </p>
          </div>
        </motion.div>

        {/* Vehicle Inspection Checklist — ND requirement */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
          <div className="flex items-center gap-2 mb-2">
            <ClipboardCheck className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-lg">Vehicle Safety Inspection</h2>
            <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">ND Required</span>
          </div>
          <p className="text-xs text-muted-foreground mb-4">Confirm your vehicle meets North Dakota TNC safety standards. All items must be checked before submission.</p>
          <div className="space-y-2">
            {INSPECTION_ITEMS.map((item, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setInspectionChecked(prev => ({ ...prev, [i]: !prev[i] }))}
                className={`w-full flex items-center gap-3 p-3 rounded-xl border-2 text-left transition-all ${inspectionChecked[i] ? "border-primary bg-primary/5" : "border-border bg-secondary/50"}`}
              >
                <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-colors ${inspectionChecked[i] ? "bg-primary border-primary" : "border-border"}`}>
                  {inspectionChecked[i] && <CheckCircle className="w-3.5 h-3.5 text-white" />}
                </div>
                <span className={`text-sm ${inspectionChecked[i] ? "text-foreground font-medium" : "text-muted-foreground"}`}>{item}</span>
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            {INSPECTION_ITEMS.filter((_, i) => inspectionChecked[i]).length}/{INSPECTION_ITEMS.length} items confirmed
          </p>
        </motion.div>

        {/* Driver Eligibility Attestation — ND TNC vetting requirement */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.27 }}>
          <DriverEligibilityAttestation
            checked={eligibilityChecked}
            onToggle={(i) => setEligibilityChecked((prev) => ({ ...prev, [i]: !prev[i] }))}
          />
        </motion.div>

        {/* Zero-Tolerance Alcohol Policy */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.28 }}>
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-destructive" />
            <h2 className="font-bold text-lg">Zero-Tolerance Policy</h2>
            <span className="text-xs text-destructive bg-destructive/10 border border-destructive/20 px-2 py-0.5 rounded-full">Required</span>
          </div>
          <div className="bg-destructive/5 border-2 border-destructive/20 rounded-2xl p-4 space-y-3">
            <p className="text-sm text-muted-foreground leading-relaxed">
              North Dakota law requires all TNC drivers to maintain a <strong className="text-foreground">strict zero-tolerance policy</strong> for alcohol and controlled substances while operating a vehicle on this platform.
            </p>
            <button
              type="button"
              onClick={() => setAlcoholPolicyAgreed(!alcoholPolicyAgreed)}
              className={`w-full flex items-start gap-3 p-3 rounded-xl border-2 text-left transition-all ${alcoholPolicyAgreed ? "border-primary bg-primary/5" : "border-border bg-background"}`}
            >
              <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors ${alcoholPolicyAgreed ? "bg-primary border-primary" : "border-border"}`}>
                {alcoholPolicyAgreed && <CheckCircle className="w-3.5 h-3.5 text-white" />}
              </div>
              <span className="text-sm font-medium">I acknowledge and agree to EW Premier Rides's zero-tolerance policy for alcohol and drugs while driving. I understand that any violation will result in immediate and permanent removal from the platform.</span>
            </button>
          </div>
        </motion.div>

        {/* Terms & Privacy */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.29 }}>
          <button
            type="button"
            onClick={() => setTermsAgreed(!termsAgreed)}
            className={`w-full flex items-start gap-3 p-4 rounded-2xl border-2 text-left transition-all ${termsAgreed ? "border-primary bg-primary/5" : "border-border bg-card"}`}
          >
            <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors ${termsAgreed ? "bg-primary border-primary" : "border-border"}`}>
              {termsAgreed && <CheckCircle className="w-3.5 h-3.5 text-white" />}
            </div>
            <span className="text-sm text-muted-foreground">
              I agree to the{" "}
              <Link to="/terms" className="text-primary font-semibold underline" onClick={(e) => e.stopPropagation()}>Terms of Service</Link>
              {" "}and{" "}
              <Link to="/privacy" className="text-primary font-semibold underline" onClick={(e) => e.stopPropagation()}>Privacy Policy</Link>
            </span>
          </button>
        </motion.div>

        {/* Background Check — Manual Review */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-5 h-5 text-primary" />
            <h2 className="font-bold text-lg">Background Check</h2>
          </div>
          <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4">
            <p className="text-sm font-semibold text-blue-900 mb-1">🔍 Manual Review Process</p>
            <p className="text-xs text-blue-800 leading-relaxed">
              Our team will manually review your submitted documents including your MVR (driving record) and conduct a background check before approving your account. This typically takes 1-3 business days. You will be notified by email once approved.
            </p>
          </div>
        </motion.div>

        {validationError && (
          <div className="bg-destructive/10 border-2 border-destructive rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              <p className="font-bold text-destructive text-sm">Document Validation Failed</p>
            </div>
            {validationError.license?.is_active !== true && (
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">Driver's License:</strong> {validationError.license?.reason || "Expired, unreadable, or missing expiration date."}
              </p>
            )}
            {validationError.age_verified_21 === false && (
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">Age Requirement:</strong> We could not verify from your license that you are at least 21 years old. ND law requires TNC drivers to be 21+. Please upload a clear photo of your license showing your date of birth.
              </p>
            )}
            {validationError.insurance?.is_active !== true && (
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">Insurance:</strong> {validationError.insurance?.reason || "Expired, unreadable, or missing expiration date."}
              </p>
            )}
            <p className="text-xs text-muted-foreground">Please upload a current, clearly readable document and submit again.</p>
          </div>
        )}

        <motion.button
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          onClick={handleSubmit}
          disabled={loading || !docs.drivers_license || !docs.vehicle_registration || !docs.insurance || !vehicle.make || !docs.profile_photo || !INSPECTION_ITEMS.every((_, i) => inspectionChecked[i]) || !ELIGIBILITY_ITEMS.every((_, i) => eligibilityChecked[i]) || !alcoholPolicyAgreed || !termsAgreed}
          className="w-full bg-primary text-white py-4 rounded-2xl font-bold text-base shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-40 mb-8"
        >
          {loading ? (
            <div className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              {validating ? "Validating documents..." : "Uploading..."}
            </div>
          ) : "Submit for Review"}
        </motion.button>
      </div>
    </div>
  );
}