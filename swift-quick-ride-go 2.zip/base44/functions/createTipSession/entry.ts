import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@17.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { rideId, tipAmount } = await req.json();

    if (!rideId || !tipAmount || tipAmount < 0) {
      return Response.json({ error: 'Invalid tip amount' }, { status: 400 });
    }

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"));
    
    // Get ride to find driver
    const rides = await base44.entities.Ride.filter({ id: rideId });
    if (!rides.length) {
      return Response.json({ error: 'Ride not found' }, { status: 404 });
    }

    const ride = rides[0];
    if (ride.status !== 'completed') {
      return Response.json({ error: 'Can only tip completed rides' }, { status: 400 });
    }

    // Create Stripe checkout session for tip
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: 'Driver Tip',
              description: `Tip for ${ride.driver_name}`,
            },
            unit_amount: Math.round(tipAmount * 100), // Convert to cents
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${req.headers.get('origin')}/customer-home?tip=success`,
      cancel_url: `${req.headers.get('origin')}/customer-home?tip=cancelled`,
      metadata: {
        base44_app_id: Deno.env.get("BASE44_APP_ID"),
        ride_id: rideId,
        driver_id: ride.driver_id,
        tip_amount: tipAmount.toString(),
        is_tip: 'true',
      },
    });

    return Response.json({ url: session.url });
  } catch (error) {
    console.error('Tip creation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});