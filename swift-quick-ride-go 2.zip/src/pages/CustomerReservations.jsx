import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, Clock, ChevronLeft, Calendar, X, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { calculateFare, fareBreakdown, FARE_RATES } from "@/utils/fareCalculator";
import AddressAutocomplete from "@/components/AddressAutocomplete";

function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 3958.8;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

const RIDE_TYPES = [
  { id: "economy", label: "Economy", emoji: "🚗" },
  { id: "comfort", label: "Comfort", emoji: "🚙" },
  { id: "premium", label: "Premium", emoji: "🏎️" },
];

export default function CustomerReservations() {
  const [user, setUser] = useState(null);
  const [reservations, setReservations] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [pickup, setPickup] = useState("");
  const [dropoff, setDropoff] = useState("");
  const [pickupCoords, setPickupCoords] = useState(null);
  const [dropoffCoords, setDropoffCoords] = useState(null);
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [rideType, setRideType] = useState("economy");
  const [notes, setNotes] = useState("");
  const [tripEstimate, setTripEstimate] = useState({ durationMin: 15, distanceMiles: 3.0 });
  const [userCoords, setUserCoords] = useState(null);

  useEffect(() => {
    base44.auth.me().then((me) => {
      setUser(me);
      if (me) loadReservations(me.id);
    });
    detectLocation();
  }, []);

  const detectLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition((pos) => {
      setUserCoords([pos.coords.latitude, pos.coords.longitude]);
    });
  };

  const loadReservations = async (customerId) => {
    const all = await base44.entities.Reservation.filter({ customer_id: customerId }, "-scheduled_time", 50);
    setReservations(all.filter((r) => r.status !== "cancelled"));
  };

  const handlePickupSelect = (location) => {
    setPickupCoords({ lat: location.lat, lng: location.lng });
    if (dropoffCoords) updateEstimate({ lat: location.lat, lng: location.lng }, dropoffCoords);
  };

  const handleDropoffSelect = (location) => {
    setDropoffCoords({ lat: location.lat, lng: location.lng });
    if (pickupCoords) updateEstimate(pickupCoords, { lat: location.lat, lng: location.lng });
  };

  const updateEstimate = async (pCoords, dCoords) => {
    try {
      const res = await fetch(
        `https://router.project-osrm.org/route/v1/driving/${pCoords.lng},${pCoords.lat};${dCoords.lng},${dCoords.lat}?overview=false`
      );
      const data = await res.json();
      if (data.routes?.[0]) {
        setTripEstimate({
          durationMin: Math.round(data.routes[0].duration / 60),
          distanceMiles: parseFloat((data.routes[0].distance * 0.000621371).toFixed(1)),
        });
      }
    } catch {
      const miles = haversineDistance(pCoords.lat, pCoords.lng, dCoords.lat, dCoords.lng) * 0.75;
      setTripEstimate({ durationMin: Math.round((miles / 65) * 60 + 3), distanceMiles: parseFloat(miles.toFixed(1)) });
    }
  };

  const handleSubmit = async () => {
    if (!pickup || !dropoff || !scheduledDate || !scheduledTime) {
      alert("Please fill in all required fields.");
      return;
    }
    const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
    if (scheduledDateTime <= new Date()) {
      alert("Please choose a future date and time.");
      return;
    }
    const minAdvance = new Date(Date.now() + 60 * 60 * 1000); // at least 1 hour ahead
    if (scheduledDateTime < minAdvance) {
      alert("Reservations must be made at least 1 hour in advance.");
      return;
    }
    setLoading(true);
    const fare = calculateFare(tripEstimate.durationMin, tripEstimate.distanceMiles, rideType);
    await base44.entities.Reservation.create({
      customer_id: user.id,
      customer_name: user.full_name,
      pickup_address: pickup,
      dropoff_address: dropoff,
      scheduled_time: scheduledDateTime.toISOString(),
      ride_type: rideType,
      estimated_fare: fare,
      estimated_duration_min: tripEstimate.durationMin,
      estimated_distance_miles: tripEstimate.distanceMiles,
      notes,
      status: "pending",
      payment_status: "unpaid",
      ...(pickupCoords && { pickup_lat: pickupCoords.lat, pickup_lng: pickupCoords.lng }),
      ...(dropoffCoords && { dropoff_lat: dropoffCoords.lat, dropoff_lng: dropoffCoords.lng }),
    });
    setLoading(false);
    setShowForm(false);
    resetForm();
    loadReservations(user.id);
  };

  const cancelReservation = async (id) => {
    if (!confirm("Cancel this reservation?")) return;
    await base44.entities.Reservation.update(id, { status: "cancelled" });
    loadReservations(user.id);
  };

  const resetForm = () => {
    setPickup(""); setDropoff(""); setPickupCoords(null); setDropoffCoords(null);
    setScheduledDate(""); setScheduledTime(""); setNotes(""); setRideType("economy");
    setTripEstimate({ durationMin: 15, distanceMiles: 3.0 });
  };

  const formatDateTime = (iso) => {
    const d = new Date(iso);
    return d.toLocaleString("en-US", { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", hour12: true });
  };

  const statusColor = (s) => ({
    pending: "bg-amber-100 text-amber-700",
    accepted: "bg-green-100 text-green-700",
    completed: "bg-secondary text-muted-foreground",
    cancelled: "bg-red-100 text-red-700",
  }[s] || "bg-secondary text-muted-foreground");

  // Min date = today
  const minDate = new Date().toISOString().split("T")[0];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="pb-6 px-5 bg-card border-b border-border" style={{ paddingTop: 'max(3rem, env(safe-area-inset-top, 3rem))' }}>
        <div className="flex items-center gap-3">
          <button onClick={() => window.location.href = "/customer-home"} className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </button>
          <div className="flex-1">
            <p className="text-foreground font-bold text-xl">My Reservations</p>
            <p className="text-muted-foreground text-sm">Schedule a future ride</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="h-10 px-4 bg-primary rounded-xl text-white font-bold text-sm active:scale-95 transition-transform"
          >
            + Book
          </button>
        </div>
      </div>

      <div className="px-5 py-5 space-y-4">
        {reservations.length === 0 && !showForm && (
          <div className="text-center py-16">
            <span className="text-6xl block mb-4">📅</span>
            <p className="font-bold text-lg">No reservations yet</p>
            <p className="text-muted-foreground text-sm mt-1 mb-6">Schedule a ride in advance</p>
            <button onClick={() => setShowForm(true)} className="bg-primary text-white px-8 py-3 rounded-2xl font-bold active:scale-95 transition-transform">
              Book a Reservation
            </button>
          </div>
        )}

        {reservations.map((r) => (
          <motion.div key={r.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-border rounded-2xl p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                <span className="font-bold text-sm">{formatDateTime(r.scheduled_time)}</span>
              </div>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${statusColor(r.status)}`}>
                {r.status === "accepted" ? "✅ Driver Assigned" : r.status.charAt(0).toUpperCase() + r.status.slice(1)}
              </span>
            </div>
            <div className="space-y-2 mb-3">
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                <span className="text-muted-foreground truncate">{r.pickup_address}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-3 h-3 text-destructive flex-shrink-0" />
                <span className="text-muted-foreground truncate">{r.dropoff_address}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span>~{r.estimated_duration_min} min</span>
                <span>·</span>
                <span>{r.estimated_distance_miles} mi</span>
                <span>·</span>
                <span className="capitalize">{r.ride_type}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold">${r.estimated_fare?.toFixed(2)}</span>
                {r.status === "pending" && (
                  <button onClick={() => cancelReservation(r.id)} className="text-xs text-destructive font-medium px-2 py-1 rounded-lg bg-destructive/10 active:scale-95 transition-transform">
                    Cancel
                  </button>
                )}
              </div>
            </div>
            {r.driver_name && (
              <div className="mt-3 pt-3 border-t border-border text-sm text-muted-foreground">
                🚗 Driver: <strong className="text-foreground">{r.driver_name}</strong>
              </div>
            )}
            {r.notes && (
              <p className="mt-2 text-xs text-muted-foreground italic">"{r.notes}"</p>
            )}
          </motion.div>
        ))}
      </div>

      {/* Booking Form Modal */}
      <AnimatePresence>
        {showForm && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 z-40" onClick={() => { setShowForm(false); resetForm(); }} />
            <motion.div
              initial={{ opacity: 0, y: "100%" }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 bg-card rounded-t-3xl z-50 max-h-[92vh] overflow-y-auto"
            >
              <div className="px-5 pt-5 pb-2 flex items-center justify-between sticky top-0 bg-card border-b border-border">
                <h2 className="text-lg font-bold">Book a Reservation</h2>
                <button onClick={() => { setShowForm(false); resetForm(); }} className="w-9 h-9 bg-secondary rounded-xl flex items-center justify-center">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="px-5 py-5 space-y-4">
                {/* Addresses */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Pickup</label>
                  <AddressAutocomplete placeholder="Pickup location" value={pickup} onChange={setPickup} onSelect={handlePickupSelect} icon="pin" userCoords={userCoords} />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Dropoff</label>
                  <AddressAutocomplete placeholder="Destination" value={dropoff} onChange={setDropoff} onSelect={handleDropoffSelect} icon="destination" userCoords={userCoords} />
                </div>

                {/* Date & Time */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-1">Date</label>
                    <input
                      type="date"
                      min={minDate}
                      value={scheduledDate}
                      onChange={(e) => setScheduledDate(e.target.value)}
                      className="w-full bg-secondary rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-1">Time</label>
                    <input
                      type="time"
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                      className="w-full bg-secondary rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>

                {/* Ride Type */}
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-2">Ride Type</label>
                  <div className="grid grid-cols-3 gap-2">
                    {RIDE_TYPES.map((t) => {
                      const bd = fareBreakdown(tripEstimate.durationMin, tripEstimate.distanceMiles, t.id);
                      return (
                        <button
                          key={t.id}
                          onClick={() => setRideType(t.id)}
                          className={`p-3 rounded-xl border-2 text-center transition-all ${rideType === t.id ? "border-primary bg-primary/5" : "border-border bg-card"}`}
                        >
                          <span className="text-2xl block mb-1">{t.emoji}</span>
                          <p className="text-xs font-bold">{t.label}</p>
                          <p className="text-xs text-muted-foreground">${bd.total}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Trip estimate */}
                {pickupCoords && dropoffCoords && (
                  <div className="flex items-center gap-3 bg-secondary rounded-xl px-4 py-3 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4 flex-shrink-0" />
                    <span>~{tripEstimate.durationMin} min</span>
                    <span className="text-border">·</span>
                    <span>{tripEstimate.distanceMiles} mi</span>
                    <span className="text-border">·</span>
                    <span className="font-bold text-foreground">${fareBreakdown(tripEstimate.durationMin, tripEstimate.distanceMiles, rideType).total}</span>
                  </div>
                )}

                {/* Notes */}
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-1">Notes (optional)</label>
                  <textarea
                    placeholder="Any special instructions for your driver..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={2}
                    className="w-full bg-secondary rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                  />
                </div>

                <p className="text-xs text-muted-foreground text-center">
                  ℹ️ Reservations must be made at least 1 hour in advance. A driver will accept your reservation before your ride time.
                </p>

                <button
                  onClick={handleSubmit}
                  disabled={loading || !pickup || !dropoff || !scheduledDate || !scheduledTime}
                  className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-40"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
                  ) : (
                    `Request Reservation · $${fareBreakdown(tripEstimate.durationMin, tripEstimate.distanceMiles, rideType).total}`
                  )}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}