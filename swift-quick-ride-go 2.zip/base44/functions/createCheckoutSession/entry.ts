import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.21.0';

Deno.serve(async (req) => {
  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { rideId } = await req.json();

    if (!rideId) {
      return Response.json({ error: 'Missing rideId' }, { status: 400 });
    }

    // Look up the ride server-side — never trust an amount sent from the phone
    const rides = await base44.asServiceRole.entities.Ride.filter({ id: rideId });
    if (!rides.length) {
      return Response.json({ error: 'Ride not found' }, { status: 404 });
    }
    const ride = rides[0];
    if (!ride.estimated_fare || ride.estimated_fare <= 0) {
      return Response.json({ error: 'Ride has no valid fare' }, { status: 400 });
    }
    const rideType = ride.ride_type;
    const pickupAddress = ride.pickup_address;
    const dropoffAddress = ride.dropoff_address;
    const amountCents = Math.round(ride.estimated_fare * 100);

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      customer_creation: 'always',
      customer_email: user.email || undefined,
      payment_intent_data: {
        setup_future_usage: 'off_session',
      },
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: `${rideType ? rideType.charAt(0).toUpperCase() + rideType.slice(1) : 'Economy'} Ride`,
              description: `${pickupAddress} → ${dropoffAddress}`,
            },
            unit_amount: amountCents,
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${req.headers.get('origin') || 'https://app.base44.com'}/customer-ride-tracking?rideId=${rideId}&paid=true`,
      cancel_url: `${req.headers.get('origin') || 'https://app.base44.com'}/customer-home`,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        ride_id: rideId,
      },
    });

    // Mark ride as payment pending
    await base44.asServiceRole.entities.Ride.update(rideId, { payment_status: 'pending' });

    return Response.json({ url: session.url });
  } catch (error) {
    console.error('Stripe checkout error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});