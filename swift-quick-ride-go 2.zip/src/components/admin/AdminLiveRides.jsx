import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, Clock, Navigation, RefreshCw } from "lucide-react";

const STATUS_COLORS = {
  requested: "bg-amber-100 text-amber-700",
  accepted: "bg-blue-100 text-blue-700",
  en_route: "bg-blue-100 text-blue-700",
  arrived: "bg-purple-100 text-purple-700",
  in_progress: "bg-primary/10 text-primary",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

const ACTIVE_STATUSES = ["requested", "accepted", "en_route", "arrived", "in_progress"];

export default function AdminLiveRides() {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const loadRides = async () => {
    setLoading(true);
    const all = await base44.entities.Ride.list("-created_date", 100);
    setRides(all.filter((r) => ACTIVE_STATUSES.includes(r.status)));
    setLastRefresh(new Date());
    setLoading(false);
  };

  useEffect(() => {
    loadRides();
    const unsub = base44.entities.Ride.subscribe((event) => {
      setRides((prev) => {
        if (event.type === "delete") return prev.filter((r) => r.id !== event.id);
        const updated = event.data;
        if (!ACTIVE_STATUSES.includes(updated.status)) return prev.filter((r) => r.id !== updated.id);
        const exists = prev.find((r) => r.id === updated.id);
        if (exists) return prev.map((r) => r.id === updated.id ? updated : r);
        return [updated, ...prev];
      });
    });
    return unsub;
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground text-sm">
            {rides.length} active ride{rides.length !== 1 ? "s" : ""} · Last updated {lastRefresh.toLocaleTimeString()}
          </p>
        </div>
        <button onClick={loadRides} className="flex items-center gap-2 bg-secondary px-4 py-2 rounded-xl text-sm font-medium hover:bg-border transition-colors">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {rides.length === 0 ? (
        <div className="text-center py-16 bg-card border border-border rounded-2xl">
          <div className="text-5xl mb-3">🚗</div>
          <p className="font-semibold">No active rides right now</p>
          <p className="text-muted-foreground text-sm mt-1">Active rides will appear here in real time</p>
        </div>
      ) : (
        <div className="space-y-3">
          {rides.map((ride) => (
            <div key={ride.id} className="bg-card border border-border rounded-2xl p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${STATUS_COLORS[ride.status] || "bg-secondary text-foreground"}`}>
                      {ride.status.replace("_", " ")}
                    </span>
                    <span className="text-xs text-muted-foreground capitalize">{ride.ride_type}</span>
                  </div>
                  <p className="font-bold">{ride.customer_name || "Customer"}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-primary">${ride.estimated_fare?.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">{new Date(ride.created_date).toLocaleTimeString()}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex flex-col items-center gap-1 mt-1">
                  <div className="w-2 h-2 bg-primary rounded-full" />
                  <div className="w-0.5 h-6 bg-border" />
                  <MapPin className="w-3 h-3 text-destructive" />
                </div>
                <div className="flex-1 space-y-2">
                  <p className="text-sm text-muted-foreground">{ride.pickup_address}</p>
                  <p className="text-sm font-medium">{ride.dropoff_address}</p>
                </div>
              </div>

              {ride.driver_name && (
                <div className="mt-3 pt-3 border-t border-border flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Driver: <span className="text-foreground font-medium">{ride.driver_name}</span></span>
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <div className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{ride.estimated_duration_min} min</div>
                    <div className="flex items-center gap-1"><Navigation className="w-3.5 h-3.5" />{ride.estimated_distance_miles} mi</div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}