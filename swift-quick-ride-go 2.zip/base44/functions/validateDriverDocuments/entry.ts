import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { license_url, insurance_url } = await req.json();
    if (!license_url || !insurance_url) {
      return Response.json({ error: 'license_url and insurance_url are required' }, { status: 400 });
    }

    const today = new Date().toISOString().split('T')[0];

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Today's date is ${today}. You are verifying documents for a rideshare driver applicant.

Two files are attached IN THIS ORDER:
1. The first file should be a DRIVER'S LICENSE.
2. The second file should be a CAR INSURANCE card or policy document.

For EACH document:
- Confirm it is actually the correct document type (a real driver's license / a real auto insurance document).
- Extract the expiration date in YYYY-MM-DD format.
- Determine if it is currently ACTIVE (expiration date is on or after today, ${today}).
- If the document is unreadable, the wrong type, or has no visible expiration date, mark is_active as false and explain why in the reason field.

For the DRIVER'S LICENSE additionally:
- Extract the date of birth in YYYY-MM-DD format.
- Determine whether the driver is at least 21 years old as of today (${today}). Set is_21_or_older accordingly.
- If you cannot clearly read the date of birth, set is_21_or_older to false and explain why in the reason field.

Be strict: only mark a document active if you can clearly read a valid expiration date that has not passed.`,
      file_urls: [license_url, insurance_url],
      response_json_schema: {
        type: 'object',
        properties: {
          license: {
            type: 'object',
            properties: {
              is_correct_document_type: { type: 'boolean' },
              expiration_date: { type: 'string' },
              date_of_birth: { type: 'string' },
              is_21_or_older: { type: 'boolean' },
              is_active: { type: 'boolean' },
              reason: { type: 'string' }
            }
          },
          insurance: {
            type: 'object',
            properties: {
              is_correct_document_type: { type: 'boolean' },
              expiration_date: { type: 'string' },
              is_active: { type: 'boolean' },
              reason: { type: 'string' }
            }
          }
        }
      }
    });

    const licenseActive = result?.license?.is_active === true;
    const insuranceActive = result?.insurance?.is_active === true;
    const ageVerified = result?.license?.is_21_or_older === true;
    const documentsValid = licenseActive && insuranceActive && ageVerified;

    const notes = [
      `License: ${licenseActive ? 'active' : 'invalid'} (exp: ${result?.license?.expiration_date || 'unknown'})${result?.license?.reason ? ' - ' + result.license.reason : ''}`,
      `Age 21+: ${ageVerified ? 'verified' : 'NOT verified'} (DOB: ${result?.license?.date_of_birth || 'unknown'})`,
      `Insurance: ${insuranceActive ? 'active' : 'invalid'} (exp: ${result?.insurance?.expiration_date || 'unknown'})${result?.insurance?.reason ? ' - ' + result.insurance.reason : ''}`
    ].join(' | ');

    await base44.asServiceRole.entities.User.update(user.id, {
      license_expiration_date: result?.license?.expiration_date || null,
      insurance_expiration_date: result?.insurance?.expiration_date || null,
      documents_valid: documentsValid,
      documents_validation_notes: notes,
      age_verified_21: ageVerified,
      date_of_birth: result?.license?.date_of_birth || null
    });

    console.log(`Document validation for ${user.email}: ${notes}`);

    return Response.json({
      documents_valid: documentsValid,
      age_verified_21: ageVerified,
      license: result?.license || null,
      insurance: result?.insurance || null
    });
  } catch (error) {
    console.error('Document validation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});