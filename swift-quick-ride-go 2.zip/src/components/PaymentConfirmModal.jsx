import { motion } from "framer-motion";
import { CreditCard, X } from "lucide-react";

export default function PaymentConfirmModal({ fare, rideType, savedCard, onUseCard, onNewCard, onCancel, loading }) {
  const brandEmoji = { visa: "💳", mastercard: "💳", amex: "💳", discover: "💳" };

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 z-40"
        onClick={onCancel}
      />
      <motion.div
        initial={{ y: "100%", opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: "100%", opacity: 0 }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        className="fixed bottom-0 left-0 right-0 bg-card rounded-t-3xl z-50 p-6 pb-10"
      >
        <button onClick={onCancel} className="absolute top-4 right-4 w-9 h-9 bg-secondary rounded-xl flex items-center justify-center">
          <X className="w-4 h-4" />
        </button>

        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <CreditCard className="w-7 h-7 text-primary" />
          </div>
          <h2 className="text-xl font-bold">Confirm Payment</h2>
          <p className="text-muted-foreground text-sm mt-1">
            {rideType?.charAt(0).toUpperCase() + rideType?.slice(1)} ride · <span className="font-bold text-foreground">${fare?.toFixed(2)}</span>
          </p>
        </div>

        {savedCard && (
          <>
            <div className="bg-secondary rounded-2xl p-4 mb-4">
              <p className="text-xs text-muted-foreground mb-1">CARD ON FILE</p>
              <div className="flex items-center gap-3">
                <span className="text-2xl">{brandEmoji[savedCard.brand] || "💳"}</span>
                <div>
                  <p className="font-bold capitalize">{savedCard.brand} •••• {savedCard.last4}</p>
                  <p className="text-xs text-muted-foreground">Expires {savedCard.exp_month}/{savedCard.exp_year}</p>
                </div>
              </div>
            </div>
            <button
              onClick={onUseCard}
              disabled={loading}
              className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform mb-3"
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Charging card...
                </div>
              ) : `Use ${savedCard.brand} •••• ${savedCard.last4}`}
            </button>
            <button
              onClick={onNewCard}
              disabled={loading}
              className="w-full border-2 border-border text-foreground py-4 rounded-2xl font-bold active:scale-95 transition-transform"
            >
              Use a Different Card
            </button>
          </>
        )}

        {!savedCard && (
          <button
            onClick={onNewCard}
            disabled={loading}
            className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform"
          >
            {loading ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Loading...
              </div>
            ) : "Pay with Card"}
          </button>
        )}
      </motion.div>
    </>
  );
}