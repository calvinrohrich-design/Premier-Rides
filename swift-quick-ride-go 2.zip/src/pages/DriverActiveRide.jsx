import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Phone, MessageCircle, Navigation, MapPin, CheckCircle, Clock, DollarSign, User } from "lucide-react";
import { fareBreakdown, driverEarnings } from "@/utils/fareCalculator";
import { motion, AnimatePresence } from "framer-motion";
import LiveMap from "@/components/LiveMap";
import RideChat from "@/components/RideChat";
import QueuedRideCard from "@/components/QueuedRideCard";
import TurnByTurnBanner from "@/components/TurnByTurnBanner";


const DEFAULT_PICKUP = null;
const DEFAULT_DROPOFF = null;
const DEFAULT_DRIVER = null;

const RIDE_FLOW = [
  { status: "accepted", label: "Head to Pickup", action: "I've Arrived", nextStatus: "arrived", color: "bg-blue-500" },
  { status: "arrived", label: "Waiting for Rider", action: "Start Ride", nextStatus: "in_progress", color: "bg-amber-500" },
  { status: "in_progress", label: "Ride in Progress", action: "Complete Ride", nextStatus: "completed", color: "bg-primary" },
];

export default function DriverActiveRide() {
  const [ride, setRide] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [driverCoords, setDriverCoords] = useState(null);
  const [queuedRide, setQueuedRide] = useState(null);
  const [startingNext, setStartingNext] = useState(false);
  const [gpsError, setGpsError] = useState(null);
  const distanceRef = useRef(0); // accumulated miles during in_progress
  const lastCoordsRef = useRef(null); // last GPS coords for distance calc

  const rideId = new URLSearchParams(window.location.search).get("rideId");

  // When the ride completes, check for a queued next ride
  useEffect(() => {
    if (!(completed || ride?.status === "completed") || !currentUser) return;
    base44.entities.Ride.filter({ status: "requested", queued_driver_id: currentUser.id }).then((rides) => {
      setQueuedRide(rides[0] || null);
    });
  }, [completed, ride?.status, currentUser?.id]);

  const startNextRide = async () => {
    if (!queuedRide) return;
    setStartingNext(true);
    // Make sure it wasn't taken by another driver in the meantime
    const fresh = await base44.entities.Ride.filter({ id: queuedRide.id });
    if (!fresh.length || fresh[0].status !== "requested") {
      alert("This ride is no longer available.");
      setQueuedRide(null);
      setStartingNext(false);
      return;
    }
    await base44.entities.Ride.update(queuedRide.id, {
      status: "accepted",
      driver_id: currentUser?.id,
      driver_name: currentUser?.full_name,
      driver_rating: currentUser?.rating || 4.9,
      vehicle_info: `${currentUser?.vehicle_color || ""} ${currentUser?.vehicle_make || ""} ${currentUser?.vehicle_model || ""}`.trim() || "Vehicle",
      license_plate: currentUser?.license_plate || "",
      driver_eta_min: Math.floor(3 + Math.random() * 7),
      driver_photo_url: currentUser?.profile_photo_url || null,
    });
    window.location.href = `/driver-active-ride?rideId=${queuedRide.id}`;
  };

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
    if (!rideId || !navigator.geolocation) return;

    // Wake Lock — keep screen on while driving
    let wakeLock = null;
    const requestWakeLock = async () => {
      if ("wakeLock" in navigator) {
        try {
          wakeLock = await navigator.wakeLock.request("screen");
        } catch (e) {
          console.warn("Wake lock failed:", e);
        }
      }
    };
    requestWakeLock();
    const handleVisibility = () => {
      if (document.visibilityState === "visible") requestWakeLock();
    };
    document.addEventListener("visibilitychange", handleVisibility);

    // GPS watch with auto-restart on error
    let watchId = null;
    let retryTimer = null;
    let lastWrite = 0;
    let lastAccepted = 0;
    // Remote GPS diagnostics — throttled to 1 log per event type per 20s
    const lastLog = {};
    const gpsLog = (event, detail) => {
      const now = Date.now();
      if (lastLog[event] && now - lastLog[event] < 20000) return;
      lastLog[event] = now;
      base44.entities.GpsLog.create({ ride_id: rideId, event, detail: String(detail || "") }).catch(() => {});
    };
    gpsLog("watch_started", `geolocation available: ${!!navigator.geolocation}`);
    const startWatch = () => {
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          // Skip only very inaccurate fixes (cell-tower positions can be blocks off),
          // but never go dark: accept anything if we haven't had a fix in 15s
          const acc = pos.coords.accuracy || 0;
          const staleFor = Date.now() - lastAccepted;
          if (acc > 200 && staleFor < 15000) {
            console.warn('[DriverActiveRide] Skipping low-accuracy fix:', acc, 'm');
            gpsLog("fix_skipped", `accuracy ${Math.round(acc)}m`);
            return;
          }
          if (!lastAccepted) gpsLog("first_fix_accepted", `accuracy ${Math.round(acc)}m`);
          lastAccepted = Date.now();
          const coords = [pos.coords.latitude, pos.coords.longitude];
          setDriverCoords(coords);
          setGpsError(null);

          // Accumulate actual distance while ride is in_progress
          setRide((currentRide) => {
            if (currentRide?.status === "in_progress" && lastCoordsRef.current) {
              const [lat1, lng1] = lastCoordsRef.current;
              const lat2 = pos.coords.latitude;
              const lng2 = pos.coords.longitude;
              const R = 3958.8;
              const dLat = (lat2 - lat1) * Math.PI / 180;
              const dLon = (lng2 - lng1) * Math.PI / 180;
              const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
              const miles = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
              if (miles > 0.01) distanceRef.current += miles; // ignore tiny jitter
            }
            lastCoordsRef.current = [pos.coords.latitude, pos.coords.longitude];
            return currentRide;
          });

          // Throttle database writes to once every 4s to avoid overloading the app
          const now = Date.now();
          if (now - lastWrite >= 4000) {
            lastWrite = now;
            base44.entities.Ride.update(rideId, { driver_lat: pos.coords.latitude, driver_lng: pos.coords.longitude }).catch((err) => {
              console.warn('[DriverActiveRide] Failed to update driver location:', err?.message);
              gpsLog("write_failed", err?.message);
            });
          }
        },
        (err) => {
          console.warn('[DriverActiveRide] GPS error, retrying in 3s:', err?.message);
          gpsLog("gps_error", `code ${err?.code}: ${err?.message}`);
          setGpsError(err?.code === 1 ? "blocked" : "weak");
          clearTimeout(retryTimer);
          retryTimer = setTimeout(startWatch, 3000);
        },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 }
      );
    };
    startWatch();

    return () => {
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
      clearTimeout(retryTimer);
      document.removeEventListener("visibilitychange", handleVisibility);
      if (wakeLock) wakeLock.release().catch(() => {});
    };
  }, [rideId]);

  // Re-fetch ride when screen wakes up
  useEffect(() => {
    if (!rideId) return;
    const handleVisibility = async () => {
      if (document.visibilityState === "visible") {
        const rides = await base44.entities.Ride.filter({ id: rideId });
        if (rides.length) setRide(rides[0]);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);
    return () => document.removeEventListener("visibilitychange", handleVisibility);
  }, [rideId]);

  useEffect(() => {
    if (!rideId) {
      console.log('[DriverActiveRide] No rideId in URL, redirecting to driver home');
      window.location.replace('/driver-home');
      return;
    }
    
    console.log('[DriverActiveRide] Loading ride:', rideId);
    let mounted = true;
    
    const loadRide = async () => {
      try {
        const rides = await base44.entities.Ride.filter({ id: rideId });
        console.log('[DriverActiveRide] Ride query result:', rides);
        if (mounted) {
          if (rides.length) {
            setRide(rides[0]);
            console.log('[DriverActiveRide] Ride loaded successfully:', rides[0].status);
          } else {
            console.log('[DriverActiveRide] No ride found with id:', rideId);
          }
          setLoading(false);
        }
      } catch (err) {
        console.error('[DriverActiveRide] Failed to load ride:', err);
        if (mounted) setLoading(false);
      }
    };
    
    loadRide();
    
    const unsub = base44.entities.Ride.subscribe((event) => {
      if (event.id === rideId) {
        console.log('[DriverActiveRide] Ride update:', event.data?.status);
        setRide(event.data);
      }
    });
    
    return () => {
      mounted = false;
      unsub();
    };
  }, [rideId]);

  const currentStep = RIDE_FLOW.find((s) => s.status === ride?.status);

  const handleAction = async () => {
    if (!currentStep) return;
    setActionLoading(true);
    const updates = { status: currentStep.nextStatus };
    if (currentStep.nextStatus === "in_progress") {
      updates.ride_start_time = new Date().toISOString();
    }
    if (currentStep.nextStatus === "completed") {
      updates.ride_end_time = new Date().toISOString();
      if (distanceRef.current > 0) {
        updates.actual_distance_miles = parseFloat(distanceRef.current.toFixed(2));
      }
    }
    await base44.entities.Ride.update(rideId, updates);
    if (currentStep.nextStatus === "completed") {
      setCompleted(true);
    }
    setActionLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="w-12 h-12 border-4 border-border border-t-primary rounded-full animate-spin mb-4" />
        <p className="font-semibold text-lg">Loading your ride...</p>
        <p className="text-muted-foreground text-sm mt-2 text-center">If this takes too long, you can return to the dashboard</p>
        <button
          onClick={() => window.location.href = "/driver-home"}
          className="mt-6 bg-secondary text-foreground px-6 py-3 rounded-2xl font-semibold"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  if (!ride) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
        <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mb-4">
          <MapPin className="w-10 h-10 text-destructive" />
        </div>
        <h2 className="text-2xl font-bold">Ride Not Found</h2>
        <p className="text-muted-foreground mt-2 max-w-sm">
          We couldn't load your active ride. It may have been cancelled or already completed.
        </p>
        <button
          onClick={() => window.location.href = "/driver-home"}
          className="mt-6 w-full max-w-sm bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  if (completed || ride?.status === "completed") {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.2 }} className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <CheckCircle className="w-12 h-12 text-primary" />
        </motion.div>
        <h2 className="text-3xl font-bold">Ride Complete!</h2>
        <p className="text-muted-foreground mt-2">Great job delivering safely</p>
        {(() => {
          const bd = ride ? fareBreakdown(ride.estimated_duration_min, ride.estimated_distance_miles, ride.ride_type) : null;
          return (
            <div className="bg-card border border-border rounded-2xl p-5 mt-6 w-full max-w-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-muted-foreground text-sm">You Earned (70%)</p>
                  <p className="font-bold text-3xl text-primary">${driverEarnings(parseFloat(bd?.total || ride?.estimated_fare || 0)).toFixed(2)}</p>
                </div>
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center">
                  <DollarSign className="w-7 h-7 text-primary" />
                </div>
              </div>
              {bd && (
                <div className="space-y-1.5 text-sm border-t border-border pt-4">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Base charge</span><span>${bd.base}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>{ride.estimated_duration_min} min × $0.35</span><span>${bd.time}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>{ride.estimated_distance_miles} mi × $1.50</span><span>${bd.distance}</span>
                  </div>
                  {bd.multiplier > 1 && (
                    <div className="flex justify-between text-muted-foreground">
                      <span className="capitalize">{ride.ride_type} multiplier</span><span>×{bd.multiplier}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-muted-foreground pt-1 border-t border-border">
                    <span>Total fare</span><span>${bd.total}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Your share (70%)</span><span className="text-primary">${driverEarnings(parseFloat(bd.total)).toFixed(2)}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })()}
        {queuedRide && (
          <div className="bg-primary/5 border-2 border-primary rounded-2xl p-4 mt-6 w-full max-w-sm text-left">
            <p className="font-bold text-primary text-sm mb-1">🚗 Next Ride Queued</p>
            <p className="font-semibold text-sm truncate">{queuedRide.pickup_address}</p>
            <p className="text-muted-foreground text-xs truncate">→ {queuedRide.dropoff_address}</p>
            <button
              onClick={startNextRide}
              disabled={startingNext}
              className="mt-3 w-full bg-primary text-white py-3 rounded-xl font-bold active:scale-95 transition-transform disabled:opacity-60"
            >
              {startingNext ? "Starting..." : `Start Next Ride · $${driverEarnings(queuedRide.estimated_fare).toFixed(2)}`}
            </button>
          </div>
        )}
        <button onClick={() => window.location.href = "/driver-home"} className="mt-6 w-full max-w-sm bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30">
          Back to Dashboard
        </button>
      </motion.div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Live Map */}
      <div className="relative" style={{ height: "50vh" }}>
        <LiveMap
          pickupCoords={ride?.pickup_lat ? [ride.pickup_lat, ride.pickup_lng] : null}
          dropoffCoords={ride?.dropoff_lat ? [ride.dropoff_lat, ride.dropoff_lng] : null}
          driverCoords={driverCoords}
          showRoute={true}
          followDriver={true}
          routeTo={ride?.status === "in_progress" ? "dropoff" : "pickup"}
          height="50vh"
        />
        {/* Status bar overlay — safe area aware for all iOS devices */}
        <div className={`absolute top-0 left-0 right-0 z-10 ${currentStep?.color || "bg-primary"} pb-3 px-5`} style={{ paddingTop: 'max(48px, env(safe-area-inset-top, 48px))' }}>
          <div className="flex items-center justify-between">
            <button
              onClick={() => window.location.href = "/driver-home"}
              className="text-white/80 hover:text-white text-sm font-semibold"
            >
              ← Back
            </button>
            <div className="flex-1 text-center">
              <p className="text-white font-bold">{currentStep?.label || "Active Ride"}</p>
            </div>
            <div className="w-12" />
          </div>
          <p className="text-white/70 text-sm mt-1">{ride?.status === "in_progress" ? `→ ${ride?.dropoff_address}` : `→ ${ride?.pickup_address}`}</p>
        </div>
      </div>

      {/* Bottom Sheet */}
      <div className="bg-background rounded-t-3xl -mt-6 relative z-10 flex-1 px-5 pt-6 pb-8">
        <div className="w-10 h-1 bg-border rounded-full mx-auto mb-5" />

        {/* GPS status indicator */}
        {gpsError ? (
          <div className="bg-destructive/10 border border-destructive rounded-2xl px-4 py-3 mb-4 text-sm">
            <p className="font-bold text-destructive">⚠️ GPS not working</p>
            <p className="text-muted-foreground text-xs mt-0.5">
              {gpsError === "blocked"
                ? "Location permission is blocked. Enable it in your phone's browser settings (Settings → Safari/Chrome → Location → Allow), then reload."
                : "Weak GPS signal — trying again... Make sure location services are on."}
            </p>
          </div>
        ) : driverCoords ? (
          <div className="flex items-center gap-2 mb-4 text-xs text-muted-foreground">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            GPS active — customer can see you live
          </div>
        ) : (
          <div className="flex items-center gap-2 mb-4 text-xs text-muted-foreground">
            <span className="w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
            Getting GPS signal... (allow location when prompted)
          </div>
        )}

        {/* In-app turn-by-turn directions */}
        {driverCoords && (
          <div className="mb-4">
            <TurnByTurnBanner
              from={driverCoords}
              to={ride?.status === "in_progress"
                ? (ride?.dropoff_lat ? [ride.dropoff_lat, ride.dropoff_lng] : null)
                : (ride?.pickup_lat ? [ride.pickup_lat, ride.pickup_lng] : null)}
            />
          </div>
        )}

        {/* Next ride queue offer */}
        {currentUser && <QueuedRideCard currentUser={currentUser} activeRideId={rideId} />}

        {/* Customer Card */}
        <div className="bg-card border border-border rounded-2xl p-4 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-bold">{ride?.customer_name || "Customer"}</p>
                <p className="text-muted-foreground text-xs capitalize">{ride?.ride_type} ride</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center active:scale-90 transition-transform">
                <Phone className="w-5 h-5 text-primary" />
              </button>
              <button onClick={() => setShowChat(true)} className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center active:scale-90 transition-transform">
                <MessageCircle className="w-5 h-5 text-primary" />
              </button>
            </div>
          </div>
        </div>

        {/* Route */}
        <div className="bg-secondary rounded-2xl p-4 mb-4">
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center gap-1 mt-1">
              <div className="w-2.5 h-2.5 bg-primary rounded-full" />
              <div className="w-0.5 h-8 bg-border" />
              <MapPin className="w-3 h-3 text-destructive" />
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <p className="text-xs text-muted-foreground">PICKUP</p>
                <p className="font-semibold text-sm">{ride?.pickup_address}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">DROPOFF</p>
                <p className="font-semibold text-sm">{ride?.dropoff_address}</p>
              </div>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-border flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-sm">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span>{ride?.estimated_duration_min} min</span>
            </div>
            <div className="flex items-center gap-1.5 text-sm">
              <Navigation className="w-4 h-4 text-muted-foreground" />
              <span>{ride?.estimated_distance_miles} mi</span>
            </div>
            <div className="ml-auto font-bold text-primary">${ride?.estimated_fare?.toFixed(2)}</div>
          </div>
          {/* Map view note */}
          <div className="mt-3 flex items-center justify-between">
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <span className="w-2 h-2 bg-primary rounded-full"></span>
              Live navigation active on map above
            </p>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="text-xs font-semibold text-primary flex items-center gap-1"
            >
              View Map ↑
            </button>
          </div>
        </div>

        {/* Steps progress */}
        <div className="flex items-center gap-2 mb-5">
          {RIDE_FLOW.map((step, i) => {
            const flowIndex = RIDE_FLOW.findIndex((s) => s.status === ride?.status);
            const isDone = i < flowIndex;
            const isActive = i === flowIndex;
            return (
              <div key={step.status} className="flex items-center gap-2 flex-1">
                <div className={`h-1.5 flex-1 rounded-full ${isDone || isActive ? "bg-primary" : "bg-border"}`} />
                {i === RIDE_FLOW.length - 1 && <div className={`h-1.5 flex-1 rounded-full ${isDone ? "bg-primary" : "bg-border"}`} />}
              </div>
            );
          })}
        </div>

        {currentStep && (
          <button
            onClick={handleAction}
            disabled={actionLoading}
            className={`w-full ${currentStep.color} text-white py-4 rounded-2xl font-bold text-base shadow-lg active:scale-95 transition-transform disabled:opacity-60`}
          >
            {actionLoading ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Updating...
              </div>
            ) : currentStep.action}
          </button>
        )}
      </div>

      {/* Chat */}
      <AnimatePresence>
        {showChat && currentUser && (
          <RideChat
            rideId={rideId}
            currentUser={currentUser}
            senderRole="driver"
            otherName={ride?.customer_name || "Customer"}
            onClose={() => setShowChat(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}