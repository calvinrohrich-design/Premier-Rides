import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const { rideId } = await req.json();

    if (!rideId) {
      return Response.json({ error: 'Missing rideId' }, { status: 400 });
    }

    const rides = await base44.asServiceRole.entities.Ride.filter({ id: rideId });
    if (!rides.length) {
      return Response.json({ error: 'Ride not found' }, { status: 404 });
    }
    const ride = rides[0];

    // Get customer email
    const customers = await base44.asServiceRole.entities.User.filter({ id: ride.customer_id });
    if (!customers.length) {
      return Response.json({ error: 'Customer not found' }, { status: 404 });
    }
    const customer = customers[0];

    const fare = ride.final_fare || ride.estimated_fare || 0;
    const tip = ride.tip_amount || 0;
    const total = fare + tip;
    const rideDate = new Date(ride.updated_date || ride.created_date).toLocaleString('en-US', {
      timeZone: 'America/Chicago',
      dateStyle: 'full',
      timeStyle: 'short',
    });

    const body = `
Hi ${customer.full_name},

Thank you for riding with EW Premier Ride! Here is your electronic receipt as required by North Dakota TNC regulations.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TRIP RECEIPT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Date: ${rideDate}
Ride Type: ${ride.ride_type ? ride.ride_type.charAt(0).toUpperCase() + ride.ride_type.slice(1) : 'Economy'}

📍 ORIGIN
${ride.pickup_address}

🏁 DESTINATION
${ride.dropoff_address}

⏱ TRIP DETAILS
Duration: ${ride.estimated_duration_min || '-'} min
Distance: ${ride.estimated_distance_miles || '-'} miles

👤 DRIVER
${ride.driver_name || 'N/A'}  |  ⭐ ${ride.driver_rating || 'N/A'}
Vehicle: ${ride.vehicle_info || 'N/A'}
License Plate: ${ride.license_plate || 'N/A'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FARE BREAKDOWN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Base Fare:        $${fare.toFixed(2)}
Tip:              $${tip.toFixed(2)}
─────────────────────────────
TOTAL:            $${total.toFixed(2)}

Payment Status: ${ride.payment_status === 'paid' ? 'Paid ✅' : 'Pending'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This receipt is provided in compliance with North Dakota Century Code § 39-34.
Thank you for choosing EW Premier Ride!
    `.trim();

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: customer.email,
      subject: `Your EW Premier Ride Receipt — $${total.toFixed(2)}`,
      body,
    });

    console.log(`Receipt sent to ${customer.email} for ride ${rideId}`);
    return Response.json({ success: true });
  } catch (error) {
    console.error('sendRideReceipt error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});