import { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Car, User, Eye, EyeOff, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

export default function SignUpPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const [role, setRole] = useState(urlParams.get("role") === "driver" ? "driver" : "customer");
  const [form, setForm] = useState({ full_name: "", email: "", password: "", confirmPassword: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState("register"); // register | otp | upgrade
  const [otp, setOtp] = useState("");

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    setLoading(true);
    try {
      await base44.auth.register({ email: form.email, password: form.password });
      setStep("otp");
    } catch (err) {
      // Email already exists — offer role upgrade via login
      setStep("upgrade");
      setError("");
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await base44.auth.verifyOtp({ email: form.email, otpCode: otp });
      base44.auth.setToken(res.access_token);
      await base44.auth.updateMe({ full_name: form.full_name, user_type: role });
      window.location.href = "/welcome";
    } catch (err) {
      setError(err?.message || "Invalid code. Please try again.");
      setLoading(false);
    }
  };

  const handleUpgradeRole = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(form.email, form.password);
      const user = await base44.auth.me();
      // Determine new combined user_type
      const currentType = user.user_type || "customer";
      let newRole = role;
      if (currentType === "customer" && role === "driver") newRole = "both";
      else if (currentType === "driver" && role === "customer") newRole = "both";
      else if (currentType === "both") newRole = "both";
      await base44.auth.updateMe({ user_type: newRole });
      window.location.href = "/welcome";
    } catch (err) {
      setError(err?.message || "Incorrect password. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-foreground pt-14 pb-10 px-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-primary/20 rounded-full -translate-y-16 translate-x-16" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-primary/10 rounded-full translate-y-12 -translate-x-8" />
        <div className="relative z-10">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center mb-4">
            <Car className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">Create Account</h1>
          <p className="text-white/60 mt-1">Join thousands of riders & drivers</p>
        </div>
      </div>

      <div className="flex-1 px-6 py-8 -mt-4 bg-background rounded-t-3xl">

        {step === "register" && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            {/* Role Toggle */}
            <div className="flex gap-3 mb-7">
              {["customer", "driver"].map((r) => (
                <button
                  key={r}
                  onClick={() => setRole(r)}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl font-semibold text-sm transition-all ${
                    role === r
                      ? "bg-primary text-white shadow-lg shadow-primary/30"
                      : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {r === "customer" ? <User className="w-4 h-4" /> : <Car className="w-4 h-4" />}
                  {r.charAt(0).toUpperCase() + r.slice(1)}
                </button>
              ))}
            </div>

            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="text-sm font-semibold text-foreground/70 mb-1.5 block">Full Name</label>
                <input
                  type="text"
                  placeholder="John Doe"
                  value={form.full_name}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                  className="w-full bg-secondary rounded-2xl px-4 py-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-base"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-semibold text-foreground/70 mb-1.5 block">Email</label>
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full bg-secondary rounded-2xl px-4 py-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-base"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-semibold text-foreground/70 mb-1.5 block">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Min. 8 characters"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    className="w-full bg-secondary rounded-2xl px-4 py-4 pr-12 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-base"
                    required
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="text-sm font-semibold text-foreground/70 mb-1.5 block">Confirm Password</label>
                <input
                  type="password"
                  placeholder="Repeat password"
                  value={form.confirmPassword}
                  onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
                  className="w-full bg-secondary rounded-2xl px-4 py-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-base"
                  required
                />
              </div>

              {error && <p className="text-destructive text-sm font-medium">{error}</p>}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-white py-4 rounded-2xl font-bold text-base mt-2 flex items-center justify-center gap-2 shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-60"
              >
                {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Create Account <ChevronRight className="w-5 h-5" /></>}
              </button>
            </form>
          </motion.div>
        )}

        {step === "upgrade" && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🔄</span>
              </div>
              <h2 className="text-2xl font-bold">Account Exists</h2>
              <p className="text-muted-foreground mt-2 max-w-xs mx-auto">
                This email already has an account. Enter your password to add the <strong>{role}</strong> role to it.
              </p>
            </div>
            <form onSubmit={handleUpgradeRole} className="space-y-4">
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Your existing password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className="w-full bg-secondary rounded-2xl px-4 py-4 pr-12 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-base"
                  required
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {error && <p className="text-destructive text-sm font-medium">{error}</p>}
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-white py-4 rounded-2xl font-bold text-base flex items-center justify-center gap-2 shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-60"
              >
                {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Add {role} role <ChevronRight className="w-5 h-5" /></>}
              </button>
              <button type="button" onClick={() => { setStep("register"); setError(""); }} className="w-full text-muted-foreground py-2 text-sm">
                Back
              </button>
            </form>
          </motion.div>
        )}

        {step === "otp" && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">📧</span>
              </div>
              <h2 className="text-2xl font-bold">Verify Email</h2>
              <p className="text-muted-foreground mt-2">We sent a code to <span className="font-semibold text-foreground">{form.email}</span></p>
            </div>
            <form onSubmit={handleVerify} className="space-y-4">
              <input
                type="text"
                placeholder="Enter 6-digit code"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full bg-secondary rounded-2xl px-4 py-4 text-center text-foreground text-2xl font-bold tracking-widest focus:outline-none focus:ring-2 focus:ring-primary"
                maxLength={6}
                required
              />
              {error && <p className="text-destructive text-sm font-medium">{error}</p>}
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-white py-4 rounded-2xl font-bold text-base flex items-center justify-center gap-2 shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-60"
              >
                {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : "Verify & Continue"}
              </button>
              <button type="button" onClick={() => base44.auth.resendOtp(form.email)} className="w-full text-primary font-semibold py-2">
                Resend Code
              </button>
            </form>
          </motion.div>
        )}

        <p className="text-center text-muted-foreground mt-6 text-sm">
          Already have an account?{" "}
          <Link to="/login" className="text-primary font-semibold">Sign In</Link>
        </p>
      </div>
    </div>
  );
}