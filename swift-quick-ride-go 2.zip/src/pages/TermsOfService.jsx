import { Car, ArrowLeft } from "lucide-react";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background">
      <div className="bg-foreground pt-14 pb-6 px-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-primary/20 rounded-full -translate-y-10 translate-x-10" />
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
            <Car className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Terms of Service</h1>
            <p className="text-white/60 text-xs">Last updated: June 2025</p>
          </div>
        </div>
      </div>

      <div className="px-5 py-6 max-w-2xl mx-auto space-y-6 pb-16">
        <button onClick={() => window.history.back()} className="inline-flex items-center gap-2 text-muted-foreground text-sm hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        <Section title="1. Acceptance of Terms">
          By accessing or using EW Premier Rides ("the App"), you agree to be bound by these Terms of Service. If you do not agree, do not use the App.
        </Section>

        <Section title="2. Service Description">
          EW Premier Rides is a technology platform that connects passengers seeking transportation services with independent transportation network company (TNC) drivers in North Dakota. EW Premier Rides operates under applicable North Dakota TNC regulations.
        </Section>

        <Section title="3. Eligibility">
          You must be at least 18 years of age to use the App. By creating an account, you represent that you meet this requirement. Drivers must hold a valid driver's license, meet North Dakota TNC driver requirements, and pass all required background checks.
        </Section>

        <Section title="4. Driver Requirements (North Dakota TNC)">
          All drivers on the EW Premier Rides platform must:
          <ul className="list-disc pl-5 mt-2 space-y-1 text-sm text-muted-foreground">
            <li>Hold a valid North Dakota driver's license</li>
            <li>Pass a background check meeting ND TNC standards</li>
            <li>Maintain a valid vehicle registration and insurance</li>
            <li>Have a vehicle that passes the required safety inspection</li>
            <li>Display their photo and license plate to passengers before boarding</li>
            <li>Maintain zero tolerance for alcohol and controlled substances while driving</li>
          </ul>
        </Section>

        <Section title="5. Zero-Tolerance Alcohol & Drug Policy">
          <strong>EW Premier Rides has a strict zero-tolerance policy.</strong> Drivers may not operate a vehicle while under the influence of alcohol, marijuana, or any controlled substance. Any driver found to be in violation will be immediately and permanently removed from the platform and reported to relevant authorities. Passengers who suspect a driver is impaired should end the ride immediately and contact emergency services.
        </Section>

        <Section title="6. Fares & Payments">
          Fares are calculated based on base rate, time, and distance. Payments are processed securely through Stripe. All fares include applicable fees. Tips are optional and go directly to the driver. Receipts are provided via email after each completed ride.
        </Section>

        <Section title="7. Passenger Damage Policy">
          Passengers are fully responsible for any damage they cause to a driver's vehicle during a ride. A <strong>minimum damage fee of $300.00</strong> will be charged to the passenger's payment method on file for any damage caused to the driver's vehicle, including but not limited to: spills, stains, vandalism, or physical damage. Additional charges may apply if damages exceed $300.00. By using EW Premier Rides, passengers agree to this policy and authorize EW Premier Rides to charge their payment method accordingly.
        </Section>

        <Section title="8. Cancellations">
          Passengers may cancel a ride before the driver arrives. Repeated cancellations may result in account suspension. Drivers who cancel excessively may be removed from the platform.
        </Section>

        <Section title="9. Limitation of Liability">
          EW Premier Rides provides a technology platform only and is not responsible for the acts or omissions of drivers or passengers. To the fullest extent permitted by law, EW Premier Rides's liability is limited to the fare paid for the specific ride giving rise to any claim.
        </Section>

        <Section title="10. Governing Law">
          These Terms are governed by the laws of the State of North Dakota. Any disputes shall be resolved in the state or federal courts of North Dakota.
        </Section>

        <Section title="11. Contact">
          For questions about these Terms, contact us through the app's Help & Support section.
        </Section>

        <div className="pt-4 border-t border-border">
          <a href="/privacy" className="text-primary text-sm font-semibold">View Privacy Policy →</a>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div>
      <h2 className="font-bold text-base mb-2">{title}</h2>
      <p className="text-muted-foreground text-sm leading-relaxed">{children}</p>
    </div>
  );
}