import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Phone, MessageCircle, Star, X, Navigation, MapPin, Clock, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import LiveMap from "@/components/LiveMap";
import RideChat from "@/components/RideChat";
import NoDriverModal from "@/components/NoDriverModal";

const DEFAULT_PICKUP = null;
const DEFAULT_DROPOFF = null;
const DEFAULT_DRIVER = null;

const STATUS_STEPS = {
  requested: { label: "Finding your driver...", emoji: "🔍", color: "text-amber-500", progress: 20 },
  accepted: { label: "Driver is on the way", emoji: "🚗", color: "text-blue-500", progress: 45 },
  en_route: { label: "Driver is heading to you", emoji: "🚗", color: "text-blue-500", progress: 55 },
  arrived: { label: "Driver has arrived!", emoji: "📍", color: "text-primary", progress: 75 },
  in_progress: { label: "On your way!", emoji: "🎉", color: "text-primary", progress: 88 },
  completed: { label: "Ride Completed", emoji: "✅", color: "text-primary", progress: 100 },
};

function playStatusSound(status) {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const configs = {
    accepted: [{ freq: 520, t: 0 }, { freq: 660, t: 0.15 }],
    arrived:  [{ freq: 660, t: 0 }, { freq: 880, t: 0.15 }, { freq: 1040, t: 0.3 }],
    in_progress: [{ freq: 440, t: 0 }, { freq: 550, t: 0.12 }],
    completed: [{ freq: 880, t: 0 }, { freq: 1100, t: 0.15 }, { freq: 880, t: 0.3 }, { freq: 1100, t: 0.45 }],
  };
  (configs[status] || []).forEach(({ freq, t }) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = freq;
    osc.type = "sine";
    gain.gain.setValueAtTime(0.4, ctx.currentTime + t);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.12);
    osc.start(ctx.currentTime + t);
    osc.stop(ctx.currentTime + t + 0.15);
  });
}

const STATUS_NOTIFICATIONS = {
  accepted:    { title: "Driver is on the way! 🚗", body: "Your driver has accepted the ride." },
  arrived:     { title: "Your driver has arrived! 📍", body: "Your driver is waiting for you." },
  in_progress: { title: "Ride started! 🎉",          body: "You're on your way to the destination." },
  completed:   { title: "You've arrived! ✅",         body: "Thanks for riding with us." },
};

function showStatusNotification(status) {
  const n = STATUS_NOTIFICATIONS[status];
  if (!n) return;
  if ("Notification" in window && Notification.permission === "granted") {
    new Notification(n.title, { body: n.body, icon: "/favicon.ico", tag: "ride-status" });
  }
}

export default function CustomerRideTracking() {
  const [ride, setRide] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showRating, setShowRating] = useState(false);
  const [rating, setRating] = useState(0);
  const [selectedTip, setSelectedTip] = useState(null);
  const [sheetExpanded, setSheetExpanded] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [userCoords, setUserCoords] = useState(null);
  const [mapExpanded, setMapExpanded] = useState(false);
  const [showNoDriver, setShowNoDriver] = useState(false);
  const [waitExtension, setWaitExtension] = useState(0);
  const [liveEta, setLiveEta] = useState(null);
  const etaFetchRef = useRef(0);

  const rideId = new URLSearchParams(window.location.search).get("rideId");

  // Wake Lock — keep screen on during active ride
  useEffect(() => {
    let wakeLock = null;
    const requestWakeLock = async () => {
      if ("wakeLock" in navigator) {
        try {
          wakeLock = await navigator.wakeLock.request("screen");
        } catch (e) {
          console.warn("Wake lock failed:", e);
        }
      }
    };
    requestWakeLock();
    // Re-acquire wake lock when tab becomes visible again (e.g. after screen wake)
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") requestWakeLock();
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      if (wakeLock) wakeLock.release().catch(() => {});
    };
  }, []);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser);
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  // Auto-expand map when driver is en route
  useEffect(() => {
    if (ride?.status === "accepted" || ride?.status === "en_route" || ride?.status === "arrived") {
      setMapExpanded(true);
    } else {
      setMapExpanded(false);
    }
  }, [ride?.status]);

  // Re-fetch ride when app comes back to foreground (after screen sleep)
  useEffect(() => {
    if (!rideId) return;
    const handleVisibility = async () => {
      if (document.visibilityState === "visible") {
        const r = await base44.entities.Ride.filter({ id: rideId });
        if (r.length) setRide(r[0]);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);
    return () => document.removeEventListener("visibilitychange", handleVisibility);
  }, [rideId]);

  useEffect(() => {
    if (!rideId) return;
    const load = async () => {
      const r = await base44.entities.Ride.filter({ id: rideId });
      if (r.length) setRide(r[0]);
      setLoading(false);
    };
    load();
    const unsub = base44.entities.Ride.subscribe((event) => {
      if (event.id === rideId) {
        const prevStatus = ride?.status;
        const newStatus = event.data?.status;
        setRide(event.data);
        if (newStatus && newStatus !== prevStatus) {
          playStatusSound(newStatus);
          showStatusNotification(newStatus);
        }
        if (newStatus === "completed") {
          setShowRating(true);
          // Send ND-compliant email receipt automatically
          base44.functions.invoke("sendRideReceipt", { rideId });
        }
      }
    });
    return unsub;
  }, [rideId]);

  // No-driver timeout: if still "requested" 5 min after creation, notify the customer
  // Skipped when a driver has queued this ride for after their current trip
  useEffect(() => {
    if (!ride || ride.status !== "requested" || ride.queued_driver_id) {
      setShowNoDriver(false);
      return;
    }
    const deadline = new Date(ride.created_date).getTime() + (5 + waitExtension) * 60 * 1000;
    const remaining = deadline - Date.now();
    if (remaining <= 0) {
      setShowNoDriver(true);
      return;
    }
    const timer = setTimeout(() => setShowNoDriver(true), remaining);
    return () => clearTimeout(timer);
  }, [ride?.status, ride?.created_date, ride?.queued_driver_id, waitExtension]);

  // Live ETA — recompute from the driver's actual GPS position (every 15s max)
  useEffect(() => {
    const heading = ride?.status === "accepted" || ride?.status === "en_route";
    if (!heading || !ride?.driver_lat || !ride?.pickup_lat) {
      setLiveEta(null);
      return;
    }
    const now = Date.now();
    if (now - etaFetchRef.current < 15000) return;
    etaFetchRef.current = now;
    fetch(`https://router.project-osrm.org/route/v1/driving/${ride.driver_lng},${ride.driver_lat};${ride.pickup_lng},${ride.pickup_lat}?overview=false`)
      .then((r) => r.json())
      .then((d) => {
        const sec = d?.routes?.[0]?.duration;
        if (sec != null) setLiveEta(Math.max(1, Math.round(sec / 60)));
      })
      .catch(() => {});
  }, [ride?.driver_lat, ride?.driver_lng, ride?.status]);

  const handleCancel = async () => {
    await base44.entities.Ride.update(rideId, { status: "cancelled" });
    window.location.href = "/customer-home";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-border border-t-primary rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading ride details...</p>
        </div>
      </div>
    );
  }

  const status = STATUS_STEPS[ride?.status] || STATUS_STEPS.requested;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Live Map */}
      <div className="relative transition-all duration-500" style={{ height: mapExpanded ? "85vh" : "55vh" }}>
        <LiveMap
          pickupCoords={ride?.pickup_lat ? [ride.pickup_lat, ride.pickup_lng] : userCoords}
          dropoffCoords={ride?.dropoff_lat ? [ride.dropoff_lat, ride.dropoff_lng] : null}
          driverCoords={ride?.driver_lat ? [ride.driver_lat, ride.driver_lng] : null}
          showRoute={true}
          routeTo={ride?.status === "in_progress" ? "dropoff" : "pickup"}
          followDriver={true}
          height={mapExpanded ? "85vh" : "55vh"}
        />
        {/* Back button + ETA — safe area aware for all iOS devices */}
        <div className="absolute left-0 right-0 z-10 flex items-center justify-between px-4" style={{ top: 'max(48px, env(safe-area-inset-top, 48px))' }}>
          <button onClick={() => window.location.href = "/customer-home"} className="w-10 h-10 bg-black/40 backdrop-blur rounded-xl flex items-center justify-center">
            <X className="w-5 h-5 text-white" />
          </button>
          {(ride?.status === "accepted" || ride?.status === "en_route") && (liveEta || ride?.driver_eta_min) && (
            <div className="bg-black/40 backdrop-blur rounded-xl px-3 py-2 flex items-center gap-2">
              <Clock className="w-4 h-4 text-white" />
              <span className="text-white text-sm font-bold">{liveEta ?? ride.driver_eta_min} min</span>
            </div>
          )}
        </div>
        {/* Expand/Collapse toggle */}
        <button
          onClick={() => setMapExpanded(!mapExpanded)}
          className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/40 backdrop-blur rounded-full px-4 py-2 flex items-center gap-2"
        >
          <span className="text-white text-xs font-semibold">{mapExpanded ? "Show Details" : "Full Map"}</span>
          <ChevronDown className={`w-4 h-4 text-white transition-transform ${mapExpanded ? "" : "rotate-180"}`} />
        </button>
      </div>

      {/* Bottom Sheet */}
      <div className="bg-background rounded-t-3xl -mt-6 relative z-10 flex-1">
        <button onClick={() => setSheetExpanded(!sheetExpanded)} className="w-full flex flex-col items-center pt-4 pb-2">
          <div className="w-10 h-1 bg-border rounded-full mb-1" />
          <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${sheetExpanded ? "rotate-180" : ""}`} />
        </button>

        <div className="px-5 pb-8">
          {/* Status */}
          <div className="flex items-center gap-3 mb-4">
            <span className="text-3xl">{ride?.status === "requested" && ride?.queued_driver_id ? "🚗" : status.emoji}</span>
            <div>
              <p className={`font-bold text-lg ${status.color}`}>
                {ride?.status === "requested" && ride?.queued_driver_id
                  ? `${ride.queued_driver_name || "A driver"} will pick you up after their current trip`
                  : status.label}
              </p>
              {(ride?.status === "accepted" || ride?.status === "en_route") && (liveEta || ride?.driver_eta_min) && (
                <p className="text-muted-foreground text-sm">{liveEta ?? ride.driver_eta_min} min away</p>
              )}
            </div>
          </div>

          {/* Progress bar */}
          <div className="h-1.5 bg-secondary rounded-full mb-5 overflow-hidden">
            <motion.div
              className="h-full bg-primary rounded-full"
              initial={{ width: "0%" }}
              animate={{ width: `${status.progress}%` }}
              transition={{ duration: 0.8 }}
            />
          </div>

          {/* Payment badge / action */}
          {ride?.payment_status === "paid" && (
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold mb-3 bg-green-100 text-green-700">
              ✅ Payment confirmed
            </div>
          )}
          {ride?.payment_status === "pending" && (
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold mb-3 bg-amber-100 text-amber-700">
              ⏳ Payment processing
            </div>
          )}
          {ride?.payment_status === "unpaid" && (
            <div className="bg-red-50 border-2 border-red-300 rounded-2xl p-4 mb-4">
              <p className="font-bold text-red-700 mb-1">💳 Payment Required</p>
              <p className="text-sm text-red-600 mb-3">Your ride won't be accepted until payment is confirmed.</p>
              <button
                onClick={async () => {
                  if (window.self !== window.top) {
                    alert("Payment checkout only works from the published app.");
                    return;
                  }
                  const res = await base44.functions.invoke("createCheckoutSession", { rideId });
                  if (res.data?.url) window.location.href = res.data.url;
                }}
                className="w-full bg-red-600 text-white py-3 rounded-xl font-bold active:scale-95 transition-transform"
              >
                Complete Payment · ${ride?.estimated_fare?.toFixed(2)}
              </button>
            </div>
          )}

          {/* Driver Card */}
          {ride?.driver_name && (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-border rounded-2xl p-4 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {/* Driver Photo — ND compliance: must show before passenger enters vehicle */}
                  <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-primary/30 flex-shrink-0">
                    {ride.driver_photo_url ? (
                      <img src={ride.driver_photo_url} alt={ride.driver_name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-primary/10 flex items-center justify-center text-2xl">👨</div>
                    )}
                  </div>
                  <div>
                    <p className="font-bold">{ride.driver_name}</p>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                      <span className="text-sm text-muted-foreground">{ride.driver_rating || "4.9"}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center active:scale-90 transition-transform">
                    <Phone className="w-5 h-5 text-primary" />
                  </button>
                  <button onClick={() => setShowChat(true)} className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center active:scale-90 transition-transform">
                    <MessageCircle className="w-5 h-5 text-primary" />
                  </button>
                </div>
              </div>
              {/* Vehicle info — ND compliance: license plate must be shown */}
              {(ride.vehicle_info || ride.license_plate) && (
                <div className="mt-3 pt-3 border-t border-border flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{ride.vehicle_info || "Vehicle"}</span>
                  {ride.license_plate && (
                    <span className="font-bold bg-secondary px-3 py-1.5 rounded-lg tracking-widest text-foreground">{ride.license_plate}</span>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {/* Trip Info */}
          <div className="bg-secondary rounded-2xl p-4 mb-4">
            <div className="flex items-start gap-3">
              <div className="flex flex-col items-center gap-1 mt-1">
                <div className="w-2.5 h-2.5 bg-primary rounded-full" />
                <div className="w-0.5 h-8 bg-border" />
                <MapPin className="w-3 h-3 text-destructive" />
              </div>
              <div className="flex-1 space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">PICKUP</p>
                  <p className="font-semibold text-sm">{ride?.pickup_address}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">DROPOFF</p>
                  <p className="font-semibold text-sm">{ride?.dropoff_address}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-lg">${ride?.estimated_fare?.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground">Est. fare</p>
              </div>
            </div>
          </div>

          {/* Cancel Button - Show until driver arrives */}
          {(ride?.status === "requested" || ride?.status === "accepted" || ride?.status === "en_route") && (
            <button onClick={handleCancel} className="w-full bg-destructive/10 border-2 border-destructive text-destructive py-4 rounded-2xl font-bold active:scale-95 transition-transform mb-4">
              Cancel Ride
            </button>
          )}
        </div>
      </div>

      {/* No driver found */}
      <AnimatePresence>
        {showNoDriver && (
          <NoDriverModal
            onKeepWaiting={() => {
              setWaitExtension((w) => w + 5);
              setShowNoDriver(false);
            }}
            onCancel={handleCancel}
          />
        )}
      </AnimatePresence>

      {/* Chat */}
      <AnimatePresence>
        {showChat && currentUser && (
          <RideChat
            rideId={rideId}
            currentUser={currentUser}
            senderRole="customer"
            otherName={ride?.driver_name || "Driver"}
            onClose={() => setShowChat(false)}
          />
        )}
      </AnimatePresence>

      {/* Rating & Tip Modal */}
      <AnimatePresence>
        {showRating && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 bg-black/50 z-40" />
            <motion.div initial={{ opacity: 0, y: 100 }} animate={{ opacity: 1, y: 0 }} className="fixed bottom-0 left-0 right-0 bg-card rounded-t-3xl z-50 p-6 pb-10 max-h-[90vh] overflow-y-auto">
              <div className="text-center mb-6">
                <span className="text-5xl">🎉</span>
                <h2 className="text-2xl font-bold mt-3">Ride Complete!</h2>
                <p className="text-muted-foreground">How was your experience with {ride?.driver_name}?</p>
              </div>
              
              {/* Rating */}
              <div className="flex justify-center gap-3 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} onClick={() => setRating(star)} className="active:scale-110 transition-transform">
                    <Star className={`w-10 h-10 transition-colors ${star <= rating ? "text-amber-500 fill-amber-500" : "text-border"}`} />
                  </button>
                ))}
              </div>
              {rating === 0 && (
                <p className="text-center text-sm text-amber-600 font-medium mb-4">⭐ Tap a star to rate, then choose a tip</p>
              )}

              {/* Tip Section */}
              <div className="mb-6">
                <p className="text-center font-bold text-lg mb-3">Add a tip for your driver</p>
                <div className="grid grid-cols-4 gap-3 mb-4">
                  {[3, 5, 10].map((amount) => (
                    <button
                      key={amount}
                      onClick={() => setSelectedTip(amount)}
                      className={`py-3 rounded-xl font-bold transition-colors border-2 ${selectedTip === amount ? "bg-primary text-white border-primary" : "bg-secondary border-border hover:border-primary hover:bg-primary/10"}`}
                    >
                      ${amount}
                    </button>
                  ))}
                  <button
                    onClick={() => {
                      const custom = prompt("Enter custom tip amount:");
                      if (custom && !isNaN(parseFloat(custom)) && parseFloat(custom) > 0) {
                        setSelectedTip(parseFloat(custom));
                      }
                    }}
                    className={`py-3 rounded-xl font-bold transition-colors border-2 ${selectedTip && ![3,5,10].includes(selectedTip) ? "bg-primary text-white border-primary" : "bg-secondary border-border hover:border-primary hover:bg-primary/10"}`}
                  >
                    {selectedTip && ![3,5,10].includes(selectedTip) ? `$${selectedTip}` : "Custom"}
                  </button>
                </div>

                {/* Confirm Tip Button */}
                {selectedTip && (
                  <button
                    onClick={async () => {
                      if (!rideId) return;
                      if (rating > 0) {
                        await base44.entities.Ride.update(rideId, { customer_rating: rating });
                        const driverRides = await base44.entities.Ride.filter({ driver_id: ride.driver_id, status: "completed" });
                        const rated = driverRides.filter((r) => r.customer_rating);
                        const allRatings = rated.map((r) => r.id === rideId ? rating : r.customer_rating);
                        if (!rated.find((r) => r.id === rideId)) allRatings.push(rating);
                        const avg = allRatings.reduce((s, v) => s + v, 0) / allRatings.length;
                        const users = await base44.entities.User.filter({ id: ride.driver_id });
                        if (users.length) await base44.entities.User.update(users[0].id, { rating: parseFloat(avg.toFixed(2)) });
                      }
                      const res = await base44.functions.invoke("createTipSession", { rideId, tipAmount: selectedTip });
                      const url = res?.data?.url;
                      if (!url) { alert("Could not start tip payment. Please try again."); return; }
                      if (window.location !== window.parent.location) {
                        alert("Please open the app in a browser to complete payment");
                      } else {
                        window.location.href = url;
                      }
                    }}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform mb-3"
                  >
                    Pay ${selectedTip} Tip
                  </button>
                )}
              </div>

              {/* Skip Tip Button */}
              <button
                onClick={async () => {
                  if (rating > 0 && rideId && ride?.driver_id) {
                    await base44.entities.Ride.update(rideId, { customer_rating: rating });
                    const driverRides = await base44.entities.Ride.filter({ driver_id: ride.driver_id, status: "completed" });
                    const rated = driverRides.filter((r) => r.customer_rating);
                    const allRatings = rated.map((r) => r.id === rideId ? rating : r.customer_rating);
                    if (!rated.find((r) => r.id === rideId)) allRatings.push(rating);
                    const avg = allRatings.reduce((s, v) => s + v, 0) / allRatings.length;
                    const users = await base44.entities.User.filter({ id: ride.driver_id });
                    if (users.length) await base44.entities.User.update(users[0].id, { rating: parseFloat(avg.toFixed(2)) });
                  }
                  window.location.href = "/customer-home";
                }}
                className="w-full border-2 border-border text-muted-foreground py-4 rounded-2xl font-bold mb-3"
              >
                Skip Tip
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}