import { useState, useRef, useCallback } from "react";

const THRESHOLD = 70;

export default function PullToRefresh({ onRefresh, children, className = "" }) {
  const [pulling, setPulling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [pullY, setPullY] = useState(0);
  const startY = useRef(null);

  const handleTouchStart = useCallback((e) => {
    const scrollEl = e.currentTarget;
    if (scrollEl.scrollTop === 0) {
      startY.current = e.touches[0].clientY;
    }
  }, []);

  const handleTouchMove = useCallback((e) => {
    if (startY.current === null) return;
    const delta = e.touches[0].clientY - startY.current;
    if (delta > 0) {
      setPullY(Math.min(delta, THRESHOLD * 1.5));
      setPulling(delta > THRESHOLD);
    }
  }, []);

  const handleTouchEnd = useCallback(async () => {
    if (pulling) {
      setRefreshing(true);
      setPullY(40);
      await onRefresh();
      setRefreshing(false);
    }
    startY.current = null;
    setPulling(false);
    setPullY(0);
  }, [pulling, onRefresh]);

  return (
    <div
      className={`overflow-y-auto ${className}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull indicator */}
      <div
        className="flex items-center justify-center overflow-hidden transition-all duration-200"
        style={{ height: refreshing ? 40 : pullY > 0 ? pullY : 0 }}
      >
        <div className={`w-6 h-6 border-2 border-primary rounded-full transition-all ${refreshing || pulling ? "border-t-transparent animate-spin" : "opacity-40"}`} />
      </div>
      {children}
    </div>
  );
}