import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const CHECKR_API_KEY = Deno.env.get("CHECKR_API_KEY");
    if (!CHECKR_API_KEY) {
      console.error('Checkr API key not configured');
      return Response.json({ error: 'Checkr not configured' }, { status: 500 });
    }

    // Parse webhook payload
    const body = await req.json();
    console.log('Checkr webhook received:', body);

    // Handle report completion
    if (body.event === 'report.completed') {
      const report = body.data;
      const collaborationId = report.collaboration_id; // This is the user ID we set

      if (!collaborationId) {
        console.error('No collaboration_id in webhook payload');
        return Response.json({ error: 'Invalid webhook payload' }, { status: 400 });
      }

      // Determine verification status based on Checkr report
      let newVerificationStatus = 'submitted';
      const checkrStatus = report.status;

      if (report.status === 'clear') {
        newVerificationStatus = 'approved';
      } else if (report.status === 'consider' || report.status === 'suspend') {
        newVerificationStatus = 'rejected';
      }

      // Update user record
      const user = await base44.asServiceRole.entities.User.get(collaborationId);
      if (user) {
        await base44.asServiceRole.entities.User.update(collaborationId, {
          checkr_report_status: checkrStatus,
          checkr_report_completed_at: new Date().toISOString(),
          verification_status: newVerificationStatus,
        });

        console.log(`Updated user ${collaborationId} verification status to ${newVerificationStatus}`);

        // If approved, send notification email
        if (checkrStatus === 'clear') {
          try {
            await base44.integrations.Core.SendEmail({
              to: user.email,
              subject: '🎉 You\'re Approved to Drive!',
              body: `Hi ${user.full_name},\n\nGreat news! Your background check has been completed and you're now approved to drive with EW Premier Rides.\n\nYou can start accepting rides immediately by going to your Driver Home.\n\nSafe driving!\nThe EW Premier Rides Team`,
            });
          } catch (emailError) {
            console.error('Failed to send approval email:', emailError);
          }
        }
      } else {
        console.error(`User ${collaborationId} not found`);
        return Response.json({ error: 'User not found' }, { status: 404 });
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Checkr webhook error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});