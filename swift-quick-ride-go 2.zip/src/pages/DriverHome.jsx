import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Star, DollarSign, Navigation, Bell, User, ChevronRight, Clock, MapPin, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { driverEarnings } from "@/utils/fareCalculator";
import BottomNav from "@/components/BottomNav";
import PullToRefresh from "@/components/PullToRefresh";

function playAlertSound() {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const times = [0, 0.15, 0.3];
  times.forEach((t) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    osc.type = "sine";
    gain.gain.setValueAtTime(0.4, ctx.currentTime + t);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.12);
    osc.start(ctx.currentTime + t);
    osc.stop(ctx.currentTime + t + 0.15);
  });
}

function vibrateDevice() {
  if (navigator.vibrate) {
    navigator.vibrate([200, 100, 200, 100, 200]);
  }
}

function requestNotificationPermission() {
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
  }
}

function showPushNotification(ride) {
  if ("Notification" in window && Notification.permission === "granted") {
    new Notification("New Ride Request 🔔", {
      body: `${ride.pickup_address} → ${ride.dropoff_address}\n$${ride.estimated_fare?.toFixed(2)}`,
      icon: "/favicon.ico",
      tag: "ride-request",
      requireInteraction: true,
      silent: false,
    });
  }
}

export default function DriverHome() {
  const { user: authUser } = useAuth();
  const [user, setUser] = useState(null);
  const [isOnline, setIsOnline] = useState(false);
  const [onBreak, setOnBreak] = useState(false);
  const [pendingRides, setPendingRides] = useState([]);
  const [activeRequest, setActiveRequest] = useState(null);
  const [loading, setLoading] = useState(false);
  const [earnings, setEarnings] = useState({ today: 0, rides: 0 });
  const [menuOpen, setMenuOpen] = useState(false);
  const [todayDriveMin, setTodayDriveMin] = useState(0);
  const [upcomingReservation, setUpcomingReservation] = useState(null);

  // Keep screen awake while online waiting for ride requests
  useEffect(() => {
    if (!isOnline) return;
    let wakeLock = null;
    const requestWakeLock = async () => {
      if ("wakeLock" in navigator) {
        try {
          wakeLock = await navigator.wakeLock.request("screen");
        } catch (e) {
          console.warn("Wake lock failed:", e);
        }
      }
    };
    requestWakeLock();
    const handleVisibility = () => {
      if (document.visibilityState === "visible") requestWakeLock();
    };
    document.addEventListener("visibilitychange", handleVisibility);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
      if (wakeLock) wakeLock.release().catch(() => {});
    };
  }, [isOnline]);

  // Use user from AuthContext immediately — no extra auth.me() call needed
  useEffect(() => {
    if (!authUser) return;
    setUser(authUser);
    if ((authUser.user_type === "driver" || authUser.user_type === "both") && authUser.verification_status !== "approved") {
      window.location.replace("/welcome");
      return;
    }
    setIsOnline(authUser.is_online || false);
    setOnBreak(authUser.on_break || false);
    loadEarnings(authUser.id);
    loadUpcomingReservation(authUser.id);
    // Non-blocking active ride check
    base44.entities.Ride.filter({ driver_id: authUser.id }).then((allRides) => {
      const activeRide = allRides.find((r) =>
        ["accepted", "en_route", "arrived", "in_progress"].includes(r.status)
      );
      if (activeRide) window.location.href = `/driver-active-ride?rideId=${activeRide.id}`;
    }).catch(() => {});
  }, [authUser]);

  useEffect(() => {
    requestNotificationPermission();
    loadPendingRides();
    const unsub = base44.entities.Ride.subscribe((event) => {
      // New ride request
      if (event.type === "create" && event.data?.status === "requested") {
        if (!onBreak) {
          setPendingRides((prev) => [event.data, ...prev]);
          setActiveRequest(event.data);
          playAlertSound();
          vibrateDevice();
          showPushNotification(event.data);
        }
      }
      // Ride accepted by another driver - remove from pending
      if (event.type === "update" && event.data?.id === activeRequest?.id && event.data?.status !== "requested") {
        setPendingRides((prev) => prev.filter((r) => r.id !== event.data.id));
        setActiveRequest(null);
      }
      // Ride status changed - refresh pending rides list
      if (event.type === "update" && event.data?.status !== "requested") {
        setPendingRides((prev) => prev.filter((r) => r.id !== event.data.id));
        if (activeRequest?.id === event.data.id) {
          setActiveRequest(null);
        }
      }
    });
    return unsub;
  }, []);

  const loadEarnings = async (driverId) => {
    if (!driverId) return;
    try {
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const allRides = await base44.entities.Ride.filter({ driver_id: driverId, status: "completed" });
      const todayRides = allRides.filter((r) => new Date(r.created_date) >= todayStart);
      // Driver keeps 70% of fare + 100% of tips
      const todayEarnings = todayRides.reduce((sum, r) => sum + driverEarnings(r.final_fare || r.estimated_fare || 0) + (r.tip_amount || 0), 0);
      setEarnings({ today: todayEarnings, rides: todayRides.length });

      // Calculate total drive time today (from ride_start_time to ride_end_time)
      const driveMin = todayRides.reduce((sum, r) => {
        if (r.ride_start_time && r.ride_end_time) {
          const mins = (new Date(r.ride_end_time) - new Date(r.ride_start_time)) / 60000;
          return sum + (mins > 0 ? mins : 0);
        }
        return sum + (r.estimated_duration_min || 0);
      }, 0);
      setTodayDriveMin(driveMin);
    } catch (error) {
      console.error('Failed to load earnings:', error);
      setEarnings({ today: 0, rides: 0 });
    }
  };

  const loadUpcomingReservation = async (driverId) => {
    if (!driverId) return;
    const all = await base44.entities.Reservation.filter({ driver_id: driverId, status: "accepted" });
    const upcoming = all
      .filter((r) => new Date(r.scheduled_time) > Date.now())
      .sort((a, b) => new Date(a.scheduled_time) - new Date(b.scheduled_time));
    setUpcomingReservation(upcoming[0] || null);
  };

  const refreshAll = useCallback(async () => {
    await loadPendingRides();
    if (user?.id) {
      await loadEarnings(user.id);
      await loadUpcomingReservation(user.id);
    }
  }, [user]);

  const loadPendingRides = async () => {
    try {
      const rides = await base44.entities.Ride.filter({ status: "requested" });
      setPendingRides(rides);
      if (rides.length > 0) setActiveRequest(rides[0]);
    } catch (error) {
      console.error('Failed to load pending rides:', error);
      setPendingRides([]);
      setActiveRequest(null);
    }
  };

  const docsBlocked = user?.documents_valid === false;
  const TWELVE_HOURS_MIN = 720;
  const hoursBlocked = todayDriveMin >= TWELVE_HOURS_MIN;

  // Block accepting new rides 30 min before a reservation
  const reservationBlockedMin = upcomingReservation
    ? Math.floor((new Date(upcomingReservation.scheduled_time) - Date.now()) / 60000)
    : null;
  const reservationBlocked = reservationBlockedMin !== null && reservationBlockedMin <= 30 && reservationBlockedMin >= 0;

  const toggleOnline = async () => {
    if (docsBlocked || hoursBlocked || reservationBlocked) return;
    const newStatus = !isOnline;
    setIsOnline(newStatus);
    // Going offline clears break status too
    const updates = { is_online: newStatus };
    if (!newStatus) { setOnBreak(false); updates.on_break = false; }
    await base44.auth.updateMe(updates);
    if (newStatus) loadPendingRides();
  };

  const toggleBreak = async () => {
    const newBreak = !onBreak;
    setOnBreak(newBreak);
    await base44.auth.updateMe({ on_break: newBreak });
    // Don't clear pending rides when going on break - just hide the alert
    // Driver can still accept the current request if they want
  };

  const acceptRide = async (ride) => {
    // Optimistic: block the button and remove the card immediately
    setLoading(true);
    setActiveRequest(null);
    setPendingRides((prev) => prev.filter((r) => r.id !== ride.id));

    // Block acceptance if reservation is within 30 min
    if (reservationBlocked) {
      alert("You have a reservation starting within 30 minutes. You cannot accept new rides until after your reservation.");
      setLoading(false);
      return;
    }

    // Validate payment status from local data first (fastest check)
    if (ride.payment_status !== "paid") {
      alert("This ride has not been paid yet. The customer must complete payment before you can accept.");
      setLoading(false);
      return;
    }

    // Optimistic navigate immediately — server update runs in background
    window.location.href = `/driver-active-ride?rideId=${ride.id}`;

    // Fire-and-forget server update (page is already navigating)
    base44.entities.Ride.update(ride.id, {
      status: "accepted",
      driver_id: user?.id,
      driver_name: user?.full_name,
      driver_rating: user?.rating || 4.9,
      vehicle_info: `${user?.vehicle_color || ""} ${user?.vehicle_make || ""} ${user?.vehicle_model || ""}`.trim() || "Toyota Camry",
      license_plate: user?.license_plate || "ABC-1234",
      driver_eta_min: Math.floor(3 + Math.random() * 7),
      driver_photo_url: user?.profile_photo_url || null,
    }).catch((err) => console.error('[DriverHome] Background ride update failed:', err));
  };

  const declineRide = async (rideId) => {
    setPendingRides((prev) => prev.filter((r) => r.id !== rideId));
    setActiveRequest(null);
    // Notify the customer that this driver was unavailable and we're still searching
    base44.functions.invoke('notifyRideDeclined', { rideId }).catch(() => {});
  };

  const stats = [
    { label: "Today's Earnings", value: `$${earnings.today.toFixed(2)}`, icon: DollarSign, color: "text-primary bg-primary/10" },
    { label: "Rides Today", value: earnings.rides.toString(), icon: Navigation, color: "text-blue-500 bg-blue-500/10" },
    { label: "Your Rating", value: user?.rating?.toFixed(1) || "5.0", icon: Star, color: "text-amber-500 bg-amber-500/10" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="pb-4 px-5 bg-card border-b border-border" style={{ paddingTop: 'max(3rem, env(safe-area-inset-top, 3rem))' }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center overflow-hidden border-2 border-primary/30">
              {user?.profile_photo_url ? (
                <img src={user.profile_photo_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <User className="w-6 h-6 text-primary" />
              )}
            </div>
            <div>
              <p className="text-muted-foreground text-xs">Driver</p>
              <p className="text-foreground font-bold text-lg">{user?.full_name || "Driver"}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {user?.role === "admin" && (
              <a href="/admin" className="px-3 h-10 bg-primary rounded-xl flex items-center justify-center text-white text-xs font-bold">
                Admin
              </a>
            )}
            <button className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center relative">
              <Bell className="w-5 h-5 text-foreground" />
              {pendingRides.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary rounded-full text-xs text-white font-bold flex items-center justify-center">{pendingRides.length}</span>
              )}
            </button>
            <button onClick={() => setMenuOpen(true)} className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
              <Menu className="w-5 h-5 text-foreground" />
            </button>
          </div>
        </div>
      </div>

      <PullToRefresh onRefresh={refreshAll} className="flex-1 overflow-y-auto">
      <div className="px-5 py-5 space-y-5 pb-nav">

        {/* Upcoming Reservation Banner */}
        {upcomingReservation && (
          <div className={`border-2 rounded-3xl p-4 ${reservationBlocked ? "bg-red-50 border-red-400" : "bg-primary/5 border-primary/40"}`}>
            <div className="flex items-start justify-between mb-2">
              <p className={`font-bold ${reservationBlocked ? "text-red-700" : "text-primary"}`}>
                {reservationBlocked ? "🚨 Reservation Starting Soon!" : "📅 Upcoming Reservation"}
              </p>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${reservationBlocked ? "bg-red-100 text-red-700" : "bg-primary/10 text-primary"}`}>
                {reservationBlockedMin !== null ? (reservationBlockedMin <= 0 ? "Now" : `${reservationBlockedMin}m`) : ""}
              </span>
            </div>
            <p className="text-sm text-muted-foreground truncate">{upcomingReservation.pickup_address}</p>
            <p className="text-xs text-muted-foreground mt-0.5">→ {upcomingReservation.dropoff_address}</p>
            {reservationBlocked && (
              <p className="text-xs text-red-600 font-semibold mt-2">New ride requests are blocked to ensure you're available for this reservation.</p>
            )}
            <button onClick={() => window.location.href = "/driver-reservations"} className="mt-3 text-xs font-bold text-primary underline">
              View all reservations →
            </button>
          </div>
        )}

        {/* 12-Hour Driving Limit Block */}
        {hoursBlocked && (
          <div className="bg-amber-500/10 border-2 border-amber-500 rounded-3xl p-5">
            <p className="font-bold text-amber-700 text-lg">⏱️ Daily Limit Reached</p>
            <p className="text-sm text-muted-foreground mt-1">
              You've driven <strong>{Math.floor(todayDriveMin / 60)}h {Math.round(todayDriveMin % 60)}m</strong> today. For safety, drivers cannot exceed 12 hours per day. Your limit resets at midnight.
            </p>
          </div>
        )}

        {/* Expired Documents Block */}
        {docsBlocked && (
          <div className="bg-destructive/10 border-2 border-destructive rounded-3xl p-5">
            <p className="font-bold text-destructive text-lg">🚫 Driving Suspended</p>
            <p className="text-sm text-muted-foreground mt-1">
              Your driver's license or insurance on file has expired. Upload a current document to get back on the road.
            </p>
            <button
              onClick={() => window.location.href = "/driver-verification"}
              className="mt-4 w-full bg-destructive text-white py-3 rounded-2xl font-bold active:scale-95 transition-transform"
            >
              Update My Documents
            </button>
          </div>
        )}

        {/* Online Toggle */}
        <motion.div
          className={`rounded-3xl p-5 transition-all ${(docsBlocked || hoursBlocked || reservationBlocked) ? "bg-secondary opacity-50" : isOnline ? "bg-primary" : "bg-secondary"}`}
          layout
        >
          <div className="flex items-center justify-between">
            <div>
              <p className={`font-bold text-xl ${isOnline ? "text-white" : "text-foreground"}`}>
                {isOnline ? "You're Online 🟢" : "You're Offline"}
              </p>
              <p className={`text-sm mt-0.5 ${isOnline ? "text-white/70" : "text-muted-foreground"}`}>
                {isOnline ? "Accepting ride requests" : "Go online to start earning"}
              </p>
            </div>
            <button
              onClick={toggleOnline}
              className={`w-16 h-8 rounded-full transition-all relative ${isOnline ? "bg-white/30" : "bg-border"}`}
            >
              <motion.div
                className={`absolute top-1 w-6 h-6 rounded-full shadow-sm ${isOnline ? "bg-white" : "bg-muted-foreground"}`}
                animate={{ left: isOnline ? "calc(100% - 28px)" : "4px" }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
              />
            </button>
          </div>
        </motion.div>

        {/* Break Toggle */}
        {isOnline && (
          <button
            onClick={toggleBreak}
            className={`w-full rounded-2xl p-4 flex items-center justify-between transition-all ${onBreak ? "bg-amber-500/20 border-2 border-amber-500" : "bg-card border border-border"}`}
          >
            <div>
              <p className={`font-bold ${onBreak ? "text-amber-600" : "text-foreground"}`}>
                {onBreak ? "☕ On Break" : "Take a Break"}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {onBreak ? "You won't receive ride requests" : "Pause requests temporarily"}
              </p>
            </div>
            <div className={`w-12 h-6 rounded-full relative transition-all ${onBreak ? "bg-amber-500" : "bg-border"}`}>
              <motion.div
                className="absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm"
                animate={{ left: onBreak ? "calc(100% - 20px)" : "4px" }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
              />
            </div>
          </button>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-card border border-border rounded-2xl p-3 text-center">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center mx-auto mb-2 ${stat.color}`}>
                <stat.icon className="w-4 h-4" />
              </div>
              <p className="font-bold text-lg">{stat.value}</p>
              <p className="text-muted-foreground text-xs leading-tight">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Incoming Request */}
        <AnimatePresence>
          {isOnline && activeRequest && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              className="bg-card border-2 border-primary rounded-3xl overflow-hidden shadow-xl shadow-primary/20"
            >
              <div className="bg-primary px-5 py-3">
                <div className="flex items-center justify-between">
                  <p className="text-white font-bold">New Ride Request 🔔</p>
                  <span className="text-white/80 text-sm font-semibold">You earn ${driverEarnings(activeRequest.estimated_fare).toFixed(2)}</span>
                </div>
              </div>
              <div className="p-5">
                <div className="flex items-start gap-3 mb-4">
                  <div className="flex flex-col items-center gap-1 mt-1">
                    <div className="w-2.5 h-2.5 bg-primary rounded-full" />
                    <div className="w-0.5 h-8 bg-border" />
                    <MapPin className="w-3 h-3 text-destructive" />
                  </div>
                  <div className="flex-1 space-y-3">
                    <div>
                      <p className="text-xs text-muted-foreground">PICKUP</p>
                      <p className="font-semibold text-sm">{activeRequest.pickup_address}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">DROPOFF</p>
                      <p className="font-semibold text-sm">{activeRequest.dropoff_address}</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mb-4 text-sm">
                  <div className="flex items-center gap-1.5 bg-secondary rounded-xl px-3 py-1.5">
                    <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                    <span>{activeRequest.estimated_duration_min || 20} min</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-secondary rounded-xl px-3 py-1.5">
                    <Navigation className="w-3.5 h-3.5 text-muted-foreground" />
                    <span>{activeRequest.estimated_distance_miles || "5.2"} mi</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-secondary rounded-xl px-3 py-1.5 capitalize">
                    <span>{activeRequest.ride_type || "Economy"}</span>
                  </div>
                  <div className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm font-semibold ${activeRequest.payment_status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                    <span>{activeRequest.payment_status === 'paid' ? '💳 Paid' : '⏳ Unpaid'}</span>
                  </div>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => declineRide(activeRequest.id)}
                    className="flex-1 border-2 border-border py-3 rounded-2xl font-bold text-muted-foreground active:scale-95 transition-transform"
                  >
                    Decline
                  </button>
                  <button
                    onClick={() => acceptRide(activeRequest)}
                    disabled={loading}
                    className="flex-[2] bg-primary text-white py-3 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform"
                  >
                    {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" /> : "Accept Ride"}
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {isOnline && !activeRequest && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Navigation className="w-10 h-10 text-primary" />
            </div>
            <p className="font-bold text-lg">Looking for rides...</p>
            <p className="text-muted-foreground text-sm mt-1">Stay online to receive requests</p>
          </motion.div>
        )}

        {/* Quick Actions */}
        <div className="space-y-2">
          {user?.role === "admin" && (
            <a href="/admin" className="flex items-center gap-4 bg-primary/10 border-2 border-primary/30 rounded-2xl p-4 active:bg-primary/20 transition-colors">
              <span className="text-2xl">👨‍💼</span>
              <span className="font-semibold flex-1 text-primary">Admin Dashboard</span>
              <ChevronRight className="w-5 h-5 text-primary" />
            </a>
          )}
          {[["My Reservations", "📅", "/driver-reservations"], ["My Profile & Ratings", "⭐", "/driver-profile"], ["Earnings Summary", "💰", "/driver-earnings"], ["Driver Verification", "🛡️", "/driver-verification"], ["Help & Support", "💬", "/help"]].map(([label, emoji, href]) => (
            <a key={label} href={href} className="flex items-center gap-4 bg-card border border-border rounded-2xl p-4 active:bg-secondary transition-colors">
              <span className="text-2xl">{emoji}</span>
              <span className="font-semibold flex-1">{label}</span>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </a>
          ))}


        </div>

        <button onClick={() => base44.auth.logout("/login")} className="w-full text-destructive font-semibold py-3 text-center">Sign Out</button>
      </div>
      </PullToRefresh>
      {/* Side Menu */}
      <AnimatePresence>
        {menuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-[9998]"
              style={{ WebkitTapHighlightColor: 'transparent' }}
              onClick={() => setMenuOpen(false)}
            />
            {/* Drawer — full width on phones, 300px on tablets+ */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed right-0 top-0 bottom-0 bg-card z-[9999] overflow-y-auto"
              style={{
                width: 'min(300px, 100vw)',
                paddingTop: 'max(56px, env(safe-area-inset-top, 56px))',
                paddingBottom: 'max(120px, calc(env(safe-area-inset-bottom, 0px) + 120px))',
                paddingLeft: '24px',
                paddingRight: '24px',
                boxShadow: '-4px 0 24px rgba(0,0,0,0.2)',
              }}
            >
              {/* Close button */}
              <button
                onClick={() => setMenuOpen(false)}
                className="absolute top-4 right-4 w-10 h-10 bg-secondary rounded-xl flex items-center justify-center active:scale-90 transition-transform"
                style={{ marginTop: 'env(safe-area-inset-top, 0px)' }}
              >
                <X className="w-5 h-5" />
              </button>

              {/* Profile */}
              <div className="flex items-center gap-3 mb-8 mt-4">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden border-2 border-primary/20">
                  {user?.profile_photo_url ? (
                    <img src={user.profile_photo_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-7 h-7 text-primary" />
                  )}
                </div>
                <div>
                  <p className="font-bold text-base">{user?.full_name || "Driver"}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span className="text-sm text-muted-foreground">{user?.rating?.toFixed(1) || "5.0"}</span>
                  </div>
                </div>
              </div>

              {/* Menu Items */}
              {(user?.role === "admin") && (
                <button
                  onClick={() => window.location.href = "/admin"}
                  className="flex items-center gap-3 py-4 border-b border-border w-full text-left active:bg-secondary rounded-lg px-1 transition-colors"
                  style={{ WebkitTapHighlightColor: 'transparent', minHeight: '56px' }}
                >
                  <span className="text-2xl w-8 text-center">👨‍💼</span>
                  <span className="font-medium flex-1 text-base">Admin Dashboard</span>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                </button>
              )}
              {[
                ["My Reservations", "📅", "/driver-reservations"],
                ["My Profile & Ratings", "⭐", "/driver-profile"],
                ["Earnings Summary", "💰", "/driver-earnings"],
                ["Driver Verification", "🛡️", "/driver-verification"],
                ["Help & Support", "💬", "/help"],
                ["Terms of Service", "📄", "/terms"],
                ["Privacy Policy", "🔒", "/privacy"],
              ].map(([label, emoji, href]) => (
                <a
                  key={label}
                  href={href}
                  className="flex items-center gap-3 py-4 border-b border-border active:bg-secondary rounded-lg px-1 transition-colors"
                  style={{ WebkitTapHighlightColor: 'transparent', minHeight: '56px' }}
                >
                  <span className="text-2xl w-8 text-center">{emoji}</span>
                  <span className="font-medium flex-1 text-base">{label}</span>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                </a>
              ))}

              <button
                onClick={() => window.location.href = "/customer-home"}
                className="flex items-center gap-3 py-4 border-b border-border w-full text-left active:bg-secondary rounded-lg px-1 transition-colors"
                style={{ WebkitTapHighlightColor: 'transparent', minHeight: '56px' }}
              >
                <span className="text-2xl w-8 text-center">👤</span>
                <span className="font-medium flex-1 text-base">Switch to Customer</span>
                <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
              </button>

              <button
                onClick={() => base44.auth.logout("/login")}
                className="w-full mt-8 py-4 text-destructive font-semibold text-center text-base rounded-2xl bg-destructive/10 active:bg-destructive/20 transition-colors"
                style={{ WebkitTapHighlightColor: 'transparent' }}
              >
                Sign Out
              </button>
              <a
                href="/driver-profile#delete"
                className="w-full mt-3 py-3 text-muted-foreground font-medium text-center text-sm block"
                style={{ WebkitTapHighlightColor: 'transparent' }}
              >
                Delete Account
              </a>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <BottomNav variant="driver" />
    </div>
  );
}