import { NavLink } from "react-router-dom";
import { Home, Clock, Calendar, User } from "lucide-react";

const CUSTOMER_TABS = [
  { label: "Home", icon: Home, to: "/customer-home" },
  { label: "Reservations", icon: Calendar, to: "/customer-reservations" },
  { label: "History", icon: Clock, to: "/customer-ride-history" },
  { label: "Profile", icon: User, to: "/driver-profile" },
];

const DRIVER_TABS = [
  { label: "Home", icon: Home, to: "/driver-home" },
  { label: "Reservations", icon: Calendar, to: "/driver-reservations" },
  { label: "Earnings", icon: Clock, to: "/driver-earnings" },
  { label: "Profile", icon: User, to: "/driver-profile" },
];

export default function BottomNav({ variant = "customer" }) {
  const tabs = variant === "driver" ? DRIVER_TABS : CUSTOMER_TABS;

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border flex"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      {tabs.map((tab) => (
        <NavLink
          key={tab.label}
          to={tab.to}
          className={({ isActive }) =>
            `flex-1 flex flex-col items-center justify-center py-2 gap-0.5 transition-colors ${
              isActive ? "text-primary" : "text-muted-foreground"
            }`
          }
        >
          {({ isActive }) => (
            <>
              <tab.icon className={`w-5 h-5 ${isActive ? "text-primary" : "text-muted-foreground"}`} strokeWidth={isActive ? 2.5 : 1.8} />
              <span className={`text-[10px] font-medium ${isActive ? "text-primary" : "text-muted-foreground"}`}>{tab.label}</span>
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
}