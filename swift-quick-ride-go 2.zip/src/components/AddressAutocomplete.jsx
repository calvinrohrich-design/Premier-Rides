import { useState, useEffect, useRef } from "react";
import { MapPin, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function AddressAutocomplete({ placeholder, value, onChange, onSelect, icon = "pin", userCoords = null }) {
  const [query, setQuery] = useState(value || "");
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const debounceRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    setQuery(value || "");
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    onChange(val);
    clearTimeout(debounceRef.current);
    if (val.length < 2) { setSuggestions([]); setOpen(false); return; }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await base44.functions.invoke("placesAutocomplete", {
          input: val,
          ...(userCoords ? { lat: userCoords[0], lng: userCoords[1] } : {}),
        });
        const results = res.data?.predictions || [];
        setSuggestions(results);
        setOpen(results.length > 0);
      } catch {
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    }, 350);
  };

  const handleSelect = async (item) => {
    const label = item.description;
    setQuery(label);
    onChange(label);
    setSuggestions([]);
    setOpen(false);
    // Fetch coordinates via placeDetails
    try {
      const res = await base44.functions.invoke("placeDetails", { place_id: item.place_id });
      const loc = res.data?.result?.geometry?.location;
      if (loc) {
        onSelect({ label, lat: loc.lat, lng: loc.lng });
      } else {
        onSelect({ label, lat: null, lng: null });
      }
    } catch {
      onSelect({ label, lat: null, lng: null });
    }
  };

  return (
    <div ref={containerRef} className="relative flex items-center gap-3 bg-secondary rounded-2xl px-4 py-3.5">
      {icon === "pin" ? (
        <MapPin className="w-4 h-4 text-destructive flex-shrink-0" />
      ) : icon === "loader" ? (
        <Loader2 className="w-4 h-4 text-primary flex-shrink-0 animate-spin" />
      ) : icon === "destination" ? (
        <div className="w-3 h-3 bg-primary rounded-full flex-shrink-0" />
      ) : loading ? (
        <Loader2 className="w-4 h-4 text-primary flex-shrink-0 animate-spin" />
      ) : (
        <div className="w-3 h-3 bg-primary rounded-full flex-shrink-0" />
      )}
      <input
        placeholder={placeholder}
        value={query}
        onChange={handleChange}
        onFocus={() => suggestions.length > 0 && setOpen(true)}
        className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
        autoComplete="off"
      />
      {open && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-2xl shadow-xl z-50 overflow-hidden">
          {suggestions.map((item, i) => {
            const main = item.structured_formatting?.main_text || item.description.split(",")[0];
            const sub = item.structured_formatting?.secondary_text || item.description.split(",").slice(1).join(",").trim();
            return (
              <button
                key={i}
                onMouseDown={(e) => { e.preventDefault(); handleSelect(item); }}
                className="w-full text-left px-4 py-3 hover:bg-secondary transition-colors border-b border-border last:border-0"
              >
                <p className="text-sm font-medium text-foreground truncate">{main}</p>
                {sub && <p className="text-xs text-muted-foreground truncate">{sub}</p>}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}