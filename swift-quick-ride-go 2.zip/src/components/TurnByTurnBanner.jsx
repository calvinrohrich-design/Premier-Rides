import { useEffect, useRef, useState } from "react";
import { ArrowUp, ArrowLeft, ArrowRight, CornerUpLeft, CornerUpRight, Flag, Volume2, VolumeX } from "lucide-react";

const ICONS = {
  left: ArrowLeft,
  right: ArrowRight,
  "slight left": CornerUpLeft,
  "slight right": CornerUpRight,
  "sharp left": CornerUpLeft,
  "sharp right": CornerUpRight,
  straight: ArrowUp,
};

function formatDistance(meters) {
  const feet = meters * 3.28084;
  if (feet < 1000) return `${Math.round(feet / 50) * 50} ft`;
  return `${(meters / 1609.34).toFixed(1)} mi`;
}

function stepText(step) {
  const type = step.maneuver?.type;
  const modifier = step.maneuver?.modifier;
  const road = step.name ? ` onto ${step.name}` : "";
  if (type === "arrive") return "You've arrived at your destination";
  if (type === "depart") return `Head ${modifier || "out"}${road}`;
  if (type === "turn") return `Turn ${modifier}${road}`;
  if (type === "merge") return `Merge ${modifier || ""}${road}`;
  if (type === "roundabout" || type === "rotary") return `Take the roundabout${road}`;
  if (type === "fork") return `Keep ${modifier} at the fork${road}`;
  if (type === "end of road") return `At the end of the road, turn ${modifier}${road}`;
  if (type === "continue") return `Continue ${modifier || "straight"}${road}`;
  return `${type || "Continue"} ${modifier || ""}${road}`.trim();
}

/**
 * In-app turn-by-turn instruction banner.
 * Props: from [lat,lng], to [lat,lng]
 */
export default function TurnByTurnBanner({ from, to }) {
  const [step, setStep] = useState(null);
  const [voiceOn, setVoiceOn] = useState(true);
  const lastFetchRef = useRef(0);
  const lastSpokenRef = useRef("");

  // Speak instruction aloud when it changes
  useEffect(() => {
    if (!voiceOn || !step?.text || !("speechSynthesis" in window)) return;
    const phrase = `In ${formatDistance(step.distance)}, ${step.text}`;
    if (lastSpokenRef.current === step.text) return;
    lastSpokenRef.current = step.text;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(phrase);
    utterance.rate = 1;
    window.speechSynthesis.speak(utterance);
  }, [step?.text, voiceOn]);

  useEffect(() => {
    if (!from || !to) return;
    const now = Date.now();
    if (now - lastFetchRef.current < 10000) return; // refresh at most every 10s
    lastFetchRef.current = now;

    const url = `https://router.project-osrm.org/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}?overview=false&steps=true`;
    fetch(url)
      .then((r) => r.json())
      .then((data) => {
        const steps = data?.routes?.[0]?.legs?.[0]?.steps;
        if (!steps || !steps.length) return;
        // Show the next maneuver (skip the initial "depart" when there's more)
        const next = steps.length > 1 ? steps[1] : steps[0];
        setStep({
          text: stepText(next),
          distance: steps[0].distance, // distance until that maneuver
          modifier: next.maneuver?.modifier,
          type: next.maneuver?.type,
        });
      })
      .catch(() => {});
  }, [from?.[0], from?.[1], to?.[0], to?.[1]]);

  if (!step) return null;

  const Icon = step.type === "arrive" ? Flag : ICONS[step.modifier] || ArrowUp;

  return (
    <div className="bg-foreground text-background rounded-2xl px-4 py-3 flex items-center gap-3">
      <div className="w-11 h-11 bg-primary rounded-xl flex items-center justify-center flex-shrink-0">
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="font-bold text-sm leading-tight truncate">{step.text}</p>
        <p className="text-xs opacity-70">{formatDistance(step.distance)}</p>
      </div>
      <button
        onClick={() => {
          const next = !voiceOn;
          setVoiceOn(next);
          if (!next) window.speechSynthesis?.cancel();
          else if (step?.text) {
            lastSpokenRef.current = "";
            // Re-announce current instruction when turning voice on (also unlocks audio on iOS)
            const u = new SpeechSynthesisUtterance(`In ${formatDistance(step.distance)}, ${step.text}`);
            window.speechSynthesis?.speak(u);
            lastSpokenRef.current = step.text;
          }
        }}
        className="w-9 h-9 bg-background/20 rounded-xl flex items-center justify-center flex-shrink-0 active:scale-90 transition-transform"
      >
        {voiceOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
      </button>
    </div>
  );
}