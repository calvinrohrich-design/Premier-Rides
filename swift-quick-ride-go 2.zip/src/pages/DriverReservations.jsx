import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, Clock, ChevronLeft, Calendar, Bell } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { driverEarnings } from "@/utils/fareCalculator";

function formatCountdown(targetIso) {
  const diff = new Date(targetIso) - Date.now();
  if (diff <= 0) return "Now";
  const totalMin = Math.floor(diff / 60000);
  const hours = Math.floor(totalMin / 60);
  const mins = totalMin % 60;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}

function formatDateTime(iso) {
  return new Date(iso).toLocaleString("en-US", {
    weekday: "short", month: "short", day: "numeric",
    hour: "numeric", minute: "2-digit", hour12: true,
  });
}

function playReminderSound() {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  [0, 0.2, 0.4].forEach((t) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.frequency.value = 660; osc.type = "sine";
    gain.gain.setValueAtTime(0.35, ctx.currentTime + t);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.18);
    osc.start(ctx.currentTime + t); osc.stop(ctx.currentTime + t + 0.2);
  });
}

export default function DriverReservations() {
  const [user, setUser] = useState(null);
  const [reservations, setReservations] = useState([]);
  const [pendingReservations, setPendingReservations] = useState([]);
  const [accepting, setAccepting] = useState(null);
  const [tick, setTick] = useState(0);
  const remindedRef = useRef(new Set());

  // Countdown ticker
  useEffect(() => {
    const interval = setInterval(() => setTick((t) => t + 1), 30000);
    return () => clearInterval(interval);
  }, []);

  // Reminder alerts — fire at 60 min and 30 min before
  useEffect(() => {
    reservations.forEach((r) => {
      const diffMin = (new Date(r.scheduled_time) - Date.now()) / 60000;
      const key60 = `${r.id}-60`;
      const key30 = `${r.id}-30`;
      if (diffMin <= 62 && diffMin > 58 && !remindedRef.current.has(key60)) {
        remindedRef.current.add(key60);
        playReminderSound();
        if ("Notification" in window && Notification.permission === "granted") {
          new Notification("⏰ Reservation in 1 Hour", {
            body: `${r.pickup_address} → ${r.dropoff_address}`,
            tag: `res-${r.id}-60`,
          });
        }
      }
      if (diffMin <= 32 && diffMin > 28 && !remindedRef.current.has(key30)) {
        remindedRef.current.add(key30);
        playReminderSound();
        if ("Notification" in window && Notification.permission === "granted") {
          new Notification("🚨 Reservation in 30 Minutes!", {
            body: `Head to ${r.pickup_address}`,
            tag: `res-${r.id}-30`,
            requireInteraction: true,
          });
        }
      }
    });
  }, [tick, reservations]);

  useEffect(() => {
    base44.auth.me().then((me) => {
      if (!me) return;
      setUser(me);
      if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
      loadMyReservations(me.id);
      loadPendingReservations();
    });

    // Subscribe to new reservations
    const unsub = base44.entities.Reservation.subscribe((event) => {
      if (event.type === "create" && event.data?.status === "pending") {
        setPendingReservations((prev) => [event.data, ...prev]);
        playReminderSound();
      }
      if (event.type === "update") {
        setPendingReservations((prev) => prev.filter((r) => r.id !== event.data?.id));
      }
    });
    return unsub;
  }, []);

  const loadMyReservations = async (driverId) => {
    const all = await base44.entities.Reservation.filter({ driver_id: driverId });
    const upcoming = all.filter((r) => r.status === "accepted" && new Date(r.scheduled_time) > Date.now());
    setReservations(upcoming.sort((a, b) => new Date(a.scheduled_time) - new Date(b.scheduled_time)));
  };

  const loadPendingReservations = async () => {
    const all = await base44.entities.Reservation.filter({ status: "pending" });
    // Only show future ones
    setPendingReservations(all.filter((r) => new Date(r.scheduled_time) > Date.now())
      .sort((a, b) => new Date(a.scheduled_time) - new Date(b.scheduled_time)));
  };

  const acceptReservation = async (res) => {
    setAccepting(res.id);
    await base44.entities.Reservation.update(res.id, {
      driver_id: user.id,
      driver_name: user.full_name,
      status: "accepted",
    });
    setPendingReservations((prev) => prev.filter((r) => r.id !== res.id));
    loadMyReservations(user.id);
    setAccepting(null);
  };

  const getUrgency = (iso) => {
    const min = (new Date(iso) - Date.now()) / 60000;
    if (min <= 30) return "urgent";
    if (min <= 60) return "soon";
    return "normal";
  };

  const urgencyStyle = {
    urgent: "border-red-400 bg-red-50",
    soon: "border-amber-400 bg-amber-50",
    normal: "border-border bg-card",
  };

  const urgencyBadge = {
    urgent: "bg-red-100 text-red-700",
    soon: "bg-amber-100 text-amber-700",
    normal: "bg-secondary text-muted-foreground",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="pb-6 px-5 bg-card border-b border-border" style={{ paddingTop: 'max(3rem, env(safe-area-inset-top, 3rem))' }}>
        <div className="flex items-center gap-3">
          <button onClick={() => window.location.href = "/driver-home"} className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </button>
          <div className="flex-1">
            <p className="text-foreground font-bold text-xl">Reservations</p>
            <p className="text-muted-foreground text-sm">Scheduled rides & open requests</p>
          </div>
          {reservations.length > 0 && (
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-white text-xs font-bold">{reservations.length}</span>
            </div>
          )}
        </div>
      </div>

      <div className="px-5 py-5 space-y-6">

        {/* My Upcoming Reservations */}
        {reservations.length > 0 && (
          <div>
            <p className="font-bold text-base mb-3 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" /> My Upcoming Reservations
            </p>
            <div className="space-y-3">
              {reservations.map((r) => {
                const urgency = getUrgency(r.scheduled_time);
                return (
                  <motion.div key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                    className={`border-2 rounded-2xl p-4 ${urgencyStyle[urgency]}`}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-primary" />
                        <span className="font-bold text-sm">{formatDateTime(r.scheduled_time)}</span>
                      </div>
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${urgencyBadge[urgency]}`}>
                        <Clock className="w-3 h-3" /> {formatCountdown(r.scheduled_time)}
                      </span>
                    </div>
                    <div className="space-y-1.5 mb-3">
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                        <span className="truncate">{r.pickup_address}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="w-3 h-3 text-destructive flex-shrink-0" />
                        <span className="truncate">{r.dropoff_address}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex gap-3">
                        <span>{r.estimated_duration_min} min</span>
                        <span>{r.estimated_distance_miles} mi</span>
                      </div>
                      <span className="font-bold text-foreground text-sm">
                        You earn ${driverEarnings(r.estimated_fare).toFixed(2)}
                      </span>
                    </div>
                    {r.notes && <p className="mt-2 text-xs text-muted-foreground italic border-t border-border pt-2">"{r.notes}"</p>}
                    {urgency === "urgent" && (
                      <div className="mt-3 bg-red-100 rounded-xl px-3 py-2 flex items-center gap-2">
                        <Bell className="w-4 h-4 text-red-600" />
                        <p className="text-xs font-bold text-red-700">Head to pickup now!</p>
                      </div>
                    )}
                    {urgency === "soon" && (
                      <div className="mt-3 bg-amber-100 rounded-xl px-3 py-2 flex items-center gap-2">
                        <Bell className="w-4 h-4 text-amber-600" />
                        <p className="text-xs font-bold text-amber-700">Prepare to leave soon</p>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* Open Reservation Requests */}
        {pendingReservations.length > 0 && (
          <div>
            <p className="font-bold text-base mb-3">Open Reservation Requests</p>
            <div className="space-y-3">
              <AnimatePresence>
                {pendingReservations.map((r) => (
                  <motion.div key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-card border-2 border-primary/30 rounded-2xl overflow-hidden">
                    <div className="bg-primary/10 px-4 py-2.5 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-primary" />
                        <span className="font-bold text-sm text-primary">{formatDateTime(r.scheduled_time)}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{formatCountdown(r.scheduled_time)} away</span>
                    </div>
                    <div className="p-4">
                      <div className="space-y-1.5 mb-3">
                        <div className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                          <span className="truncate">{r.pickup_address}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="w-3 h-3 text-destructive flex-shrink-0" />
                          <span className="truncate">{r.dropoff_address}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex gap-2 text-xs text-muted-foreground">
                          <span>{r.estimated_duration_min} min</span>
                          <span>·</span>
                          <span>{r.estimated_distance_miles} mi</span>
                          <span>·</span>
                          <span className="capitalize">{r.ride_type}</span>
                        </div>
                        <span className="font-bold text-sm">
                          You earn ${driverEarnings(r.estimated_fare).toFixed(2)}
                        </span>
                      </div>
                      {r.notes && <p className="text-xs text-muted-foreground italic mb-3">"{r.notes}"</p>}
                      <button
                        onClick={() => acceptReservation(r)}
                        disabled={accepting === r.id}
                        className="w-full bg-primary text-white py-3 rounded-2xl font-bold shadow-lg shadow-primary/30 active:scale-95 transition-transform disabled:opacity-50"
                      >
                        {accepting === r.id ? (
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
                        ) : "Accept Reservation"}
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        {reservations.length === 0 && pendingReservations.length === 0 && (
          <div className="text-center py-16">
            <span className="text-6xl block mb-4">📅</span>
            <p className="font-bold text-lg">No reservations</p>
            <p className="text-muted-foreground text-sm mt-1">Open requests will appear here automatically</p>
          </div>
        )}
      </div>
    </div>
  );
}